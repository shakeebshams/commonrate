# CommonRate

**Conditional group checkout for one fixed-fee expert session.**

A small, already wallet-native group wants to book an expert it knows, but the organizer cannot commit until enough people put money down. CommonRate models one shared USDC fee with a clear maximum deposit per seat and a fixed rule for allocating unused deposits. The organizer has no discretionary withdrawal role.

This is an experimental prototype, not a marketplace, an attendance system, an investment, or service-delivery escrow. The group and provider must agree the actual session offchain. No real provider, booking, customers, revenue or live transaction results are claimed.

## Start with Sandbox

Sandbox is the default. It is a local simulation: no wallet connection, signature, token movement or real booking. Use the simulation controls to change reservations, pass the illustrative deadline, finalize an outcome and mark simulated claims. Reloading is not a way to recover a real financial record.

The separate, explicitly selected **Live pilot** can request real wallet actions. It is not necessary to explore or test the Sandbox. See [Live pilot boundaries](#live-pilot-boundaries) before using it.

## How the payment rule works

Each round fixes its provider's total fee, seller address, maximum deposit per paid unit, minimum, capacity and deadline. Capacity is at most 12. Optional sponsorship fixes a sponsor address and a contribution per successful paid unit.

1. **Prefund the sponsor reserve, if any.** The named sponsor deposits the entire per-unit subsidy multiplied by capacity before reservations open. With no subsidy, no sponsor action is needed.
2. **Reserve paid units.** Each wallet deposits the maximum amount per unit. One wallet may reserve several units. Deposits and sponsor funding cannot be cancelled or withdrawn early.
3. **Wait for the deadline.** Filling capacity does not trigger early settlement. Funding and reservations close at the deadline; chain time, not the browser countdown, is authoritative.
4. **Finalize.** After the deadline, anyone may call finalization. A successful round allocates the fixed seller payment, participant refunds and unused sponsor reserve. A failed round allocates full participant deposits and the actually funded sponsor reserve back to their respective wallets. Finalization allocates claims; it does not send the payouts.
5. **Withdraw separately.** Each wallet requests its own outstanding credit. A claimable amount is not a confirmed withdrawal, and a transaction hash is not proof of success.

USDC accounting uses integer millionths: 1 USDC = 1,000,000 token units. On success, the fixed fee is divided across the final paid-unit count; the first remainder seat indices bear one extra micro-USDC. Each unit's participant charge is that gross share minus the fixed sponsor subsidy. The rest of its deposit becomes claimable. Role credits add together if a wallet is both seller, sponsor or participant.

### Illustrative session, not a real offer

Fixed fee: **600 USDC**. Deposit: **60 USDC per paid unit**. Sponsor support: **15 USDC per successful unit**, prefunded up to **180 USDC**. Minimum: **8**. Capacity: **12**.

| Final paid units | Participant charge per unit | Participant refund per unit | Sponsor used / unused claim | Seller claim |
| --- | --- | --- | --- | --- |
| 7: failed minimum | 0 | 60 | 0 / 180 | 0 |
| 8: success | 60 | 0 | 120 / 60 | 600 |
| 10: success | 45 | 15 | 150 / 30 | 600 |
| 12: success | 35 | 25 | 180 / 0 | 600 |

At 9 paid units, the first 6 seats pay **51.666667 USDC** and receive **8.333333 USDC** back; the remaining 3 pay **51.666666 USDC** and receive **8.333334 USDC** back. All examples assume the sponsor reserve was deposited. The provider's fee remains 600 USDC: this is fixed-cost sharing, not a vendor bulk-discount quote.

## Run and test locally

Use **Bun 1.3.14** (`.bun-version`) and **Foundry v1.7.1** (`.foundry-version`). The Solidity configuration pins **0.8.28**, Paris EVM, optimizer 200 and via IR. Install these tools from their official distributions if they are not already available.

Run from the repository root:

```sh
bun install --frozen-lockfile
bun run dev
```

Open the local URL Vite reports. The development server is for trusted local use, not public hosting.

```sh
# App tests, type checking, non-fixing lint and production build
bun run check

# Solidity compilation and focused contract tests
bun run contracts:build
bun run contracts:test
```

The contract test script uses 512 fuzz runs. Individual app commands are `bun run test`, `bun run typecheck`, `bun run lint` and `bun run build`. The production output is `dist/`. These build/test commands do not deploy a contract or transact with a wallet. Do not add broadcast flags or use deployment helper scripts as part of a routine verification run.

Key files:

- `contracts/CommonRate.sol`: immutable round terms, allocation and pull-claim accounting.
- `contracts/test/CommonRate.t.sol`: mocked-token and property tests.
- `src/simulation/`: integer math and Sandbox state.
- `src/live/`: isolated, user-operated pilot, contract verification and receipt lifecycle.
- `src/contracts/CommonRate.artifact.json`: ABI and pinned compiler artifact used by the pilot.
- `tests/`: app math, state, interface and mocked Live regressions.
- `docs/BUILD.md`: reproducible local setup and verification commands.
- `docs/VERIFICATION.md`: verification scope, source identity and remaining limits for this private source delivery.

## Live pilot boundaries

**Experimental, unaudited and single-window only.** Use one top-level browser window. Embedded frames are blocked. Do not open another Live tab or window, switch execution contexts or retry while a wallet request or transaction outcome is unresolved. Shared-storage checks are best effort, not an atomic cross-tab lock.

The pilot is a controlled-wallet allocation test, not a real session sale. It uses fixed small amounts:

- Seller fee: **0.12 USDC**.
- Participant deposit: **0.06 USDC per unit**.
- Sponsor subsidy: **0.01 USDC per successful unit**.
- Minimum **2** units; capacity **3**; prefunded sponsor reserve **0.03 USDC**.

With exactly 2 reserved units, deposits total **0.15 USDC**. After the deadline and successful finalization, seller credit is **0.12**, total participant refund credit is **0.02**, and unused sponsor credit is **0.01**. Total claims equal **0.15 USDC**, excluding gas. One controlled wallet buying both units demonstrates two paid units, not two customers. Overlapping roles are allowed and must be disclosed.

Network selection and connection are explicit. The user performs all actual approvals, deployment, funding, reservations, finalization and withdrawals through their own wallet. No private key or seed phrase is needed by this app. Do not use unattended signing or automation.

Before any real-money use, independently verify the current official Arc network/token configuration, exact contract creation transaction, compiled artifact and runtime, immutable terms, addresses, deadline and wallet balance. This repository provides no claimed live deployment address or transaction proof. Testnet tokens are not evidence of mainnet compatibility.

The USDC token interface uses **6 decimals**; Arc's native gas balance uses an **18-decimal view of the same USDC**. They are not two independent balances: never add them together. Keep additional USDC available for network fees.

The controller is designed to require fresh checks and an explicit review for each wallet action, with bounded approvals. It does not automatically reconnect, retry, chain transactions, finalize or withdraw. Pending or unknown outcomes must be reconciled with wallet/chain evidence, not treated as failure and resubmitted. Public transaction references in browser storage are recovery aids, not financial truth. One successful receipt confirmation is not a finality guarantee.

## Security and trust limits

- **Funding success is not service delivery.** Failed-funding refunds do not cover later cancellation, nonattendance, poor quality or nondelivery. Verify the provider and agree those matters separately.
- **Seats are paid units, not verified people.** A wallet can buy several, and seller/buyer roles can overlap. A sponsor must trust the known group's conduct; the contract does not prevent a seller-controlled payer from consuming a subsidy without independent attendees.
- **No early exit or administrator rescue.** Terms cannot be changed after creation. There is no organizer drain, discretionary payout, upgrade or emergency withdrawal route. Do not send tokens directly to the contract; unsolicited transfers do not create seats or claims and may be unrecoverable.
- **Claims still depend on the token and network.** USDC issuer freezes, token/proxy changes, insufficient contract holdings, wallet failures, network problems and contract defects may delay or prevent withdrawal. No refund guarantee applies to funds the contract no longer holds.
- **Local checks are not a professional audit.** Exact artifact matching proves build identity, not absence of vulnerabilities or suitability for production funds.

## Verification status

Status as of **22 October 2026**:

- The original 26 contract tests passed, including a 512-run bounded fuzz property test, and passed again in the original Studio project on 22 October 2026 with 0 failures or skips. The separately reviewed optional stateful suite adds 16 tests; a combined local run passed all 42. Its 120 four-wallet claim-order scenarios and 32 fixed two-round schedules are finite mock coverage, not live transactions or a professional audit. The normal contracts:test command still runs only the original 26; see [optional regressions](docs/SUPPLEMENTAL_CONTRACT_TESTS.md). Exact ABI and creation/runtime bytecode were independently reproduced with the pinned compiler settings.
- The current submission candidate passed 372 app tests with 2,765 assertions, typecheck, non-fixing source lint and production build against the frozen dependencies. The wallet-transport guard prevents automatic fallback to a second transaction-submission method after ambiguous errors; the original error and pending-outcome lock remain. Selective client construction retains the same action behavior in offline parity checks. Newly confirmed deployment hashes stay synchronized with the lookup field without erasing imported drafts; campaign action reviews are blocked when a draft differs from the displayed verified pilot, with an explicit local-only restore action. The explicit deadline helper fills only from the last checked chain time plus 30 minutes; it does not refresh time, overwrite manual entries automatically or weaken the fresh review/submission checks. Targeted accessibility refinements provide exact simulated claim feedback and same-row focus, plus darker Live placeholder hints; these are not a full accessibility certification. Automated checks do not prove real-wallet behavior.
- This private r6 package changes only delivery documentation and integrity records from r5. Its runtime and tests match native runtime11, commit `ee79873b251caf92189a63a466ef16113b27a539`. The six reviewed application/test files and existing third-party notice were synchronized into the original Arc Studio project. Studio then passed the full 372-test check and the original 26-contract-test command. Final scoped parity matched 72/72 application/configuration inputs and 9/9 production assets; this is not a full source export. Export26 remains the last full working-tree export, and no new source download was made. See [verification boundaries](docs/VERIFICATION.md) for the exact scope.
- The preceding interface passed hosted desktop, narrow-window and browser-zoom checks, including Rules-dialog focus containment and retained simulated receipt state. The first v2 layout passed desktop receipt/state, dialog keyboard and same-width return-focus checks. The corrected selector and exact result were co-visible at 500px and 333px reflow, with native option contrast, preset reset and retained history verified. The local reservation-completion acknowledgment, explicit receipt jump and stale-context cleanup were subsequently verified in the hosted browser. The title and authored favicon also loaded correctly. Local views do not create separate browser-history entries, while controlled same-document native Back/Forward preserved state. No physical-phone, touch or real-wallet tests are claimed. These earlier hosted observations remain historical; the new embedded Studio checks below do not replace them or establish standalone wallet behavior.
- The current embedded Studio preview passed focused keyboard and simulation checks: Rules-dialog Tab/Shift+Tab containment and Escape return focus, a 10-seat round with one owned seat settling to a 45 USDC cost and 15 USDC simulated claim, and retention of the original refund receipt after marking that simulated claim and returning to booking. At a 375px emulated viewport the document width also measured 375px; the provider disclaimer and failed 7-seat preset with two owned seats/120 USDC refund displayed cleanly. Experimental Live reached the embedded-frame restriction with Connect wallet disabled, no selected network and no account permission or transaction. One first lazy-load preview reload and Vite reconnect were observed with an unestablished cause; subsequent opening reached the stable disabled state. Switching Studio viewport remounted the iframe and reset Sandbox, so persistence across reloads is not claimed. This is not a physical-phone, standalone Live or real-wallet test.
- A later public read-only Arc Mainnet check in embedded Studio succeeded at 17:15:58 UTC on 22 October 2026: chain, canonical token code, six decimals and chain time were read at block 27,317,207 (chain time 17:15:57 UTC). A later Arc Testnet read passed at 17:16:34 UTC, block 68,553,765 (chain time 17:16:33 UTC); switching networks first cleared the prior Mainnet result. Both used Public Arc RPC with a blank deployment reference, no campaign verification and no wallet/account access or transaction. Official Arc/Circle configuration was checked separately; see [network evidence and wallet-fee gate](docs/VERIFICATION.md#public-network-read-and-remaining-wallet-fee-gate). These are genuine public network metadata reads, not campaign deployment, token movement, wallet compatibility or contest eligibility proof.
- No actual wallet connection, signature, approval, deployment, funding, reservation, finalization, claim or other chain write is part of the reported evidence. No real token movement is claimed.

Keep the pilot experimental. Standalone wallet behavior, actual wallet fee handling, Mainnet campaign/transaction proof and contest eligibility remain unestablished. Public release and real-money readiness are separate decisions.

## Third-party notices

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and the exact texts under `licenses/`. Preserve the vendored Forge Standard Library's notices alongside its source. Third-party notices do not choose or grant a project-wide license for CommonRate's own code.

### Submission cancellation boundary

A final synchronous context check runs immediately before forwarding `eth_sendTransaction` to the wallet provider. A known account/chain change, disconnect or disposal before that boundary cancels the request without sending it. Once forwarded, a later context change does not prove cancellation: ambiguous outcomes retain the recovery lock. If cancellation cleanup cannot be saved, or the controller has already been disposed, a reopened panel can conservatively retain an unresolved reference. Do not clear storage or open another Live window to work around it. These paths were exercised with inert providers, not real-wallet or Mainnet transactions.
