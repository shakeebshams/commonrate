import { describe, expect, test } from 'bun:test';
import { existsSync, readFileSync } from 'node:fs';
import { renderToStaticMarkup } from 'react-dom/server';
import App from '../src/App';
import SandboxControls from '../src/components/SandboxControls';
import MoneyMap from '../src/components/MoneyMap';
import PriceCurve from '../src/components/PriceCurve';
import { buildScenarioState, SCENARIOS, passDeadline, finalize, simulateClaim, participantAddr, makeInitialState, reserve, SANDBOX_TERMS } from '../src/simulation/engine';
import { openDemo } from '../src/simulation/presentation';
const text = (html: string) => html.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;/g, "'");
const noop = () => {};

describe('manual interface server-rendered regressions (not browser tests)', () => {
  test('default page presents one10-seat state and exact owned-seat receipt', () => {
    const html = renderToStaticMarkup(<App />);
    const copy = text(html);
    expect(copy).toContain('10 of 12 seats reserved');
    expect(copy).toContain('1 seat · 60 USDC deposited');
    expect(copy).toContain('45USDC');
    expect(copy).toContain('Estimated final cost');
    expect(copy).toContain('If the round succeeds, more seats mean a lower final cost.');
    expect(copy).not.toContain('A shared booking, illustrated');
    expect(html.indexOf('Explore payment outcomes')).toBeLessThan(html.indexOf('Estimate assumes 10 seats'));
    expect(html).toContain('cr-refund-summary');
    expect(copy).toContain('Estimated deposit refund15 USDC');
    expect(copy).toContain('180 / 180 USDC');
    expect(copy).not.toContain('Snapshot presets');
    expect(copy).not.toContain('CR–001');
    expect(copy).toContain('Review the experimental Live pilot');
    expect(copy).not.toContain('Connect wallet');
    expect(copy).not.toContain('Choose a network');
    expect(copy).not.toContain('Mainnet uses real USDC');
    expect(html.match(/id="money-map"/g)?.length).toBe(1);
  });
  test('unfunded expiry action is available without sponsor money', () => {
    const copy = text(renderToStaticMarkup(<SandboxControls state={makeInitialState(SANDBOX_TERMS, false)} scenarioId="await" onStateChange={noop} onSelectScenario={noop} onReset={noop} onViewReceipt={noop} />));
    expect(copy).toContain('actual deposited reserve is 0 USDC');
    expect(copy).toContain('Advance to deadline unfunded');
    expect(copy).not.toContain('Simulate reservation');
  });
  test('new-reservation quote uses projected count11, not the existing10-seat price', () => {
    const copy = text(renderToStaticMarkup(<SandboxControls state={openDemo()} scenarioId={null} onStateChange={noop} onSelectScenario={noop} onReset={noop} onViewReceipt={noop} />));
    expect(copy).toContain('New total after reserving11 seats');
    expect(copy).toContain('Estimated charge for these new seats39.545454 USDC');
    expect(copy).toContain('Estimated refund for these new seats20.454546 USDC');
  });
  test('at capacity before deadline offers no early settlement', () => {
    const copy = text(renderToStaticMarkup(<SandboxControls state={openDemo(12)} scenarioId={null} onStateChange={noop} onSelectScenario={noop} onReset={noop} onViewReceipt={noop} />));
    expect(copy).toContain('Advance to deadline');
    expect(copy).not.toContain('Simulate settlement');
    expect(copy).not.toContain('Simulate reservation');
  });
  test('historical allocations remain labeled original after a claim', () => {
    const state = simulateClaim(finalize(passDeadline(openDemo())), participantAddr(0));
    const copy = text(renderToStaticMarkup(<MoneyMap state={state} />));
    expect(copy).toContain('Original allocation at settlement');
    expect(copy).toContain('Original refund allocation');
    expect(copy).not.toContain('Claimable refund');
    expect(copy).toContain('remaining simulated balance = 765.000000 USDC');
  });
  test('N9 exact range shows both micro-USDC charges and refunds', () => {
    const state = buildScenarioState(SCENARIOS.find(s => s.id === 'n9')!);
    const copy = text(renderToStaticMarkup(<PriceCurve terms={state.terms} highlightN={9} sponsorFunded />));
    expect(copy).toContain('51.666666–51.666667');
    expect(copy).toContain('8.333333–8.333334');
  });
  test('unfunded curve makes no successful-price claim and K1 geometry is finite', () => {
    expect(text(renderToStaticMarkup(<PriceCurve terms={SANDBOX_TERMS} highlightN={10} sponsorFunded={false} />))).toContain('No successful price is available');
    const tiny = { ...SANDBOX_TERMS, capacity: 1n, minUnits: 1n, cost: 1n, depositPerUnit: 1n, subsidyPerUnit: 0n, sponsorReserve: 0n };
    const html = renderToStaticMarkup(<PriceCurve terms={tiny} highlightN={1} sponsorFunded={false} />);
    expect(html).not.toContain('NaN');
    expect(html).not.toContain('Infinity');
  });
  test('generic minimum-only failure does not invent a negative funding gap', () => {
    const terms = { ...SANDBOX_TERMS, cost: 600n, depositPerUnit: 100n, subsidyPerUnit: 10n, sponsorReserve: 120n, minUnits: 8n };
    let state = makeInitialState(terms, true);
    state = reserve(state, 7, participantAddr(0));
    state = finalize(passDeadline(state));
    const copy = text(renderToStaticMarkup(<MoneyMap state={state} />));
    expect(copy).toContain('minimum was not reached, even though eligible funding covers the cost');
    expect(copy).not.toContain('Funding gap = -');
    expect(copy).not.toContain('Both the minimum and eligible-funding conditions failed');
  });
  test('Live is lazy, explicit, mode-labelled and distinct from Sandbox rules', () => {
    const source = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
    expect(source).toContain("const LivePilot = lazy(() => import('./live/LivePilot'))");
    expect(source).not.toMatch(/import LivePilot from/);
    expect(source).toContain("useState<Mode>('sandbox')");
    expect(source).toContain('Experimental Live pilot. Mainnet uses real USDC; testnet uses test tokens.');
    expect(source).toContain("mode === 'sandbox' && <button ref={rulesOpener}");
    expect(source).toContain('mainRef.current?.focus({ preventScroll: true })');
    expect(source).toContain("window.scrollTo({ top: 0, behavior: 'auto' })");
    expect(existsSync(new URL('../src/components/LiveGate.tsx', import.meta.url))).toBe(false);
  });
  test('shared desktop containers keep width and gutters separate from mode navigation', () => {
    const css = readFileSync(new URL('../src/index.css', import.meta.url), 'utf8');
    const shared = css.match(/\.cr-header-inner,\s*\.cr-main,\s*\.cr-footer\s*\{([^}]+)\}/)?.[1] ?? '';
    expect(shared).toContain('max-width: 1120px');
    expect(shared).toContain('padding-left: 40px; padding-right: 40px');
    expect(css).toContain('html { scroll-behavior: auto;');
    expect(css).not.toContain('scroll-behavior: smooth');
  });
  test('simulation workspace preserves one state owner and focuses explicit navigation', () => {
    const source = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
    expect(source).toContain("setSandboxView('workspace')");
    expect(source).toContain('workspaceHeading.current?.focus()');
    expect(source).toContain('workspaceOpener.current?.focus()');
    expect(source).not.toContain('scrollIntoView');
    expect(source).not.toContain('demoRef');
    expect(source.match(/useState<SimState>/g)).toHaveLength(1);
    expect(source).toContain('receipt={receipt} compact');
    expect(source).toContain('aria-live="polite" aria-atomic="true"');
    const html = renderToStaticMarkup(<App />);
    expect(html.match(/id="receipt-title"/g)).toHaveLength(1);
    expect(html).not.toContain('id="workspace-title"');
  });
  test('entry has no wallet or diagnostics initialization', () => {
    const main = readFileSync(new URL('../src/main.tsx', import.meta.url), 'utf8');
    expect(main).not.toMatch(/import[^\n]*(tracing|console-capture|wagmi|config|connectkit)/);
    expect(main).not.toContain('WagmiProvider');
    for (const path of ['config.ts', 'tracing.ts', 'console-capture.ts']) {
      expect(existsSync(new URL(`../src/${path}`, import.meta.url))).toBe(false);
    }
  });
});


test('workspace selector styling uses the single receipt', () => {
  const source = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  const controls = readFileSync(new URL('../src/components/SandboxControls.tsx', import.meta.url), 'utf8');
  const css = readFileSync(new URL('../src/index.css', import.meta.url), 'utf8');
  expect(source).toContain('Payment outcomes');
  expect(source).toContain('outcomeControl={<ScenarioPicker');
  expect(controls).not.toContain('<ScenarioPicker');
  expect(controls).not.toContain('Choose a state');
  expect(css).toContain('.cr-receipt .cr-receipt-outcome-control select, .cr-receipt .cr-receipt-outcome-control option { color: #172a32; background: #f7f9fc;');
});
