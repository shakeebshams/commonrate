import { describe, expect, test } from 'bun:test';
import { encodeDeployData, type Address, type Hex } from 'viem';
import { campaignStateLabel, constructorArgs, deadlineFromUTC, MAX_SUPPORTED_DEADLINE, inFrame, PILOT, PILOT_DESCRIPTION, PILOT_TITLE, quantity, TERMS_HASH, TOKEN, usdc } from '../src/live/pilot';
import { ARTIFACT, assertRelease, validateProvenance, validateRuntime, validateTermReads, type Artifact, type CreationReceipt, type CreationTransaction, type TermReads } from '../src/live/verification';
const seller = '0x1111111111111111111111111111111111111111' as Address;
const sponsor = '0x2222222222222222222222222222222222222222' as Address;
const campaign = '0x3333333333333333333333333333333333333333' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex; const blockHash = `0x${'55'.repeat(32)}` as Hex;
const terms = { seller, sponsor, deadline: 2000n };
const termReads: TermReads = { token: TOKEN, seller, sponsorAddress: sponsor, cost: PILOT.cost, depositPerUnit: PILOT.deposit, subsidyPerUnit: PILOT.subsidy, capacity: PILOT.capacity, minUnits: PILOT.minimum, deadline: terms.deadline, sponsorReserve: PILOT.reserve, title: PILOT_TITLE, description: PILOT_DESCRIPTION, termsHash: TERMS_HASH };
function fixture() {
  const tx: CreationTransaction = { hash, from: seller, to: null, value: 0n, input: encodeDeployData({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs(terms) }), chainId: 5042002, blockHash };
  const receipt: CreationReceipt = { transactionHash: hash, status: 'success', contractAddress: campaign, blockNumber: 10n, blockHash, to: null }; return { tx, receipt };
}
const template = { deployedBytecode: `0x60${'00'.repeat(32)}61${'00'.repeat(32)}62` as Hex, immutableReferences: { '1': [{ start: 1, length: 32 }, { start: 34, length: 32 }] } };
const runtime = `0x60${'ab'.repeat(32)}61${'ab'.repeat(32)}62` as Hex;
describe('Live exact artifact, runtime and initialization provenance (mock only)', () => {
  test('final release identity matches independently reproduced export14', () => { expect(() => assertRelease()).not.toThrow(); });
  test('artifact metadata/reference changes cannot exploit bytecode-only pins', () => { expect(() => assertRelease({ ...ARTIFACT, immutableReferences: { '1': [{ start: 0, length: 32 }] } })).toThrow('identity'); });
  test('precise immutable slots permit constructor values', () => { expect(() => validateRuntime(runtime, template)).not.toThrow(); });
  test('a changed nonimmutable opcode fails', () => { expect(() => validateRuntime(`${runtime.slice(0, -2)}63`, template)).toThrow('outside'); });
  test('every occurrence of one immutable must agree', () => { expect(() => validateRuntime(runtime.replace('61ab', '61ac') as Hex, template)).toThrow('Inconsistent'); });
  test('runtime length, malformed and overlapping ranges fail closed', () => {
    expect(() => validateRuntime(`${runtime}00`, template)).toThrow('length');
    for (const refs of [[{ start: -1, length: 32 }], [{ start: 1, length: 31 }], [{ start: 50, length: 32 }], [{ start: 1, length: 32 }, { start: 2, length: 32 }]]) expect(() => validateRuntime(runtime, { ...template, immutableReferences: { '1': refs } })).toThrow();
    expect(() => validateRuntime(runtime, { ...template, immutableReferences: {} })).toThrow();
  });
  test('correct code cannot substitute changed immutable/config terms', () => {
    expect(() => validateTermReads(termReads, terms)).not.toThrow();
    for (const [key, value] of Object.entries(termReads)) {
      const corrupt = typeof value === 'bigint' ? value + 1n : `${String(value)}x`;
      expect(() => validateTermReads({ ...termReads, [key]: corrupt }, terms)).toThrow();
    }
  });
  test('exact successful direct creation derives the receipt address', () => { const { tx, receipt } = fixture(); expect(validateProvenance(tx, receipt, 5042002, 1000n)).toEqual({ address: campaign, terms }); });
  test('factory, nonzero value, wrong chain, receipt, block and failed initialization are rejected', () => {
    const { tx, receipt } = fixture();
    for (const changed of [{ to: campaign }, { value: 1n }, { chainId: 5042 }, { blockHash: hash }, { hash: blockHash }]) expect(() => validateProvenance({ ...tx, ...changed }, receipt, 5042002, 1000n)).toThrow();
    for (const changed of [{ to: campaign }, { status: 'reverted' as const }, { contractAddress: null }, { transactionHash: blockHash }]) expect(() => validateProvenance(tx, { ...receipt, ...changed }, 5042002, 1000n)).toThrow();
  });
  test('different creation bytecode, amount, description, extra trailing bytes and expired deadline fail', () => {
    const { tx, receipt } = fixture(); const args = [...constructorArgs(terms)];
    expect(() => validateProvenance({ ...tx, input: `0xff${tx.input.slice(4)}` }, receipt, 5042002, 1000n)).toThrow();
    expect(() => validateProvenance({ ...tx, input: `${tx.input}00` }, receipt, 5042002, 1000n)).toThrow();
    for (const index of [0, 3, 4, 5, 6, 7, 9, 10, 11]) {
      const changed = [...args]; changed[index] = typeof changed[index] === 'bigint' ? (changed[index] as bigint) + 1n : index === 0 ? seller : index === 11 ? hash : 'Different text';
      const input = encodeDeployData({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: changed }); expect(() => validateProvenance({ ...tx, input }, receipt, 5042002, 1000n)).toThrow();
    }
    expect(() => validateProvenance(tx, receipt, 5042002, 2000n)).toThrow('deadline');
  });
  test('nonrelease miniature runtime fixture is not authorized as artifact', () => { expect(() => assertRelease({ ...ARTIFACT, ...template } as Artifact)).toThrow(); });
});
describe('Live exact tiny inputs and frame checks', () => {
  test('BigInt quantity and micro-USDC formatting never use floating money', () => {
    expect(quantity('3')).toBe(3n); expect(usdc(120000n)).toBe('0.120000'); expect(usdc(1n)).toBe('0.000001');
    for (const n of ['0', '4', '1.5', '01', '-1', '1e0', ' 1']) expect(() => quantity(n)).toThrow();
    expect(() => quantity('2', 1n)).toThrow();
  });
  test('UTC date requires exact valid calendar roundtrip', () => {
    expect(deadlineFromUTC('2028-02-29T12:00Z')).toBe(BigInt(Date.parse('2028-02-29T12:00:00Z') / 1000));
    for (const value of ['2027-02-29T12:00:00Z', '2026-04-31T12:00:00Z', '2026-10-22T24:00:00Z', '2026-10-22T12:00:00', '2026-10-22T12:00:00+00:00']) expect(() => deadlineFromUTC(value)).toThrow();
  });
  test('frame and inaccessible top fail closed', () => {
    expect(inFrame(undefined)).toBe(true);
    const same = {} as Window; expect(inFrame({ top: same, self: same })).toBe(false);
    expect(inFrame({ top: null, self: same })).toBe(true);
    const inaccessible = { get top(): Window { throw new Error('cross origin'); }, self: same }; expect(inFrame(inaccessible)).toBe(true);
  });
});

describe('Loaded deadline and campaign status regressions', () => {
  test('huge valid uint256 constructor deadlines are rejected before UI conversion', () => {
    const { tx, receipt } = fixture(); const huge = { ...terms, deadline: MAX_SUPPORTED_DEADLINE + 1n };
    const input = encodeDeployData({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs(huge) });
    expect(() => validateProvenance({ ...tx, input }, receipt, 5042002, 1000n)).toThrow('supported UTC');
  });
  test('unfunded, full and zero-reservation states never imply open sales', () => {
    const state = { finalized: false, succeeded: false, unitCount: 0n, timestamp: 1000n, terms, sponsorFunded: false };
    expect(campaignStateLabel(state)).toBe('Awaiting sponsor funding'); expect(campaignStateLabel({ ...state, sponsorFunded: true, unitCount: 3n })).toBe('Full; awaiting deadline');
    expect(campaignStateLabel({ ...state, finalized: true })).toBe('Finalized: no reservations'); expect(campaignStateLabel({ ...state, timestamp: 2000n })).toBe('Deadline reached; awaiting finalization');
  });
});
