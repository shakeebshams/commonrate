import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';
import { renderToStaticMarkup } from 'react-dom/server';
import { ClaimRow, claimCompletionText, completedActionAnnouncement } from '../src/components/SandboxControls';
import { buildScenarioState, buildWalletReceipts, finalize, makeInitialState, participantAddr, passDeadline, reserve, SANDBOX_SELLER, SANDBOX_SPONSOR, SCENARIOS, simulateClaim } from '../src/simulation/engine';
import { openDemo, receiptFor } from '../src/simulation/presentation';

const scenario = (id: string) => buildScenarioState(SCENARIOS.find(item => item.id === id)!);
const source = (path: string) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

describe('simulated wallet-claim feedback (pure/SSR/source, not browser focus tests)', () => {
  test('names the actual claimed wallet and exact amount, not the selected receipt', () => {
    const state = scenario('n10');
    for (const [address, amount] of [[SANDBOX_SELLER, '600'], [SANDBOX_SPONSOR, '30'], [participantAddr(1), '45']]) {
      const receipt = buildWalletReceipts(state).find(item => item.address === address)!;
      expect(claimCompletionText(receipt)).toBe(`Marked ${amount} USDC claimed for ${address} in this simulation. No real funds moved.`);
    }
  });

  test('preserves meaningful micro-USDC and aggregates all roles for one wallet', () => {
    const exact = buildWalletReceipts(scenario('n9')).find(item => item.address === participantAddr(2))!;
    expect(claimCompletionText(exact)).toContain('16.666667 USDC');
    const state = finalize(passDeadline(reserve(makeInitialState(), 10, SANDBOX_SELLER)));
    const receipt = buildWalletReceipts(state).find(item => item.address === SANDBOX_SELLER)!;
    expect(receipt.role).toEqual(['buyer', 'seller']);
    expect(claimCompletionText(receipt)).toContain('750 USDC');
  });

  test('action feedback is valid only for its exact successful resulting state', () => {
    const before = scenario('n10');
    const message = claimCompletionText(buildWalletReceipts(before).find(item => item.address === SANDBOX_SELLER)!);
    const after = simulateClaim(before, SANDBOX_SELLER);
    const completed = { state: after, message };
    expect(completedActionAnnouncement(completed, after)).toBe(message);
    expect(completedActionAnnouncement(null, after)).toBeNull();
    expect(completedActionAnnouncement(completed, { ...after })).toBeNull();
    expect(completedActionAnnouncement(completed, openDemo())).toBeNull();
    expect(completedActionAnnouncement(completed, simulateClaim(after, SANDBOX_SPONSOR))).toBeNull();
    for (const preset of SCENARIOS) expect(completedActionAnnouncement(completed, buildScenarioState(preset))).toBeNull();
  });

  test('a claimed row retains its programmatic heading target, without a new tab stop or live region', () => {
    const before = scenario('n10');
    const after = simulateClaim(before, SANDBOX_SELLER);
    const row = (state: typeof before) => buildWalletReceipts(state).find(item => item.address === SANDBOX_SELLER)!;
    const original = renderToStaticMarkup(<ClaimRow receipt={row(before)} onClaim={() => true} />);
    const claimed = renderToStaticMarkup(<ClaimRow receipt={row(after)} onClaim={() => true} />);
    expect(original).toContain('<h4 tabindex="-1">seller.workshop</h4>');
    expect(claimed).toContain('<h4 tabindex="-1">seller.workshop</h4>');
    expect(original).toContain('Mark claimed</button>');
    expect(claimed).not.toContain('<button');
    expect(claimed).toContain('600 USDC marked claimed');
    expect(claimed).toContain('0 USDC outstanding');
    expect(claimed).not.toMatch(/aria-live|role="(?:status|alert)"|tabindex="0"/);
    expect(receiptFor(after, participantAddr(0))).toEqual(receiptFor(before, participantAddr(0)));
  });

  test('zero allocations and repeated/unsuccessful claims never offer a false new completion', () => {
    const zero = buildWalletReceipts(scenario('n8')).find(item => item.address === participantAddr(0))!;
    const html = renderToStaticMarkup(<ClaimRow receipt={zero} onClaim={() => false} />);
    expect(html).toContain('No credit to claim');
    expect(html).not.toContain('<button');
    expect(html).not.toContain('marked claimed');
    expect(() => simulateClaim(scenario('n8'), participantAddr(0))).toThrow('Nothing to claim');
    expect(() => simulateClaim(simulateClaim(scenario('n10'), SANDBOX_SELLER), SANDBOX_SELLER)).toThrow('Nothing to claim');
    expect(() => simulateClaim(openDemo(), SANDBOX_SELLER)).toThrow('Not yet finalized');
  });

  test('one existing announcement path consumes successful feedback and reset/preset clears it', () => {
    const app = source('src/App.tsx');
    expect(app).toContain('completedAction.current = message ? { state: next, message } : null;');
    expect(app).toContain('const choose = (id: ScenarioId) => { completedAction.current = null;');
    expect(app).toContain('const actionMessage = completedActionAnnouncement(completedAction.current, state);');
    expect(app).toContain('completedAction.current = null;\n    setAnnouncement(actionMessage ??');
    expect(app.match(/className="cr-sr-only" role="status"/g)).toHaveLength(1);
    expect(app).toContain('onReset={() => update(openDemo())}');
    expect(app.match(/onClaim={\(\) => update\(simulateClaim\(state, participantAddr\(0\)\)\)}/g)).toHaveLength(2);
  });

  test('focus is scheduled only after a successful row claim and stays on that wallet label', () => {
    const controls = source('src/components/SandboxControls.tsx');
    expect(controls).toContain('if (onClaim()) window.requestAnimationFrame(() => walletHeading.current?.focus({ preventScroll: true }))');
    expect(controls).toContain('onStateChange(next, announcement);\n      return true;');
    expect(controls).toContain('catch (cause) { setCompleted(null); updateForm({ error: cause instanceof Error ? cause.message : String(cause) }); return false; }');
    expect(controls).not.toMatch(/aria-live|role="status"|nextElementSibling|scrollIntoView/);
    expect(source('src/index.css')).toContain('.cr-claim-row h4 { margin: 0; font-size: 14px; font-weight: 500; display: block; overflow-wrap: anywhere; }');
  });
});

describe('scoped readable Live placeholder color (static contrast, not rendered CSS evidence)', () => {
  test('palette-consistent placeholder text exceeds 4.5:1 against its white field', () => {
    const css = source('src/live/live.css');
    expect(css).toContain('.cr-live-field input::placeholder, .cr-live-field textarea::placeholder { color: var(--cr-muted); opacity: 1; }');
    const color = source('src/index.css').match(/--cr-muted:\s*#([a-f\d]{6})/i)![1];
    const channels = [0, 2, 4].map(index => parseInt(color.slice(index, index + 2), 16) / 255).map(channel => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
    const luminance = channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
    expect(1.05 / (luminance + 0.05)).toBeGreaterThanOrEqual(4.5);
    expect(css).toContain('background: #fff; color: var(--cr-ink);');
  });

  test('the override targets only placeholders, leaving entered text and disabled-action styles intact', () => {
    const css = source('src/live/live.css');
    expect(css.match(/::placeholder/g)).toHaveLength(2);
    expect(css).not.toContain('!important');
    expect(source('src/index.css')).toContain('button:disabled { cursor: not-allowed; opacity: .5; }');
    expect(source('src/live/LivePilot.tsx')).toContain('disabled={!checkedDeadline || state.busy || unresolved}');
  });
});
