import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';
import { renderToStaticMarkup } from 'react-dom/server';
import { ReservationCompletion, reservationCompletionText } from '../src/components/SandboxControls';
import { buildScenarioState, finalize, participantAddr, passDeadline, reserve, SCENARIOS } from '../src/simulation/engine';
import { openDemo } from '../src/simulation/presentation';

describe('local simulated reservation completion (pure state and SSR, not browser tests)', () => {
  test('names the completed reservation, not the next quoted reservation', () => {
    const before = openDemo();
    const after = reserve(before, 1, participantAddr(0));
    expect(reservationCompletionText({ state: after, quantity: 1 }, after)).toBe('Added 1 seat. 11 of 12 seats reserved.');
    expect(before.unitCount).toBe(10);
    expect(after.unitCount).toBe(11);
  });

  test('uses the actual quantity and current capacity without a second balance', () => {
    const after = reserve(openDemo(8), 2, participantAddr(0));
    const message = reservationCompletionText({ state: after, quantity: 2 }, after);
    expect(message).toBe('Added 2 seats. 10 of 12 seats reserved.');
    expect(message).not.toMatch(/USDC|refund|cost|claim/);
  });

  test('does not display completion before a successful action', () => {
    expect(reservationCompletionText(null, openDemo())).toBeNull();
  });

  test('a replaced round invalidates completion even at the same seat count', () => {
    const after = reserve(openDemo(), 1, participantAddr(0));
    const completed = { state: after, quantity: 1 };
    expect(reservationCompletionText(completed, openDemo(11))).toBeNull();
    expect(reservationCompletionText(completed, { ...after })).toBeNull();
    expect(reservationCompletionText(completed, openDemo())).toBeNull();
    for (const scenario of SCENARIOS) {
      expect(reservationCompletionText(completed, buildScenarioState(scenario))).toBeNull();
    }
  });

  test('later actions and phase changes cannot retain a stale success line', () => {
    const after = reserve(openDemo(), 1, participantAddr(0));
    const completed = { state: after, quantity: 1 };
    expect(reservationCompletionText(completed, reserve(after, 1, participantAddr(0)))).toBeNull();
    const expired = passDeadline(after);
    expect(reservationCompletionText(completed, expired)).toBeNull();
    expect(reservationCompletionText(completed, finalize(expired))).toBeNull();
    const full = reserve(openDemo(), 2, participantAddr(0));
    expect(reservationCompletionText({ state: full, quantity: 2 }, full)).toBeNull();
  });

  test('the quiet receipt action is explicit and adds no second live region', () => {
    let invoked = 0;
    const message = 'Added 1 seat. 11 of 12 seats reserved.';
    const element = ReservationCompletion({ message, onViewReceipt: () => { invoked++; } });
    const html = renderToStaticMarkup(element);
    expect(invoked).toBe(0);
    expect(html).toContain(message);
    expect(html).toContain('View updated receipt');
    expect(html.match(/<button\b/g)).toHaveLength(1);
    expect(html).toContain('type="button"');
    expect(html).not.toMatch(/aria-live|role="(?:status|alert)"|USDC|href=/);
    element.props.children[1].props.onClick();
    expect(invoked).toBe(1);
  });

  test('app wiring focuses the same receipt only through its explicit callback', () => {
    const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
    const controls = readFileSync(new URL('../src/components/SandboxControls.tsx', import.meta.url), 'utf8');
    expect(app).toContain('receiptHeadingRef={receiptHeading}');
    expect(app).toContain('onViewReceipt={() => receiptHeading.current?.focus()}');
    const completionComponent = controls.slice(controls.indexOf('export function ReservationCompletion'), controls.indexOf('export default function SandboxControls'));
    const reservationSection = controls.slice(controls.indexOf("{phase === 'Open'"), controls.indexOf("{phase === 'FullAwaitDeadline'"));
    expect(completionComponent).not.toMatch(/\.focus\(|scrollTo\(|scrollIntoView\(/);
    expect(reservationSection).not.toMatch(/\.focus\(|scrollTo\(|scrollIntoView\(/);
    expect(controls.indexOf('{completion && <ReservationCompletion')).toBeGreaterThan(controls.indexOf('Simulate reservation</button>'));
    expect(controls).toContain('setCompleted(reservationQuantity === undefined ? null : { state: next, quantity: reservationQuantity })');
    expect(controls).toContain('catch (cause) { setCompleted(null);');
  });
});
