import { afterAll, describe, expect, test } from 'bun:test';
import type { Address, EIP1193Provider, Hex } from 'viem';
import { LiveController, type LiveDependencies } from '../src/live/controller';
import { walletClient, type CampaignSnapshot, type Reader } from '../src/live/chain';
import { hasUnresolved } from '../src/live/actionState';
import type { NetworkId } from '../src/live/pilot';

// The production wallet transport is exercised against an inert EIP-1193 object.
// No real provider, wallet, signature, RPC, browser or financial operation occurs.
const account = '0x1111111111111111111111111111111111111111' as Address;
const campaign = '0x3333333333333333333333333333333333333333' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex;
const deploymentHash = `0x${'55'.repeat(32)}` as Hex;
const terms = { seller: account, sponsor: account, deadline: 2000n };
type Interruption = 'accountsChanged' | 'chainChanged' | 'disconnect' | 'localDisconnect' | 'dispose';
const interruptions: Interruption[] = ['accountsChanged', 'chainChanged', 'disconnect', 'localDisconnect', 'dispose'];
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }
function fixture(action: 'reserve' | 'deploy' = 'reserve', chain: NetworkId = 5042002) {
  let saved: string | null = null; let failSave = false; let realFactoryStarted = false; let expected: any;
  let sendBehavior: (() => Hex | Promise<Hex>) | undefined; let waitBehavior: (() => Promise<any>) | undefined;
  let sendCount = 0; let receiverOkay = true; let receiptWaits = 0;
  const calls: any[] = []; const listeners = new Map<string, () => void>();
  const heldChain = deferred<`0x${string}`>(); const reachedWalletChain = deferred<void>(); const reachedSend = deferred<void>();
  const snapshot: CampaignSnapshot = { chain, block: 100n, timestamp: 1000n, address: campaign, deploymentHash, terms, unitCount: 1n, sponsorFunded: true, finalized: false, succeeded: false, outstanding: 90000n, lifetimeDeposits: 60000n, totalClaimed: 0n, account, balance: 1000000n, allowance: 60000n, credit: 0n, claimed: 0n, allocation: [0n,0n,0n,0n,0n,0n], seats: [] };
  const provider = {
    request(this: unknown, request: any) {
      receiverOkay &&= this === provider;
      calls.push(structuredClone(request));
      if (request.method === 'eth_accounts' || request.method === 'eth_requestAccounts') return Promise.resolve([account]);
      if (request.method === 'eth_chainId') {
        if (realFactoryStarted) { reachedWalletChain.resolve(); return heldChain.promise; }
        return Promise.resolve(`0x${chain.toString(16)}`);
      }
      if (request.method === 'eth_sendTransaction') { sendCount++; reachedSend.resolve(); return sendBehavior ? sendBehavior() : Promise.resolve(hash); }
      throw new Error(`Unexpected inert provider method: ${request.method}`);
    },
    on: (event: string, cb: () => void) => { listeners.set(event, cb); }, removeListener: (event: string) => { listeners.delete(event); },
  } as unknown as EIP1193Provider;
  const storage = { getItem: (_key: string) => saved, setItem: (_key: string, value: string) => { if (failSave) throw new Error('Mock storage denied'); saved = value; } };
  const reader = { getTransactionCount: async () => 7, estimateGas: async (params: any) => { expected = params; return 21000n; }, simulateContract: async () => ({}), readContract: async () => 10000n, waitForTransactionReceipt: async () => { receiptWaits++; return waitBehavior ? waitBehavior() : { status: 'success', transactionHash: hash }; }, getTransaction: async () => ({ hash, from: account, to: expected.to ?? null, input: expected.data, nonce: 7, value: 0n, chainId: chain }) } as unknown as Reader;
  const deps = { readClient: () => reader, walletClient: (...args: Parameters<typeof walletClient>) => { realFactoryStarted = true; return walletClient(...args); }, verifyNetwork: async () => ({ chain, block: 100n, timestamp: 1000n }), verifyCampaign: async () => structuredClone(snapshot) } as LiveDependencies;
  const c = new LiveController(provider, false, storage, deps);
  const interrupt = (mode: Interruption) => { if (mode === 'localDisconnect') c.disconnect(); else if (mode === 'dispose') c.dispose(); else listeners.get(mode)?.(); };
  async function review() { c.selectChain(chain); await c.connect(); if (action !== 'deploy') await c.refresh(deploymentHash); await c.prepare(action, 1n, action === 'deploy' ? terms : undefined); expect(c.getSnapshot().review?.action).toBe(action); }
  return { c, deps, storage, calls, review, interrupt, reachedWalletChain: reachedWalletChain.promise, reachedSend: reachedSend.promise, releaseChain: () => heldChain.resolve(`0x${chain.toString(16)}`), sends: () => sendCount, saved: () => saved, receiverOkay: () => receiverOkay, receiptWaits: () => receiptWaits, failSave: () => { failSave = true; }, onSend: (cb: () => Hex | Promise<Hex>) => { sendBehavior = cb; }, onWait: (cb: () => Promise<any>) => { waitBehavior = cb; } };
}
// The ordinary package test command has no audit preload; fixtures remain inert.
afterAll(() => { const attempts = (globalThis as any).__AUDIT_NETWORK_ATTEMPTS__; if (attempts) expect(attempts).toEqual([]); });

describe('Submission epoch boundary using the production wallet transport, offline only', () => {
  test('every invalidation during viem chain lookup prevents both write and deployment dispatch', async () => {
    for (const action of ['reserve', 'deploy'] as const) for (const mode of interruptions) {
      const f = fixture(action); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain;
      expect(f.sends()).toBe(0); expect(f.c.getSnapshot().receipts[0].status).toBe('awaiting-wallet');
      f.interrupt(mode); f.releaseChain(); await pending;
      const result = f.c.getSnapshot().receipts[0]; expect(f.sends()).toBe(0); expect(f.receiptWaits()).toBe(0); expect(result.status).toBe('cancelled'); expect(result.hash).toBeUndefined(); expect(result.message).toContain('No wallet transaction request was sent'); expect(f.c.getSnapshot().review).toBeUndefined(); expect(f.receiverOkay()).toBe(true);
      // Disposal deliberately prevents a stale instance from writing storage.
      expect(JSON.parse(f.saved()!).pending).toHaveLength(mode === 'dispose' ? 1 : 0);
      await f.c.confirm(); expect(f.sends()).toBe(0);
    }
  });
  test('unchanged context preserves one exact zero-value reviewed dispatch on either chain', async () => {
    for (const action of ['reserve', 'deploy'] as const) for (const chain of [5042, 5042002] as const) {
      const f = fixture(action, chain); await f.review(); const review = f.c.getSnapshot().review!; const pending = f.c.confirm(); await f.reachedWalletChain; f.releaseChain(); await pending;
      expect(f.sends()).toBe(1); expect(f.c.getSnapshot().receipts[0].status).toBe('confirmed'); expect(f.receiverOkay()).toBe(true);
      const sent = f.calls.find(x => x.method === 'eth_sendTransaction').params[0]; expect(sent).toEqual({ from: account, data: review.data, gas: '0x5208', nonce: '0x7', value: '0x0', ...(review.to ? { to: review.to } : {}) });
      expect(f.calls.filter(x => x.method.includes('sendTransaction')).map(x => x.method)).toEqual(['eth_sendTransaction']); expect(JSON.parse(f.saved()!).pending).toHaveLength(0);
    }
  });
  test('post-dispatch interruption plus transport failure stays unknown, even with cancellation-looking error text', async () => {
    for (const mode of interruptions) {
      const f = fixture(); const result = deferred<Hex>(); f.onSend(() => result.promise); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain; f.releaseChain(); await f.reachedSend;
      expect(f.sends()).toBe(1); f.interrupt(mode);
      result.resolve(Promise.reject(Object.assign(new Error('Wallet context changed before submission.'), { name: 'CancelledBeforeDispatchError', code: -32000 })) as never);
      await pending; expect(f.c.getSnapshot().receipts[0].status).toBe('unknown'); expect(hasUnresolved(f.c.getSnapshot().receipts)).toBe(true); expect(f.sends()).toBe(1); expect(JSON.parse(f.saved()!).pending).toHaveLength(1); expect(f.receiptWaits()).toBe(0);
      await f.c.prepare('reserve'); await f.c.confirm(); expect(f.sends()).toBe(1);
    }
  });
  test('a synchronous provider throw after it was invoked cannot become a pre-dispatch cancellation', async () => {
    const f = fixture(); f.onSend(() => { f.interrupt('localDisconnect'); throw new Error('Wallet context changed before submission.'); }); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain; f.releaseChain(); await pending;
    expect(f.sends()).toBe(1); expect(f.c.getSnapshot().receipts[0].status).toBe('unknown'); expect(JSON.parse(f.saved()!).pending).toHaveLength(1); expect(f.receiverOkay()).toBe(true);
  });
  test('a context change after dispatch cannot rewrite a returned hash plus matching receipt as cancellation', async () => {
    for (const mode of interruptions) {
      const f = fixture(); const result = deferred<Hex>(); f.onSend(() => result.promise); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain; f.releaseChain(); await f.reachedSend;
      const before = f.c.getSnapshot().snapshot; f.interrupt(mode); result.resolve(hash); await pending; expect(f.sends()).toBe(1); expect(f.c.getSnapshot().receipts[0].status).toBe('confirmed'); expect(f.c.getSnapshot().receipts[0].hash).toBe(hash); expect(f.c.getSnapshot().snapshot).toBe(mode === 'dispose' ? before : undefined); expect(f.c.getSnapshot().review).toBeUndefined();
    }
  });
  test('pre-dispatch cancellation with cleanup storage failure retains a reload lock and never sends', async () => {
    const f = fixture(); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain; f.failSave(); f.interrupt('localDisconnect'); f.releaseChain(); await pending;
    expect(f.sends()).toBe(0); expect(f.c.getSnapshot().receipts[0].status).toBe('cancelled'); expect(f.c.getSnapshot().storageWarning).toContain('could not be saved'); expect(JSON.parse(f.saved()!).pending).toHaveLength(1);
    const restored = new LiveController(undefined, false, f.storage, f.deps); expect(restored.getSnapshot().receipts[0].status).toBe('unknown'); await restored.prepare('reserve'); expect(restored.getSnapshot().review).toBeUndefined(); expect(f.sends()).toBe(0);
  });
  test('dispose before dispatch keeps the stale instance from overwriting public recovery references', async () => {
    const f = fixture(); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain;
    f.interrupt('dispose'); const saved = f.saved(); f.releaseChain(); await pending;
    expect(f.sends()).toBe(0); expect(f.saved()).toBe(saved); expect(f.c.getSnapshot().receipts[0].status).toBe('cancelled');
    const restored = new LiveController(undefined, false, f.storage, f.deps); expect(restored.getSnapshot().receipts[0].status).toBe('unknown'); expect(hasUnresolved(restored.getSnapshot().receipts)).toBe(true);
  });
  test('post-dispatch failure with lost persistence preserves the original expected call for recovery', async () => {
    const f = fixture(); f.onSend(() => { f.failSave(); f.interrupt('localDisconnect'); throw new Error('Ambiguous inert submission with inaccessible storage'); }); await f.review(); const pending = f.c.confirm(); await f.reachedWalletChain; f.releaseChain(); await pending;
    expect(f.sends()).toBe(1); expect(f.c.getSnapshot().receipts[0].status).toBe('unknown'); const saved = JSON.parse(f.saved()!); expect(saved.pending).toHaveLength(1); expect(saved.pending[0].expected.nonce).toBe(7); expect(saved.pending[0].hash).toBeUndefined();
    const restored = new LiveController(undefined, false, f.storage, f.deps); expect(restored.getSnapshot().receipts[0].status).toBe('unknown'); await restored.prepare('reserve'); expect(restored.getSnapshot().review).toBeUndefined(); expect(f.sends()).toBe(1);
  });
});
