import { describe, expect, test } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import ScenarioPicker from '../src/components/ScenarioPicker';
import ReservationReceipt, { receiptEmphasis } from '../src/components/ReservationReceipt';
import {
  buildScenarioState,
  finalize,
  makeInitialState,
  participantAddr,
  passDeadline,
  reserve,
  SANDBOX_TERMS,
  SCENARIOS,
  simulateClaim,
  type ScenarioId,
} from '../src/simulation/engine';
import { openDemo, receiptFor } from '../src/simulation/presentation';
import type { SimState } from '../src/simulation/types';

// Pure state and server-rendered markup only. These assertions do not exercise
// browser disclosure interaction, CSS layout, announcements, or focus movement.
const wallet = participantAddr(0);
const noop = () => {};
const text = (html: string) => html.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;/g, "'");

function scenario(id: ScenarioId) {
  const preset = SCENARIOS.find(candidate => candidate.id === id);
  if (!preset) throw new Error(`Missing scenario: ${id}`);
  return buildScenarioState(preset);
}

function renderReceipt(state: SimState, compact = false, owner = wallet) {
  return renderToStaticMarkup(<ReservationReceipt state={state} receipt={receiptFor(state, owner)} compact={compact} onClaim={noop} />);
}

function primary(html: string) {
  const match = html.match(/<div class="cr-receipt-total">([\s\S]*?)<\/div>/);
  expect(match).not.toBeNull();
  return text(match![1]);
}

function ledger(html: string) {
  return Object.fromEntries([...html.matchAll(/<dt>([\s\S]*?)<\/dt><dd>([\s\S]*?)<\/dd>/g)]
    .map(([, label, amount]) => [text(label), text(amount)]));
}

function claimButtons(html: string) {
  return [...html.matchAll(/<button\b[^>]*>([\s\S]*?)<\/button>/g)]
    .map(([, copy]) => text(copy))
    .filter(copy => /^Mark .+ USDC claimed$/.test(copy));
}

describe('reservation receipt state hierarchy and SSR markup (not browser tests)', () => {
  test('the default ten-seat round estimates the exact owned-one charge and refund', () => {
    const state = openDemo();
    const receipt = receiptFor(state, wallet);
    expect(state.unitCount).toBe(10);
    expect(receipt).toEqual({
      indices: [0], deposit: 60_000_000n, charge: 45_000_000n, refund: 15_000_000n,
      allocated: 0n, claimed: 0n, outstanding: 0n,
    });
    expect(receiptEmphasis(state, receipt)).toEqual({
      label: 'Estimated final cost', amount: 45_000_000n, state: 'Open · estimate, not final',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Estimated final cost45USDC');
    expect(text(html)).toContain('1 seat · 60 USDC deposited');
    expect(ledger(html)).toMatchObject({
      'Original deposit': '60 USDC',
      'Estimated cost if settled here': '45 USDC',
      'Estimated deposit refund': '15 USDC',
    });
    expect(text(html)).toContain('Estimate assumes 10 seats at the deadline. Deposits stay locked until then.');
    expect(claimButtons(html)).toEqual([]);
  });

  test('an unsettled shortfall emphasizes held deposits, not a zero final cost or a claim', () => {
    const state = openDemo(7);
    const receipt = receiptFor(state, wallet);
    expect(receipt.charge).toBe(0n);
    expect(receiptEmphasis(state, receipt)).toEqual({
      label: 'Deposit held', amount: 60_000_000n, state: 'Funding condition not met',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Deposit held60USDC');
    expect(ledger(html)['Refund if the round fails']).toBe('60 USDC');
    expect(text(html)).toContain('the full deposit becomes claimable after finalization');
    expect(claimButtons(html)).toEqual([]);
  });

  test('settled N7 owns two seats and emphasizes the 120 USDC available credit', () => {
    const state = scenario('n7');
    const receipt = receiptFor(state, wallet);
    expect(state.finalizeResult?.branch).toBe('failure');
    expect(receipt).toEqual({
      indices: [0, 1], deposit: 120_000_000n, charge: 0n, refund: 120_000_000n,
      allocated: 120_000_000n, claimed: 0n, outstanding: 120_000_000n,
    });
    expect(receiptEmphasis(state, receipt)).toEqual({
      label: 'Available to claim', amount: 120_000_000n, state: 'Settled · simulated credit',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Available to claim120USDC');
    expect(text(html)).toContain('2 seats · 120 USDC deposited');
    expect(ledger(html)).toEqual({
      'Original refund allocation': '120 USDC',
      'Original deposit': '120 USDC',
      'Final cost': '0 USDC',
      'Marked claimed': '0 USDC',
      'Still available to claim': '120 USDC',
    });
    expect(claimButtons(html)).toEqual(['Mark 120 USDC claimed']);
    expect(text(html)).toContain('Withdrawal is a separate step. No real funds moved.');
  });

  test('claiming N7 preserves deposit and refund history while making outstanding zero', () => {
    const before = scenario('n7');
    const state = simulateClaim(before, wallet);
    const receipt = receiptFor(state, wallet);
    expect(receipt).toEqual({
      indices: [0, 1], deposit: 120_000_000n, charge: 0n, refund: 120_000_000n,
      allocated: 120_000_000n, claimed: 120_000_000n, outstanding: 0n,
    });
    expect(receiptFor(before, wallet).outstanding).toBe(120_000_000n);
    expect(receiptEmphasis(state, receipt)).toEqual({
      label: 'Marked claimed', amount: 120_000_000n, state: 'Recorded in this simulation',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Marked claimed120USDC');
    expect(ledger(html)).toEqual({
      'Original refund allocation': '120 USDC',
      'Original deposit': '120 USDC',
      'Final cost': '0 USDC',
      'Marked claimed': '120 USDC',
      'Still available to claim': '0 USDC',
    });
    expect(claimButtons(html)).toEqual([]);
    expect(() => simulateClaim(state, wallet)).toThrow('Nothing to claim for this wallet');
  });

  test('a successful claim keeps final cost and original refund distinct from claim history', () => {
    const state = simulateClaim(finalize(passDeadline(openDemo())), wallet);
    expect(receiptEmphasis(state, receiptFor(state, wallet))).toEqual({
      label: 'Marked claimed', amount: 15_000_000n, state: 'Recorded in this simulation',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Marked claimed15USDC');
    expect(ledger(html)).toEqual({
      'Original refund allocation': '15 USDC', 'Original deposit': '60 USDC',
      'Final cost': '45 USDC', 'Marked claimed': '15 USDC', 'Still available to claim': '0 USDC',
    });
    expect(claimButtons(html)).toEqual([]);
  });

  test('N9 keeps six-decimal wallet aggregates rather than rounded average prices', () => {
    const state = scenario('n9');
    const receipt = receiptFor(state, wallet);
    expect(receipt).toMatchObject({
      indices: [0, 1, 2], deposit: 180_000_000n, charge: 155_000_001n,
      refund: 24_999_999n, allocated: 24_999_999n, outstanding: 24_999_999n,
    });
    expect(receiptEmphasis(state, receipt)).toEqual({
      label: 'Available to claim', amount: 24_999_999n, state: 'Settled · simulated credit',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Available to claim24.999999USDC');
    expect(ledger(html)).toMatchObject({
      'Original deposit': '180 USDC', 'Final cost': '155.000001 USDC',
      'Original refund allocation': '24.999999 USDC', 'Still available to claim': '24.999999 USDC',
    });
    expect(claimButtons(html)).toEqual(['Mark 24.999999 USDC claimed']);
    expect(text(html)).toContain('Seat indices: 0, 1, 2.');

    const lastWallet = participantAddr(3);
    expect(receiptFor(state, lastWallet)).toMatchObject({
      indices: [7, 8], charge: 103_333_332n, refund: 16_666_668n,
    });
    const lastHtml = renderReceipt(state, false, lastWallet);
    expect(primary(lastHtml)).toBe('Available to claim16.666668USDC');
    expect(ledger(lastHtml)['Final cost']).toBe('103.333332 USDC');
  });

  for (const count of [7, 10, 12]) {
    test(`N${count} exposes no claim before the deadline or between the deadline and finalization`, () => {
      const open = openDemo(count);
      if (count === 12) {
        expect(receiptEmphasis(open, receiptFor(open, wallet)).state).toBe('Full · waiting for deadline');
        expect(text(renderReceipt(open))).not.toContain('seats · open');
      }
      expect(() => finalize(open)).toThrow('Deadline not yet passed');
      for (const state of [open, passDeadline(open)]) {
        const receipt = receiptFor(state, wallet);
        expect(receipt.allocated).toBe(0n);
        expect(receipt.outstanding).toBe(0n);
        expect(receiptEmphasis(state, receipt).label).not.toBe('Available to claim');
        expect(claimButtons(renderReceipt(state))).toEqual([]);
        expect(() => simulateClaim(state, wallet)).toThrow('Not yet finalized');
      }
      const expired = passDeadline(open);
      expect(receiptEmphasis(expired, receiptFor(expired, wallet)).state).toBe(count >= 8
        ? 'Awaiting finalization'
        : 'Funding condition not met · awaiting finalization');
      const expiredCopy = text(renderReceipt(expired));
      expect(expiredCopy).toContain('The deadline has passed.');
      expect(expiredCopy).toContain('Finalization is still required.');
      expect(expiredCopy).not.toContain('Estimate assumes');
      expect(expiredCopy).not.toContain('If the round fails at the deadline');
    });
  }

  test('never-funded rounds have no imaginary deposit, refund allocation, or claim', () => {
    const open = makeInitialState(SANDBOX_TERMS, false);
    expect(receiptEmphasis(open, receiptFor(open, wallet))).toEqual({
      label: 'Reservations closed', amount: null, state: 'Waiting for sponsor funding',
    });
    for (const state of [open, passDeadline(open)]) {
      expect(receiptFor(state, wallet)).toEqual({
        indices: [], deposit: 0n, charge: null, refund: null,
        allocated: 0n, claimed: 0n, outstanding: 0n,
      });
      const html = renderReceipt(state);
      expect(primary(html)).toBe('Reservations closed');
      expect(text(html)).toContain('No seats reserved yet.');
      expect(ledger(html)['Original deposit']).toBe('0 USDC');
      expect(ledger(html)['Refund if the round fails']).toBe('Not available');
      expect(claimButtons(html)).toEqual([]);
    }
    const settled = finalize(passDeadline(open));
    expect(settled.totalOutstanding).toBe(0n);
    expect(receiptFor(settled, wallet)).toEqual({
      indices: [], deposit: 0n, charge: 0n, refund: 0n,
      allocated: 0n, claimed: 0n, outstanding: 0n,
    });
    expect(receiptEmphasis(settled, receiptFor(settled, wallet))).toEqual({
      label: 'Nothing to claim', amount: 0n, state: 'Settled · no outstanding credit',
    });
    expect(primary(renderReceipt(settled))).toBe('Nothing to claim0USDC');
    expect(text(renderReceipt(settled))).toContain('This example wallet had no deposit to refund.');
    expect(text(renderReceipt(settled))).not.toContain('made the full deposit claimable');
    expect(claimButtons(renderReceipt(settled))).toEqual([]);
  });

  test('an expired never-funded round awaits finalization, not impossible sponsor funding', () => {
    const state = passDeadline(makeInitialState(SANDBOX_TERMS, false));
    expect(receiptEmphasis(state, receiptFor(state, wallet))).toEqual({
      label: 'Reservations closed', amount: null, state: 'Awaiting finalization',
    });
    for (const compact of [false, true]) {
      const html = renderReceipt(state, compact);
      const copy = text(html);
      expect(primary(html)).toBe('Reservations closed');
      expect(copy).toContain('Awaiting finalization');
      expect(copy).toContain('The deadline has passed. Funding conditions were not met. Finalization is still required.');
      expect(copy).toContain('Finalization records credits; withdrawal is a separate step.');
      expect(copy).not.toContain('Waiting for sponsor funding');
      expect(copy).not.toContain('Reservations open only after');
      expect(copy).not.toContain('If the round fails at the deadline');
      expect(claimButtons(html)).toEqual([]);
    }
  });

  test('B=0 rounds stay open without inventing a required sponsor deposit', () => {
    const terms = { ...SANDBOX_TERMS, subsidyPerUnit: 0n, sponsorReserve: 0n };
    let state = makeInitialState(terms, false);
    for (let index = 0; index < 10; index++) state = reserve(state, 1, participantAddr(index));
    expect(state.sponsorFunded).toBe(false);
    expect(state.phase).toBe('Open');
    expect(receiptEmphasis(state, receiptFor(state, wallet))).toEqual({
      label: 'Estimated final cost', amount: 60_000_000n, state: 'Open · estimate, not final',
    });
    const html = renderReceipt(state);
    expect(primary(html)).toBe('Estimated final cost60USDC');
    expect(ledger(html)['Estimated deposit refund']).toBe('0 USDC');
    expect(text(html)).toContain('Estimate assumes 10 seats at the deadline.');
    expect(text(html)).not.toContain('Waiting for sponsor funding');
    expect(text(html)).not.toContain('required sponsor reserve');
    expect(claimButtons(html)).toEqual([]);

    const belowMinimum = reserve(makeInitialState(terms, false), 7, wallet);
    expect(receiptEmphasis(belowMinimum, receiptFor(belowMinimum, wallet))).toEqual({
      label: 'Deposit held', amount: 420_000_000n, state: 'Funding condition not met',
    });
    const belowHtml = renderReceipt(belowMinimum);
    expect(text(belowHtml)).toContain('the full deposit becomes claimable after finalization');
    expect(text(belowHtml)).not.toContain('required sponsor reserve');
  });

  for (const id of ['n8', 'n0'] as const) {
    test(`${id} shows nothing to claim instead of a misleading claimed receipt`, () => {
      const state = scenario(id);
      const receipt = receiptFor(state, wallet);
      expect(receipt.allocated).toBe(0n);
      expect(receipt.claimed).toBe(0n);
      expect(receiptEmphasis(state, receipt)).toEqual({
        label: 'Nothing to claim', amount: 0n, state: 'Settled · no outstanding credit',
      });
      const html = renderReceipt(state);
      expect(primary(html)).toBe('Nothing to claim0USDC');
      expect(ledger(html)['Still available to claim']).toBe('0 USDC');
      expect(claimButtons(html)).toEqual([]);
      expect(() => simulateClaim(state, wallet)).toThrow('Nothing to claim for this wallet');
      if (id === 'n8') {
        expect(state.finalizeResult?.branch).toBe('success');
        expect(ledger(html)['Final cost']).toBe('120 USDC');
        expect(ledger(html)['Original refund allocation']).toBe('0 USDC');
      }
    });
  }

  test('compact mode renders one named receipt and retains claim history in a native disclosure', () => {
    const state = simulateClaim(scenario('n7'), wallet);
    const html = renderReceipt(state, true);
    const aside = html.match(/<aside\b[^>]*>/g) ?? [];
    expect(aside).toHaveLength(1);
    expect(aside[0]).toContain('class="cr-receipt cr-receipt-compact"');
    expect(aside[0]).toContain('aria-labelledby="receipt-title"');
    expect(html.match(/id="receipt-title"/g)).toHaveLength(1);
    expect(html).toMatch(/<h2\b[^>]*id="receipt-title"[^>]*>2 seats · 120 USDC deposited<\/h2>/);
    expect(text(html).match(/Your reservation/g)).toHaveLength(1);
    expect(html.match(/<details\b/g)).toHaveLength(1);
    expect(html.match(/<summary\b/g)).toHaveLength(1);
    const disclosure = html.match(/<details\b([^>]*)>([\s\S]*?)<\/details>/);
    expect(disclosure).not.toBeNull();
    expect(disclosure![1]).not.toMatch(/\bopen(?:\s|=|$)/);
    expect(disclosure![2]).toContain('<summary>View full receipt</summary>');
    expect(ledger(disclosure![2])).toEqual({
      'Original deposit': '120 USDC', 'Final cost': '0 USDC',
      'Original refund allocation': '120 USDC',
      'Marked claimed': '120 USDC', 'Still available to claim': '0 USDC',
    });
    expect(text(disclosure![2])).toContain('Seat indices: 0, 1.');
    expect(text(disclosure![2])).toContain('Deposits cannot be withdrawn early.');
    expect(text(disclosure![2])).toContain('Withdrawal is a separate step. No real funds moved.');
    expect(ledger(html)['Original refund allocation']).toBe('120 USDC');
    expect(text(html)).toContain('Simulation only. No wallet or real transaction.');
    expect(claimButtons(html)).toEqual([]);
  });

  test('compact unsettled receipts keep lockup and separate-claim timing visible', () => {
    const open = renderReceipt(openDemo(), true);
    expect(open.slice(0, open.indexOf('<details'))).toContain('Locked until deadline. Finalize, then claim.');
    const expired = renderReceipt(passDeadline(openDemo()), true);
    expect(expired.slice(0, expired.indexOf('<details'))).toContain('Deadline passed. Finalize before any claim.');
    expect(expired).not.toContain('Locked until deadline');
    expect(renderReceipt(scenario('n7'), true)).not.toContain('cr-receipt-timing');
  });
  test('compact presentation preserves the same primary balance, ledger, and claim actions', () => {
    for (const state of [openDemo(), scenario('n7'), simulateClaim(scenario('n7'), wallet), scenario('n9'), scenario('n8'), scenario('n0')]) {
      const expanded = renderReceipt(state);
      const compact = renderReceipt(state, true);
      expect(primary(compact)).toBe(primary(expanded));
      expect(ledger(compact)).toEqual(ledger(expanded));
      expect(claimButtons(compact)).toEqual(claimButtons(expanded));
    }
  });
});


describe('one-receipt outcome selection and compact history', () => {
  test('the single preset selector immediately precedes the primary receipt result', () => {
    const state = openDemo();
    const html = renderToStaticMarkup(<ReservationReceipt state={state} receipt={receiptFor(state, wallet)} compact onClaim={noop} outcomeControl={<ScenarioPicker activeId={null} onSelect={noop} />} />);
    expect(html.match(/<aside\b/g)).toHaveLength(1); expect(html.match(/<select\b/g)).toHaveLength(1);
    expect(text(html)).toContain('Choose a payment outcome');
    expect(html).toContain('aria-describedby="outcome-help"');
    expect(text(html)).toContain('Replaces this simulation.');
    expect(html.indexOf('</select>')).toBeLessThan(html.indexOf('cr-receipt-total'));
    expect(primary(html)).toBe('Estimated final cost45USDC');
  });
  test('settled compact history preserves original refunds once, inside its disclosure', () => {
    for (const state of [scenario('n7'), simulateClaim(scenario('n7'), wallet), scenario('n8'), scenario('n9')]) {
      const html = renderReceipt(state, true);
      expect(html).not.toContain('cr-refund-summary');
      expect(html.match(/Original refund allocation/g)).toHaveLength(1);
      expect(html.indexOf('Original refund allocation')).toBeGreaterThan(html.indexOf('<details'));
      expect(ledger(html)).toEqual(ledger(renderReceipt(state, false)));
    }
  });
});
