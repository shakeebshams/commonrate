import { describe, expect, test } from 'bun:test';
import type { KeyboardEvent } from 'react';
import { trapDialogTab } from '../src/components/RulesDrawer';

// Pure handler regression with DOM-shaped doubles, not a browser focus test.
function setup(count: number, activeIndex: number, shiftKey = false, key = 'Tab') {
  const focusCalls: number[] = []; let prevented = 0;
  const nodes = Array.from({ length: count }, (_, index) => ({ tabIndex: 0, hidden: false, getClientRects: () => [{}], focus: () => focusCalls.push(index) }));
  const dialog = { querySelectorAll: () => nodes, ownerDocument: { activeElement: nodes[activeIndex] ?? null }, focus: () => focusCalls.push(-1) };
  const event = { key, shiftKey, currentTarget: dialog, preventDefault: () => { prevented += 1; } } as unknown as KeyboardEvent<HTMLDialogElement>;
  return { run: () => trapDialogTab(event), focusCalls, prevented: () => prevented, nodes };
}

describe('Rules dialog boundary handler (mock DOM only)', () => {
  test('single Close button wraps both Tab directions before iframe escape', () => {
    for (const shift of [false, true]) { const f = setup(1, 0, shift); f.run(); expect(f.prevented()).toBe(1); expect(f.focusCalls).toEqual([0]); }
  });
  test('multiple controls wrap at either end but preserve normal interior navigation', () => {
    const forward = setup(3, 2); forward.run(); expect(forward.focusCalls).toEqual([0]); expect(forward.prevented()).toBe(1);
    const backward = setup(3, 0, true); backward.run(); expect(backward.focusCalls).toEqual([2]); expect(backward.prevented()).toBe(1);
    const middle = setup(3, 1); middle.run(); expect(middle.focusCalls).toEqual([]); expect(middle.prevented()).toBe(0);
  });
  test('noncandidate focus returns to the appropriate dialog edge', () => {
    const f = setup(2, -1); f.run(); expect(f.focusCalls).toEqual([0]);
    const b = setup(2, -1, true); b.run(); expect(b.focusCalls).toEqual([1]);
  });
  test('invisible or negative-tabindex controls are skipped, with dialog fallback', () => {
    const f = setup(2, 1); f.nodes[0].hidden = true; f.run(); expect(f.focusCalls).toEqual([1]);
    const empty = setup(1, 0); empty.nodes[0].tabIndex = -1; empty.run(); expect(empty.prevented()).toBe(1); expect(empty.focusCalls).toEqual([-1]);
  });
  test('Escape remains handled by native cancel, not the Tab handler', () => {
    const f = setup(1, 0, false, 'Escape'); f.run(); expect(f.prevented()).toBe(0); expect(f.focusCalls).toEqual([]);
  });
});
