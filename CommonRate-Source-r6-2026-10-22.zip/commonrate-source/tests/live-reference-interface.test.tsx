import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';
import { renderToStaticMarkup } from 'react-dom/server';
import LivePilot, { CampaignAddress } from '../src/live/LivePilot';
import { ReferenceExport, ReferenceImport } from '../src/live/PilotReference';
import { formatCampaignReference } from '../src/live/reference';

const reference = formatCampaignReference({ chain: 5042002, deploymentHash: `0x${'ab'.repeat(32)}` });
describe('Reference and read-first interface structure (SSR/source, not interaction tests)', () => {
  test('reference import renders inert and explicit, with bounded input', () => {
    let calls = 0;
    const html = renderToStaticMarkup(<ReferenceImport blockedReason="" onImport={() => { calls++; }} />);
    expect(calls).toBe(0);
    expect(html).toContain('maxLength="256"');
    expect(html).toContain('Import reference only');
    expect(html).toContain('Importing it makes no request and proves nothing');
    expect(html).toContain('Verify it separately');
    expect(html).not.toContain('href=');
  });
  test('unresolved context has an explanatory import block', () => {
    const html = renderToStaticMarkup(<ReferenceImport blockedReason="Resolve the pending transaction first." onImport={() => { throw new Error('must remain inert'); }} />);
    expect(html).toMatch(/<input[^>]*disabled=""/);
    expect(html).toMatch(/<button[^>]*disabled=""/);
    expect(html).toContain('Resolve the pending transaction first.');
  });
  test('export is a copyable public reference, never an automatically opened URL', () => {
    const html = renderToStaticMarkup(<ReferenceExport reference={reference} />);
    expect(html).toContain(reference);
    expect(html).toContain('readonly=""');
    expect(html).toContain('Copy reference');
    expect(html).toContain('It grants no access to this app');
    expect(html).toContain('not a trusted provider or a delivery guarantee');
    expect(html).not.toContain('href=');
    const source = readFileSync(new URL('../src/live/PilotReference.tsx', import.meta.url), 'utf8');
    expect(source).toContain('await navigator.clipboard.writeText(reference)');
    expect(source).not.toMatch(/fetch\(|localStorage|location\.|eth_requestAccounts|setTimeout/);
  });
  test('read-only verification appears before long risk detail and deployment inputs', () => {
    const html = renderToStaticMarkup(<LivePilot />);
    expect(html.indexOf('Verify / refresh reads')).toBeLessThan(html.indexOf('USDC issuer freezes'));
    expect(html.indexOf('Verify / refresh reads')).toBeLessThan(html.indexOf('Seller public address'));
    expect(html.indexOf('Use a single app window')).toBeLessThan(html.indexOf('Verify / refresh reads'));
    expect(html.indexOf('Withdrawal can fail')).toBeLessThan(html.indexOf('Verify / refresh reads'));
    expect(html).toContain('No new account permission or transaction is requested.');
  });
  test('campaign addresses have an adjacent direct-transfer warning', () => {
    const address = '0x1111111111111111111111111111111111111111';
    const html = renderToStaticMarkup(<CampaignAddress address={address} />);
    expect(html).toContain(address);
    expect(html).toContain('Do not send USDC directly to this campaign/spender address.');
    expect(html).toContain('Direct transfers do not create seats or refundable credits.');
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain('<CampaignAddress address={snapshot.address} />');
    expect(source.match(/<CampaignAddress address={review.campaign} \/>/g)).toHaveLength(2);
    expect(source).toContain('state.storageWarning &&');
    expect(source).toContain('!state.error && !formError && state.notice');
  });
  test('verification uses the displayed draft, never a silently reused old hash', () => {
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain('void controller.refresh(hash)');
    expect(source).not.toContain('hash || state.savedHash');
    expect(source).toContain('const reference = controller.importReference(value); if (reference) { setHash(reference.deploymentHash)');
    expect(source).toContain('disabled={state.busy || unresolved}');
    expect(source).toContain('reviewHeading.current?.focus()');
    expect(source).toContain('reviewOpener.current?.focus()');
  });
});
