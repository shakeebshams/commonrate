import { describe, expect, test } from 'bun:test';
import { createWalletClient, custom, encodeFunctionData, type Address, type EIP1193Provider, type Hex } from 'viem';
import { walletClient as guardedWallet, deploymentData, type CampaignSnapshot, type Reader } from '../src/live/chain';
import { LiveController, actionCall, type LiveDependencies } from '../src/live/controller';
import { hasUnresolved, isRejected, type ActionKind } from '../src/live/actionState';
import { NETWORKS, TOKEN, constructorArgs, type NetworkId } from '../src/live/pilot';
import { ARTIFACT } from '../src/live/verification';

// The unguarded factory is an inert regression fixture only. All guarded
// assertions exercise the actual application factory, never a duplicate fix.
function unguardedWallet(chain: NetworkId, account: Address, provider: EIP1193Provider) {
  return createWalletClient({ chain: NETWORKS[chain], account, transport: custom(provider, { retryCount: 0 }) });
}
const account = '0x1111111111111111111111111111111111111111' as Address;
const campaign = '0x2222222222222222222222222222222222222222' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex;
const deploymentHash = `0x${'55'.repeat(32)}` as Hex;
const errors = [-32601, -32602, -32000, -32004, -32603, -32005, 4001, 4100, 4200, 4900, 4901] as const;
const normalize = (v: unknown) => JSON.parse(JSON.stringify(v, (_k, v) => typeof v === 'bigint' ? `${v}n` : v));
function hasCause(error: any, expected: unknown): boolean { for (let e = error; e; e = e.cause) if (e === expected) return true; return false; }
function providerFixture(chain: NetworkId, code?: number) {
  const calls: any[] = [];
  let possibleSubmissions = 0;
  const error = Object.assign(new Error(`Mock response lost after wallet accepted: ${code}`), { code, data: '0x1234' });
  const provider = { request: async (request: any) => {
    calls.push(normalize(request));
    if (request.method === 'eth_chainId') return `0x${chain.toString(16)}`;
    if (request.method === 'eth_accounts' || request.method === 'eth_requestAccounts') return [account];
    if (request.method === 'eth_sendTransaction' || request.method === 'wallet_sendTransaction') {
      // Count possible acceptance BEFORE throwing. A second submission would be unsafe.
      possibleSubmissions++;
      if (request.method === 'eth_sendTransaction' && code !== undefined) throw error;
      return hash;
    }
    throw new Error(`Unexpected mock method ${request.method}`);
  } } as unknown as EIP1193Provider;
  return { provider, calls, error, possibleSubmissions: () => possibleSubmissions };
}
const terms = { seller: account, sponsor: account, deadline: 2000n };
const actionParams = (action: ActionKind, chain: NetworkId) => ({ ...(action === 'deploy' ? { abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs(terms) } : actionCall(action, campaign, 120000n, 2n)), account, chain: NETWORKS[chain], value: 0n, nonce: 7, gas: 74565n });
const invoke = (wallet: any, action: ActionKind, chain: NetworkId) => action === 'deploy' ? wallet.deployContract(actionParams(action, chain)) : wallet.writeContract(actionParams(action, chain));

describe('Wallet submission allowlist proof, exclusively inert mocks', () => {
  test('unguarded regression: ambiguous -32000 dispatches two submission-method requests', async () => {
    const f = providerFixture(5042002, -32000);
    await invoke(unguardedWallet(5042002, account, f.provider), 'reserve', 5042002);
    expect(f.possibleSubmissions()).toBe(2);
    expect(f.calls.map(x => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction', 'wallet_sendTransaction']);
    expect(f.calls[2].params).toEqual(f.calls[1].params);
  });
  for (const chain of [5042, 5042002] as const) for (const action of ['deploy', 'approveSponsor', 'approveReserve', 'fund', 'reserve', 'finalize', 'claim'] as const) {
    test(`production ${chain} ${action}: success preserves exact review parameters`, async () => {
      const f = providerFixture(chain);
      const result = await invoke(guardedWallet(chain, account, f.provider), action, chain);
      expect(result).toBe(hash); expect(f.possibleSubmissions()).toBe(1);
      expect(f.calls.map(x => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction']);
      const call = action === 'deploy' ? undefined : actionCall(action, campaign, 120000n, 2n);
      expect(f.calls[1].params).toEqual([{ from: account, gas: '0x12345', nonce: '0x7', value: '0x0', data: action === 'deploy' ? deploymentData(terms) : encodeFunctionData(call!), ...(call ? { to: call.address } : {}) }]);
    });
  }
  for (const mode of ['deploy', 'reserve'] as const) for (const code of errors) {
    test(`production ${mode} ${code}: exactly one provider dispatch and original cause`, async () => {
      const f = providerFixture(5042002, code);
      let caught: unknown;
      try { await invoke(guardedWallet(5042002, account, f.provider), mode, 5042002); } catch (e) { caught = e; }
      expect(caught).toBeDefined(); expect(hasCause(caught, f.error)).toBe(true);
      expect(isRejected(caught)).toBe(code === 4001); expect(f.possibleSubmissions()).toBe(1);
      expect(f.calls.map(x => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction']);
    });
  }
  test('wrong chain stops before submission with the restricted transport', async () => {
    const f = providerFixture(5042);
    await expect(invoke(guardedWallet(5042002, account, f.provider), 'reserve', 5042002)).rejects.toThrow('does not match');
    expect(f.possibleSubmissions()).toBe(0); expect(f.calls.map(x => x.method)).toEqual(['eth_chainId']);
  });
  test('wallet namespace and unneeded signing methods fail before reaching the provider', async () => {
    const f = providerFixture(5042002);
    const wallet = guardedWallet(5042002, account, f.provider);
    for (const method of ['wallet_sendTransaction', 'eth_sendRawTransaction', 'eth_signTransaction', 'personal_sign', 'wallet_sendCalls']) {
      await expect(wallet.request({ method, params: [] } as never)).rejects.toThrow('is not supported');
    }
    expect(f.calls).toEqual([]); expect(f.possibleSubmissions()).toBe(0);
  });
});

function controllerFixture(code: number, action: ActionKind) {
  const f = providerFixture(5042002, code);
  let saved: string | null = null;
  const current: CampaignSnapshot = { chain: 5042002, block: 100n, timestamp: 1000n, address: campaign, deploymentHash, terms, unitCount: 1n, sponsorFunded: true, finalized: false, succeeded: false, outstanding: 90000n, lifetimeDeposits: 60000n, totalClaimed: 0n, account, balance: 1000000n, allowance: 60000n, credit: 0n, claimed: 0n, allocation: [0n, 0n, 0n, 0n, 0n, 0n], seats: [] };
  if (action === 'approveReserve') current.allowance = 0n;
  if (action === 'approveSponsor' || action === 'fund') { current.sponsorFunded = false; current.allowance = action === 'fund' ? 30000n : 0n; }
  if (action === 'finalize') current.timestamp = 2001n;
  if (action === 'claim') { current.timestamp = 2001n; current.finalized = true; current.credit = 10000n; }
  const reader = {
    getTransactionCount: async () => 7,
    estimateGas: async () => 74565n,
    simulateContract: async () => ({}),
    readContract: async () => 10000n,
    waitForTransactionReceipt: async () => { throw new Error('No receipt poll should occur after a send error'); },
  } as unknown as Reader;
  const deps = {
    readClient: () => reader,
    walletClient: (chain: NetworkId, account: Address, provider: EIP1193Provider) => guardedWallet(chain, account, provider),
    verifyNetwork: async (_reader: Reader, chain: NetworkId) => ({ chain, block: 100n, timestamp: 1000n }),
    verifyCampaign: async () => current,
  } as unknown as LiveDependencies;
  const storage = { getItem: () => saved, setItem: (_: string, next: string) => { saved = next; } };
  return { ...f, controller: new LiveController(f.provider, false, storage, deps), saved: () => saved };
}

describe('LiveController with the actual application wallet transport restriction', () => {
  for (const action of ['deploy', 'approveSponsor', 'approveReserve', 'fund', 'reserve', 'finalize', 'claim'] as const) for (const code of [-32601, -32602, -32000, -32004]) {
    test(`${action} ambiguous error ${code}: unknown, persisted expected call, locked, no retry/chaining`, async () => {
      const f = controllerFixture(code, action), c = f.controller;
      c.selectChain(5042002); await c.connect(); if (action !== 'deploy') await c.refresh(deploymentHash);
      await c.prepare(action, 1n, action === 'deploy' ? terms : undefined);
      const review = c.getSnapshot().review; expect(review?.action).toBe(action); expect(f.possibleSubmissions()).toBe(0);
      await c.confirm();
      expect(f.possibleSubmissions()).toBe(1);
      expect(f.calls.filter(x => x.method.includes('sendTransaction')).map(x => x.method)).toEqual(['eth_sendTransaction']);
      expect(c.getSnapshot().receipts).toHaveLength(1);
      const receipt = c.getSnapshot().receipts[0]; expect(receipt.status).toBe('unknown'); expect(receipt.hash).toBeUndefined();
      expect(receipt.message).toContain('Check wallet history'); expect(c.getSnapshot().review).toBeUndefined(); expect(hasUnresolved(c.getSnapshot().receipts)).toBe(true);
      const pending = JSON.parse(f.saved()!).pending; expect(pending).toHaveLength(1);
      expect(pending[0].expected).toMatchObject({ account, chain: 5042002, nonce: 7, to: review!.to, data: review!.data });
      await c.confirm(); await c.prepare(action, 1n, action === 'deploy' ? terms : undefined); await c.confirm();
      expect(f.possibleSubmissions()).toBe(1); expect(c.getSnapshot().review).toBeUndefined();
    });
  }
  for (const action of ['deploy', 'reserve'] as const) test(`${action} explicit rejection remains rejected and permits only a fresh review`, async () => {
    const f = controllerFixture(4001, action), c = f.controller;
    c.selectChain(5042002); await c.connect(); if (action !== 'deploy') await c.refresh(deploymentHash);
    await c.prepare(action, 1n, action === 'deploy' ? terms : undefined); await c.confirm();
    expect(f.possibleSubmissions()).toBe(1); expect(c.getSnapshot().receipts[0].status).toBe('rejected'); expect(hasUnresolved(c.getSnapshot().receipts)).toBe(false);
    await c.confirm(); expect(f.possibleSubmissions()).toBe(1);
    await c.prepare(action, 1n, action === 'deploy' ? terms : undefined); expect(c.getSnapshot().review?.action).toBe(action); expect(f.possibleSubmissions()).toBe(1);
  });
});
