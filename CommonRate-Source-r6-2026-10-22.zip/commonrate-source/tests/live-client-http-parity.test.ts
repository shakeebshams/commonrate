import { afterAll, describe, expect, test } from 'bun:test';
import { encodeAbiParameters, encodeFunctionData, encodeFunctionResult, erc20Abi, type Address, type EIP1193Provider, type Hex } from 'viem';
import * as before from './fixtures/broad-clients';
import * as after from '../src/live/chain';
import { actionCall } from '../src/live/controller';
import { isRejected } from '../src/live/actionState';
import { ARTIFACT } from '../src/live/verification';
import { NETWORKS, TOKEN, constructorArgs, type NetworkId } from '../src/live/pilot';

// Real fetch is never invoked. All HTTP and provider requests use in-memory fixtures.
const originalFetch = globalThis.fetch;
let httpResponder: undefined | ((request: any, url: string, init: RequestInit) => Promise<Response>);
globalThis.fetch = (async (input: any, init?: RequestInit) => {
  if (!httpResponder) throw new Error('External network disabled by independent audit');
  return httpResponder(JSON.parse(String(init?.body)), String(input), init!);
}) as typeof fetch;
afterAll(() => { globalThis.fetch = originalFetch; });
const implementations = [before, after];
const account = '0x1111111111111111111111111111111111111111' as Address;
const otherAccount = '0x2222222222222222222222222222222222222222' as Address;
const target = '0x3333333333333333333333333333333333333333' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex;
const blockHash = `0x${'55'.repeat(32)}` as Hex;
const data = encodeFunctionData({ abi: ARTIFACT.abi, functionName: 'reserve', args: [2n] });
const receipt = { transactionHash: hash, transactionIndex: '0x0', blockHash, blockNumber: '0x64', from: account, to: target, cumulativeGasUsed: '0x12345', gasUsed: '0x12345', contractAddress: null, logs: [], logsBloom: `0x${'0'.repeat(512)}`, status: '0x1', effectiveGasPrice: '0x3', type: '0x2' };
const block = { hash: blockHash, number: '0x64', timestamp: '0x3e8', transactions: [hash], parentHash: blockHash, nonce: '0x0', sha3Uncles: hash, logsBloom: receipt.logsBloom, transactionsRoot: hash, stateRoot: hash, receiptsRoot: hash, miner: account, difficulty: '0x0', totalDifficulty: '0x0', extraData: '0x', size: '0x1', gasLimit: '0x1c9c380', gasUsed: '0x12345', baseFeePerGas: '0x1', uncles: [] };
const tx = { hash, from: account, to: target, input: data, value: '0x0', nonce: '0x0', chainId: '0x4cef52', blockHash, blockNumber: '0x64', transactionIndex: '0x0', gas: '0x12345', maxFeePerGas: '0x3', maxPriorityFeePerGas: '0x1', v: '0x0', r: hash, s: hash, type: '0x2' };
const normalize = (v: any) => JSON.parse(JSON.stringify(v, (_k, v) => typeof v === 'bigint' ? `${v}n` : v));
const errorShape = (e: any): any => e ? { name: e.name, message: e.message, shortMessage: e.shortMessage, code: e.code, data: e.data, cause: e.cause ? errorShape(e.cause) : undefined } : undefined;
type Responder = (request: any, count: number) => unknown;
function mock(chain: NetworkId, override?: Responder) {
  const calls: any[] = [], counts: Record<string, number> = {};
  const respond = async (request: any) => {
    calls.push(normalize(request));
    const count = counts[request.method] = (counts[request.method] ?? 0) + 1;
    const custom = override?.(request, count);
    if (custom !== undefined) return custom;
    switch (request.method) {
      case 'eth_chainId': return `0x${chain.toString(16)}`;
      case 'eth_blockNumber': return '0x64';
      case 'eth_getBlockByNumber': return block;
      case 'eth_getCode': return '0x60006000';
      case 'eth_getTransactionByHash': return { ...tx, chainId: `0x${chain.toString(16)}` };
      case 'eth_getTransactionCount': return '0x0';
      case 'eth_getTransactionReceipt': return receipt;
      case 'eth_estimateGas': return '0x12345';
      case 'eth_call': return request.params[0].data === encodeFunctionData({ abi: erc20Abi, functionName: 'decimals' }) ? encodeAbiParameters([{ type: 'uint8' }], [6]) : encodeFunctionResult({ abi: ARTIFACT.abi, functionName: 'reserve', result: 0n });
      case 'eth_sendTransaction': case 'wallet_sendTransaction': return hash;
      default: throw new Error(`Unexpected mocked request: ${request.method}`);
    }
  };
  return { calls, counts, respond, provider: { request: respond } as unknown as EIP1193Provider };
}
async function readTrace(implementation: typeof after, route: 'public' | 'wallet', chain: NetworkId, run: (reader: any) => Promise<unknown>, override?: Responder) {
  const fixture = mock(chain, override), envelopes: any[] = [];
  httpResponder = async (envelope, url, init) => {
    const { id, jsonrpc, ...request } = envelope;
    envelopes.push({ url, method: init.method, contentType: (init.headers as any)['Content-Type'], jsonrpc, request, abortSignal: init.signal instanceof AbortSignal });
    try { return Response.json({ jsonrpc, id, result: await fixture.respond(request) }); }
    catch (error: any) { return Response.json({ jsonrpc, id, error: { code: error.code ?? -32099, message: error.message, data: error.data } }); }
  };
  try {
    const reader = implementation.readClient(chain, route, fixture.provider);
    let result: any, error: any;
    try { result = normalize(await run(reader)); } catch (e) { error = normalize(errorShape(e)); }
    return { result, error, calls: fixture.calls, envelopes };
  } finally { httpResponder = undefined; }
}
async function pairedRead(route: 'public' | 'wallet', chain: NetworkId, run: (reader: any) => Promise<unknown>, override?: Responder) {
  const baseline = await readTrace(before, route, chain, run, override);
  const candidate = await readTrace(after, route, chain, run, override);
  expect(candidate).toEqual(baseline); return candidate;
}
async function pairedWrite(chain: NetworkId, run: (wallet: any) => Promise<unknown>, override?: Responder) {
  const traces: any[] = [];
  for (const implementation of implementations) {
    const f = mock(chain, override);
    try { traces.push({ result: await run(implementation.walletClient(chain, account, f.provider)), calls: f.calls }); }
    catch (e) { traces.push({ error: normalize(errorShape(e)), rejected: isRejected(e), calls: f.calls }); }
  }
  expect(traces[1]).toEqual(traces[0]); return traces[1];
}
const write = { address: target, abi: ARTIFACT.abi, functionName: 'reserve', args: [2n], value: 0n, gas: 74565n, nonce: 0 };
describe('Guarded selective-client semantic parity (offline only)', () => {
  test('all base properties and construction transport settings on both chains and routes', () => {
    for (const chain of [5042, 5042002] as const) for (const route of ['public', 'wallet'] as const) {
      const f = mock(chain), a = before.readClient(chain, route, f.provider), b = after.readClient(chain, route, f.provider);
      for (const key of ['key', 'name', 'type', 'account', 'batch', 'ccipRead', 'dataSuffix', 'tokens', 'cacheTime', 'pollingInterval', 'experimental_blockTag', 'chain']) expect(normalize({ value: (b as any)[key] })).toEqual(normalize({ value: (a as any)[key] }));
      expect(b.chain).toBe(NETWORKS[chain]);
      for (const key of ['retryCount', 'retryDelay', 'timeout', 'key', 'name', 'type', 'url', 'fetchOptions']) expect((b.transport as any)[key]).toEqual((a.transport as any)[key]);
      expect(b.transport.retryCount).toBe(0);
      if (route === 'public') { expect(b.transport.timeout).toBe(15000); expect((b.transport as any).url).toBe(NETWORKS[chain].rpcUrls.default.http[0]); }
      const wa = before.walletClient(chain, account, f.provider), wb = after.walletClient(chain, account, f.provider);
      expect(wb.account).toEqual({ address: account, type: 'json-rpc' });
      for (const key of ['retryCount', 'retryDelay', 'timeout', 'key', 'name', 'type']) expect((wb.transport as any)[key]).toEqual((wa.transport as any)[key]);
      expect(f.calls).toEqual([]);
    }
  });
  test('wallet read without provider fails before any request', () => {
    for (const implementation of implementations) expect(() => implementation.readClient(5042, 'wallet')).toThrow('Connect a wallet before explicitly choosing its RPC for reads.');
  });
  for (const chain of [5042, 5042002] as const) for (const route of ['public', 'wallet'] as const) {
    test(`${chain} ${route} all ten read actions have explicit successful results`, async () => {
      const trace = await pairedRead(route, chain, async reader => ({
        chain: await reader.getChainId(), block: (await reader.getBlock({ blockNumber: 100n })).number,
        code: await reader.getCode({ address: TOKEN, blockNumber: 100n }),
        decimals: await reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'decimals', blockNumber: 100n }),
        transaction: (await reader.getTransaction({ hash })).hash, nonce: await reader.getTransactionCount({ address: account, blockTag: 'pending' }),
        receipt: (await reader.getTransactionReceipt({ hash })).status, gas: await reader.estimateGas({ account, to: target, data, value: 0n }),
        simulated: (await reader.simulateContract({ ...write, account })).request.functionName,
        waited: (await reader.waitForTransactionReceipt({ hash, confirmations: 1, timeout: 1000, retryCount: 0 })).transactionHash,
      }));
      expect(trace.error).toBeUndefined();
      expect(trace.result).toEqual({ chain, block: '100n', code: '0x60006000', decimals: 6, transaction: hash, nonce: 0, receipt: 'success', gas: '74565n', simulated: 'reserve', waited: hash });
      expect(trace.calls).toHaveLength(10);
      if (route === 'public') { expect(trace.envelopes).toHaveLength(10); expect(trace.envelopes.every(e => e.url === new URL(NETWORKS[chain].rpcUrls.default.http[0]).href && e.method === 'POST' && e.contentType === 'application/json' && e.abortSignal)).toBe(true); }
    });
    test(`${chain} ${route} deployment gas estimation omits to and preserves deployment calldata`, async () => {
      const terms = { seller: account, sponsor: otherAccount, deadline: 2000n };
      const trace = await pairedRead(route, chain, reader => reader.estimateGas({ account, data: after.deploymentData(terms), value: 0n }));
      expect(trace.result).toBe('74565n'); expect(trace.error).toBeUndefined();
      expect(trace.calls).toEqual([{ method: 'eth_estimateGas', params: [{ from: account, data: after.deploymentData(terms), value: '0x0' }] }]);
    });
    test(`${chain} ${route} transient read RPC error is not retried`, async () => {
      const trace = await pairedRead(route, chain, reader => reader.getCode({ address: target }), () => { throw Object.assign(new Error('Mock provider unavailable'), { code: -32005 }); });
      expect(trace.error).toBeDefined(); expect(trace.calls).toHaveLength(1);
    });
  }
  for (const chain of [5042, 5042002] as const) for (const mode of ['deploy', 'write'] as const) {
    test(`${chain} ${mode} hoisted account and chain, zero nonce, exact gas and calldata`, async () => {
      const terms = { seller: account, sponsor: otherAccount, deadline: 2000n };
      const trace = await pairedWrite(chain, wallet => mode === 'write' ? wallet.writeContract(write) : wallet.deployContract({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs(terms), gas: 74565n, nonce: 0, value: 0n }));
      expect(trace.error).toBeUndefined(); expect(trace.result).toBe(hash); expect(trace.calls.map((x: any) => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction']);
      expect(trace.calls[1].params[0]).toEqual({ data: mode === 'write' ? data : after.deploymentData(terms), from: account, gas: '0x12345', nonce: '0x0', value: '0x0', ...(mode === 'write' ? { to: target } : {}) });
    });
  }
  test('explicit account override and chain mismatch behavior', async () => {
    const trace = await pairedWrite(5042, wallet => wallet.writeContract({ ...write, account: otherAccount, chain: NETWORKS[5042] }));
    expect(trace.result).toBe(hash); expect(trace.calls[1].params[0].from).toBe(otherAccount);
    const mismatch = await pairedWrite(5042, wallet => wallet.writeContract({ ...write, chain: NETWORKS[5042002] }));
    expect(mismatch.error.name).toBe('ContractFunctionExecutionError'); expect(mismatch.calls.map((x: any) => x.method)).toEqual(['eth_chainId']);
  });
  for (const action of ['approveSponsor', 'approveReserve', 'fund', 'reserve', 'finalize', 'claim'] as const) test(`${action} app call emits exactly one write with matching target/calldata`, async () => {
    const call = actionCall(action, target, 120000n, 2n);
    const trace = await pairedWrite(5042002, wallet => wallet.writeContract({ ...call, account, chain: NETWORKS[5042002], value: 0n, gas: 74565n, nonce: 17 }));
    expect(trace.error).toBeUndefined(); expect(trace.result).toBe(hash); expect(trace.calls.map((x: any) => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction']);
    expect(trace.calls[1].params[0]).toEqual({ data: encodeFunctionData(call), from: account, to: call.address, gas: '0x12345', nonce: '0x11', value: '0x0' });
  });
  for (const code of [4001, 4100, 4200, 4900, 4901, -32603, -32005]) test(`write error ${code} keeps cause/rejection classification without resubmit`, async () => {
    const trace = await pairedWrite(5042002, wallet => wallet.writeContract(write), request => { if (request.method === 'eth_sendTransaction') throw Object.assign(new Error(`Mock error ${code}`), { code, data: '0x1234' }); });
    expect(trace.error).toBeDefined(); expect(trace.rejected).toBe(code === 4001); expect(trace.calls.map((x: any) => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction']);
  });
  for (const code of [-32601, -32602, -32000, -32004]) test(`preserves the one-submission guard for ambiguous error ${code}`, async () => {
    const trace = await pairedWrite(5042002, wallet => wallet.writeContract(write), request => { if (request.method === 'eth_sendTransaction') throw Object.assign(new Error(`Mock error ${code}`), { code }); });
    expect(trace.result).toBeUndefined(); expect(trace.error).toBeDefined();
    expect(trace.calls.map((x: any) => x.method)).toEqual(['eth_chainId', 'eth_sendTransaction']);
    expect(JSON.stringify(trace.error)).toContain(`Mock error ${code}`);
  });
  test('chain lookup rejection cannot reach transaction RPC', async () => {
    const trace = await pairedWrite(5042002, wallet => wallet.writeContract(write), request => { if (request.method === 'eth_chainId') throw Object.assign(new Error('Mock disconnected'), { code: 4900 }); });
    expect(trace.error).toBeDefined(); expect(trace.calls.map((x: any) => x.method)).toEqual(['eth_chainId']);
  });
  test('simulation revert is retained, decoded, and never triggers write', async () => {
    const revertData = `0x08c379a0${encodeAbiParameters([{ type: 'string' }], ['Mock reserve forbidden']).slice(2)}`;
    const trace = await pairedRead('wallet', 5042002, reader => reader.simulateContract({ ...write, account }), request => { if (request.method === 'eth_call') throw Object.assign(new Error('execution reverted'), { code: 3, data: revertData }); });
    expect(trace.error.name).toBe('ContractFunctionExecutionError'); expect(trace.error.message).toContain('Mock reserve forbidden'); expect(trace.calls.map(x => x.method)).toEqual(['eth_call']);
  });
  test('delayed receipt without replacement is polled, not re-submitted', async () => {
    const trace = await pairedRead('wallet', 5042002, reader => reader.waitForTransactionReceipt({ hash, confirmations: 1, pollingInterval: 5, retryCount: 0, timeout: 1000 }), (request, count) => request.method === 'eth_getTransactionReceipt' && count === 1 ? null : undefined);
    expect(trace.error).toBeUndefined(); expect(trace.result.transactionHash).toBe(hash); expect(trace.calls.map(x => x.method)).toEqual(['eth_getTransactionReceipt', 'eth_blockNumber', 'eth_getTransactionByHash', 'eth_getTransactionReceipt']);
  });
  test('three confirmations use omitted watchBlockNumber/getBlockNumber fallbacks', async () => {
    const trace = await pairedRead('wallet', 5042002, reader => reader.waitForTransactionReceipt({ hash, confirmations: 3, pollingInterval: 5, retryCount: 0, timeout: 1000 }), (request, count) => request.method === 'eth_blockNumber' ? `0x${(99 + count).toString(16)}` : undefined);
    expect(trace.error).toBeUndefined(); expect(trace.result.transactionHash).toBe(hash); expect(trace.calls.map(x => x.method)).toEqual(['eth_getTransactionReceipt', 'eth_blockNumber', 'eth_blockNumber', 'eth_blockNumber']);
  });
  test('receipt timeout remains failure and stops polling with no write', async () => {
    const outcomes: any[] = [];
    for (const implementation of implementations) {
      const f = mock(5042002, request => request.method === 'eth_getTransactionReceipt' ? null : undefined);
      const reader = implementation.readClient(5042002, 'wallet', f.provider);
      try { await reader.waitForTransactionReceipt({ hash, checkReplacement: false, pollingInterval: 5, retryCount: 0, timeout: 25 }); throw new Error('Unexpected success'); }
      catch (e: any) { expect(e.name).toBe('WaitForTransactionReceiptTimeoutError'); outcomes.push(normalize(errorShape(e))); }
      expect(f.calls.every(x => ['eth_getTransactionReceipt', 'eth_blockNumber'].includes(x.method))).toBe(true);
      const stopped = f.calls.length; await new Promise(r => setTimeout(r, 20)); expect(f.calls).toHaveLength(stopped);
    }
    expect(outcomes[1]).toEqual(outcomes[0]);
  });
});
