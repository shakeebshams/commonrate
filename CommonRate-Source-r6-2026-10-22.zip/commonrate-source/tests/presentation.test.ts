import { describe, expect, test } from 'bun:test';
import { SANDBOX_TERMS, buildScenarioState, SCENARIOS, participantAddr, passDeadline, finalize, simulateClaim, makeInitialState } from '../src/simulation/engine';
import { formatUSD } from '../src/simulation/math';
import { formatAmount, openDemo, quoteSeats, receiptFor, statusText } from '../src/simulation/presentation';

describe('manual presentation selectors', () => {
  test('default returning example has one exact seat at the current N10', () => {
    const state = openDemo();
    expect(state.unitCount).toBe(10);
    expect(state.finalized).toBe(false);
    expect(receiptFor(state, participantAddr(0))).toMatchObject({ deposit: 60_000_000n, charge: 45_000_000n, refund: 15_000_000n, allocated: 0n });
  });
  test('N9 wallet aggregate sums exact owned indices, not a rounded seat price', () => {
    const state = buildScenarioState(SCENARIOS.find(s => s.id === 'n9')!);
    expect(receiptFor(state, participantAddr(0)).charge).toBe(155_000_001n);
    expect(receiptFor(state, participantAddr(0)).refund).toBe(24_999_999n);
    expect(receiptFor(state, participantAddr(3)).refund).toBe(16_666_668n);
  });
  test('receipt keeps original allocation after claim and clears outstanding', () => {
    let state = finalize(passDeadline(openDemo()));
    state = simulateClaim(state, participantAddr(0));
    expect(receiptFor(state, participantAddr(0))).toMatchObject({ allocated: 15_000_000n, claimed: 15_000_000n, outstanding: 0n, refund: 15_000_000n });
  });
  test('never-funded N0 has no imaginary receipt or sponsor reserve', () => {
    const state = finalize(passDeadline(makeInitialState(SANDBOX_TERMS, false)));
    expect(state.actualReserve).toBe(0n);
    expect(receiptFor(state, participantAddr(0))).toMatchObject({ deposit: 0n, allocated: 0n });
  });
  test('quotes use the sponsor and eligible-funding gates', () => {
    expect(quoteSeats(SANDBOX_TERMS, 7, false)).toBeNull();
    expect(quoteSeats(SANDBOX_TERMS, 10, false)).toBeNull();
    expect(quoteSeats(SANDBOX_TERMS, 7, true)?.every(s => s.charge === 0n && s.refund === 60_000_000n)).toBe(true);
    expect(quoteSeats({ ...SANDBOX_TERMS, minUnits: 1n }, 2, true)?.every(s => s.charge === 0n)).toBe(true);
  });
  test('B0 quote needs no imaginary funded sponsor', () => {
    expect(quoteSeats({ ...SANDBOX_TERMS, subsidyPerUnit: 0n, sponsorReserve: 0n, minUnits: 10n }, 10, false)?.[0].charge).toBe(60_000_000n);
  });
  test('invalid and zero counts have no quotes', () => {
    for (const count of [0, -1, 1.5, NaN, Infinity, 13]) expect(quoteSeats(SANDBOX_TERMS, count, true)).toBeNull();
  });
  test('status and quote are derived from the same count', () => {
    const state = openDemo(7);
    expect(statusText(state)).toBe('1 more seat to reach the minimum.');
    expect(receiptFor(state, participantAddr(0)).refund).toBe(60_000_000n);
  });
  test('display formatting retains meaningful micro-units and large integers', () => {
    expect(formatAmount(51_666_667n)).toBe('51.666667');
    expect(formatAmount(45_000_000n)).toBe('45');
    expect(formatAmount(1n)).toBe('0.000001');
    expect(formatAmount(-1_250_000n)).toBe('-1.25');
    expect(formatUSD(9_007_199_254_740_993_000_001n)).toBe('$9,007,199,254,740,993.00');
    expect(formatUSD(-1_255_000n)).toBe('-$1.26');
  });
});
