import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const icon = readFileSync(new URL('../public/favicon.svg', import.meta.url), 'utf8');

describe('local document identity and metadata', () => {
  test('describes the fixed-fee prototype without promising a real booking', () => {
    expect(html.match(/<title>/g)).toHaveLength(1);
    expect(html).toContain('<title>CommonRate · Share a fixed session fee</title>');
    expect(html).not.toContain('Book it together');
    expect(html).toContain('An experimental conditional group-checkout prototype for sharing a fixed session fee.');
    expect(html).toContain('Explore the Sandbox without a wallet or real money.');
    expect(html).toContain('Arc Studio foundation; manually refined frontend preview');
  });

  test('uses the existing authored mark as a small self-contained SVG favicon', () => {
    expect(html).toContain('<link rel="icon" type="image/svg+xml" href="/favicon.svg" />');
    expect(icon).toContain('viewBox="0 0 32 32"');
    expect(icon).toContain('fill="#f7f8f5"');
    expect(icon).toContain('fill="#214c9d" transform="rotate(-8 16 16)"');
    expect(icon.match(/width="6" height="(?:24|18|12)"/g)).toHaveLength(3);
    expect(icon).not.toMatch(/<(?:script|image|foreignObject)\b|\b(?:href|on\w+)\s*=/i);
    expect(Buffer.byteLength(icon, 'utf8')).toBeLessThan(600);
  });
});
