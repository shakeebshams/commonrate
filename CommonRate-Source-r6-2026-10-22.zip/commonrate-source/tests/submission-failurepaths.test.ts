import { afterAll, describe, expect, test } from 'bun:test';
import type { Address, EIP1193Provider, Hex } from 'viem';
import { LiveController, type LiveDependencies } from '../src/live/controller';
import { hasUnresolved } from '../src/live/actionState';
import { type CampaignSnapshot, type Reader } from '../src/live/chain';
import { formatCampaignReference } from '../src/live/reference';

// New supplemental coverage, in-memory fixtures only. Run with the repository's
// offline network-denial preload. A mocked write records intent; it sends nothing.
const account = '0x1111111111111111111111111111111111111111' as Address;
const other = '0x2222222222222222222222222222222222222222' as Address;
const campaign = '0x3333333333333333333333333333333333333333' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex;
const deploymentHash = `0x${'55'.repeat(32)}` as Hex;
const chain = 5042002 as const;
const terms = { seller: account, sponsor: account, deadline: 2000n };
const tick = () => new Promise(resolve => setTimeout(resolve, 0));
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }
function memory(initial: string | null = null) {
  let value = initial; let failWrites = false; let afterWrite: (() => void) | undefined;
  return { getItem: (_key: string) => value, setItem: (_key: string, next: string) => { if (failWrites) throw new Error('mock storage loss'); value = next; afterWrite?.(); }, value: () => value, replace: (next: string) => { value = next; }, fail: (next: boolean) => { failWrites = next; }, afterWrite: (cb?: () => void) => { afterWrite = cb; } };
}
function fixture(storage = memory()) {
  const requests: string[] = []; const listeners = new Map<string, () => void>();
  let writes = 0; let waitCalls = 0; let verifyCalls = 0; let quote = 10000n;
  let identity: unknown = [account]; let walletChain: unknown = '0x4cef52'; let last: any;
  let onWrite: (() => Promise<Hex>) | undefined;
  let wait: (() => Promise<any>) | undefined;
  let txPatch: Record<string, unknown> = {};
  let verify: (() => Promise<CampaignSnapshot>) | undefined;
  const current: CampaignSnapshot = { chain, block: 100n, timestamp: 1000n, address: campaign, deploymentHash, terms, unitCount: 1n, sponsorFunded: true, finalized: false, succeeded: false, outstanding: 90000n, lifetimeDeposits: 60000n, totalClaimed: 0n, account, balance: 1000000n, allowance: 60000n, credit: 0n, claimed: 0n, allocation: [0n, 0n, 0n, 0n, 0n, 0n], seats: [] };
  const provider = { request: async ({ method }: { method: string }) => { requests.push(method); if (method === 'eth_accounts' || method === 'eth_requestAccounts') return identity; if (method === 'eth_chainId') return walletChain; throw new Error(`Unexpected inert provider request: ${method}`); }, on: (event: string, cb: () => void) => { listeners.set(event, cb); }, removeListener: (event: string) => { listeners.delete(event); } } as unknown as EIP1193Provider;
  const reader = { getTransactionCount: async () => 7, estimateGas: async (params: any) => { last = params; return 21000n; }, simulateContract: async () => ({}), readContract: async () => quote, waitForTransactionReceipt: async () => { waitCalls++; return wait ? wait() : { status: 'success', transactionHash: hash }; }, getTransaction: async () => ({ hash, from: account, to: last?.to ?? campaign, input: last?.data ?? '0x', chainId: chain, nonce: 7, value: 0n, ...txPatch }) } as unknown as Reader;
  const write = async () => { writes++; return onWrite ? onWrite() : hash; };
  const deps = { readClient: () => reader, walletClient: () => ({ deployContract: write, writeContract: write }), verifyNetwork: async () => ({ chain, block: 100n, timestamp: 1000n }), verifyCampaign: async () => { verifyCalls++; return verify ? verify() : structuredClone(current); } } as unknown as LiveDependencies;
  const controller = new LiveController(provider, false, storage, deps);
  return { controller, storage, provider, reader, deps, requests, listeners, current, writes: () => writes, waitCalls: () => waitCalls, verifyCalls: () => verifyCalls, setIdentity: (value: unknown) => { identity = value; }, setWalletChain: (value: unknown) => { walletChain = value; }, setWrite: (value: () => Promise<Hex>) => { onWrite = value; }, setWait: (value: () => Promise<any>) => { wait = value; }, setQuote: (value: bigint) => { quote = value; }, setTransaction: (value: Record<string, unknown>) => { txPatch = value; }, setVerify: (value: () => Promise<CampaignSnapshot>) => { verify = value; } };
}
async function ready(f: ReturnType<typeof fixture>) { f.controller.selectChain(chain); await f.controller.connect(); await f.controller.refresh(deploymentHash); await f.controller.prepare('reserve'); expect(f.controller.getSnapshot().review?.action).toBe('reserve'); }
async function unknown(f: ReturnType<typeof fixture>) { await ready(f); f.setWrite(async () => { throw new Error('ambiguous inert submission'); }); await f.controller.confirm(); expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); }
function restored(f: ReturnType<typeof fixture>) {
  const review = JSON.parse(f.storage.value()!).pending[0].expected;
  const next = fixture(f.storage);
  next.setTransaction({ to: review.to, input: review.data });
  return next;
}
// The ordinary package test command has no audit preload; fixtures remain inert.
afterAll(() => { const attempts = (globalThis as any).__AUDIT_NETWORK_ATTEMPTS__; if (attempts) expect(attempts).toEqual([]); });

describe('Supplemental submission failure paths, offline only', () => {
  test('storage lost only after review stops before any mocked wallet dispatch', async () => {
    const f = fixture(); await ready(f); f.storage.fail(true); await f.controller.confirm();
    expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.controller.getSnapshot().error).toContain('No wallet request was sent');
  });
  test('storage lost after dispatch retains pre-dispatch metadata for manual hash recovery after reload', async () => {
    const f = fixture(); await ready(f);
    f.setWrite(async () => { f.storage.fail(true); return hash; });
    f.setWait(async () => { throw new Error('mock receipt timeout'); });
    await f.controller.confirm(); expect(f.writes()).toBe(1);
    const saved = JSON.parse(f.storage.value()!); expect(saved.pending).toHaveLength(1); expect(saved.pending[0].hash).toBeUndefined(); expect(saved.pending[0].expected.nonce).toBe(7);
    f.controller.dispose(); f.storage.fail(false); const next = restored(f); expect(next.requests).toEqual([]);
    next.controller.attachHash(1, hash); await next.controller.checkReceipt(1);
    expect(next.controller.getSnapshot().receipts[0].status).toBe('confirmed'); expect(JSON.parse(f.storage.value()!).pending).toHaveLength(0); expect(next.writes()).toBe(0); expect(next.requests).toEqual([]);
  });
  test('a terminal receipt with failed persistence cannot silently unlock a new submission', async () => {
    const f = fixture(); await ready(f); f.setWait(async () => { f.storage.fail(true); return { status: 'success', transactionHash: hash }; }); await f.controller.confirm();
    expect(f.controller.getSnapshot().receipts[0].status).toBe('confirmed'); expect(JSON.parse(f.storage.value()!).pending).toHaveLength(1);
    await f.controller.prepare('reserve'); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.writes()).toBe(1); expect(f.controller.getSnapshot().error).toContain('saved request');
    const next = restored(f); expect(next.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(next.requests).toEqual([]);
  });
  test('malformed pending arrays or entries remain blocked and are never rewritten as an empty history', async () => {
    for (const pending of [{}, 'not an array', [null], [false], [{ action: 'unsupported', chain }], [{ chain, account: 'bad', action: 'reserve' }], [{ chain, account, action: 'reserve', hash: '0x1' }]]) {
      const original = JSON.stringify({ chain, pending }); const storage = memory(original); const f = fixture(storage);
      await f.controller.prepare('reserve'); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.writes()).toBe(0); expect(f.requests).toEqual([]); expect(storage.value()).toBe(original);
      expect(f.controller.importReference(formatCampaignReference({ chain, deploymentHash }))).toBeUndefined(); expect(storage.value()).toBe(original);
    }
  });
  test('restoration cap never discards unresolved entries beyond the displayed twenty', async () => {
    const entries = Array.from({ length: 21 }, (_, i) => ({ referenceId: `00000000-0000-0000-0000-${String(i).padStart(12, '0')}`, chain, account, action: 'reserve', amount: '60000', hash }));
    const f = fixture(memory(JSON.stringify({ chain, pending: entries })));
    expect(f.controller.getSnapshot().receipts).toHaveLength(20); f.controller.selectChain(chain);
    expect(JSON.parse(f.storage.value()!).pending).toHaveLength(21); await f.controller.prepare('reserve'); expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().review).toBeUndefined();
  });
  test('reloaded recovery rejects every call-identity mismatch without reconnecting or resubmitting', async () => {
    const original = fixture(); await unknown(original); original.controller.dispose();
    const saved = original.storage.value()!; const expected = JSON.parse(saved).pending[0].expected;
    for (const mismatch of [{ from: other }, { chainId: 5042 }, { nonce: 8 }, { to: other }, { value: 1n }, { input: '0xdeadbeef' }]) {
      const f = fixture(memory(saved)); f.setTransaction({ to: expected.to, input: expected.data, ...mismatch }); f.controller.attachHash(1, hash); await f.controller.checkReceipt(1);
      expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(hasUnresolved(f.controller.getSnapshot().receipts)).toBe(true); expect(JSON.parse(f.storage.value()!).pending).toHaveLength(1); expect(f.requests).toEqual([]); expect(f.writes()).toBe(0);
    }
  });
  test('unsafe restored nonce and calldata metadata never become a matchable recovery call', async () => {
    const f = fixture(); await unknown(f); const baseline = JSON.parse(f.storage.value()!); const details = baseline.pending[0].expected;
    for (const patch of [{ nonce: -1 }, { nonce: 0.5 }, { nonce: Number.MAX_SAFE_INTEGER + 1 }, { nonce: '7' }, { data: '0x' }, { data: '0x1' }, { data: '0xzz' }]) {
      const next = fixture(memory(JSON.stringify({ ...baseline, pending: [{ ...baseline.pending[0], expected: { ...details, ...patch } }] })));
      next.controller.attachHash(1, hash); expect(next.controller.getSnapshot().error).toContain('expected transaction details'); expect(next.controller.getSnapshot().receipts[0].hash).toBeUndefined(); expect(next.requests).toEqual([]); expect(next.writes()).toBe(0);
    }
  });
  test('silent account or chain changes during a late identity read stop confirmation before the wallet', async () => {
    for (const changed of ['account', 'chain'] as const) {
      const f = fixture(); await ready(f); let identities = 0; const original = f.provider.request;
      f.provider.request = (async (request: any) => { if (request.method === 'eth_accounts' && ++identities === 3) { if (changed === 'account') f.setIdentity([other]); else f.setWalletChain('0x13b2'); } return original(request); }) as any;
      await f.controller.confirm(); expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.controller.getSnapshot().error).toContain(changed === 'account' ? 'account changed' : 'network changed');
    }
  });
  test('wallet events or explicit disconnect during confirmation revalidation prevent dispatch', async () => {
    for (const interruption of ['accountsChanged', 'chainChanged', 'disconnect', 'localDisconnect', 'dispose']) {
      const f = fixture(); await ready(f); const hold = deferred<CampaignSnapshot>(); f.setVerify(() => hold.promise);
      const pending = f.controller.confirm(); await tick(); if (interruption === 'localDisconnect') f.controller.disconnect(); else if (interruption === 'dispose') f.controller.dispose(); else f.listeners.get(interruption)?.();
      hold.resolve(f.current); await pending; expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.controller.getSnapshot().error).toContain('changed');
    }
  });
  test('refresh verification failure after a true mocked receipt does not erase receipt success or invent campaign verification', async () => {
    const f = fixture(); await ready(f); f.setWait(async () => { f.setVerify(async () => { throw new Error('mock canonical deployment unavailable'); }); return { status: 'success', transactionHash: hash }; }); await f.controller.confirm();
    expect(f.controller.getSnapshot().receipts[0].status).toBe('confirmed'); expect(f.controller.getSnapshot().snapshot).toBeUndefined(); expect(f.controller.getSnapshot().error).toContain('fresh verification failed'); expect(f.writes()).toBe(1); expect(f.controller.getSnapshot().review).toBeUndefined();
  });
  test('malformed provider identity responses fail before review or any wallet dispatch', async () => {
    for (const accounts of [null, {}, [], ['bad'], [0], { 0: account, length: 1 }]) {
      const f = fixture(); f.controller.selectChain(chain); f.setIdentity(accounts); await f.controller.connect(); await f.controller.prepare('reserve'); expect(f.controller.getSnapshot().account).toBeUndefined(); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.writes()).toBe(0);
    }
  });
});
