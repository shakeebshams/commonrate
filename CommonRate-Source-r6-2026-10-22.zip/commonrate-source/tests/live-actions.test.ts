import { describe, expect, test } from 'bun:test';
import type { Address, EIP1193Provider, Hex } from 'viem';
import { ActionGuard, assertIdentity, canCheckReceipt, hasUnresolved, receiptStatus } from '../src/live/actionState';
import { callMatches, replacementLineageMatches, verifyNetwork, type CampaignSnapshot, type Reader } from '../src/live/chain';
import { LiveController, receiptMayRefresh, validateAction, type LiveDependencies } from '../src/live/controller';
import { PILOT, type NetworkId } from '../src/live/pilot';
import { formatCampaignReference } from '../src/live/reference';
const account = '0x1111111111111111111111111111111111111111' as Address; const campaign = '0x2222222222222222222222222222222222222222' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex; const deploymentHash = `0x${'55'.repeat(32)}` as Hex; const replacementHash = `0x${'66'.repeat(32)}` as Hex;
function snapshot(chain: NetworkId = 5042002): CampaignSnapshot { return { chain, block: 100n, timestamp: 1000n, address: campaign, deploymentHash, terms: { seller: account, sponsor: account, deadline: 2000n }, unitCount: 1n, sponsorFunded: true, finalized: false, succeeded: false, outstanding: 90000n, lifetimeDeposits: 60000n, totalClaimed: 0n, account, balance: 1000000n, allowance: 60000n, credit: 0n, claimed: 0n, allocation: [0n, 0n, 0n, 0n, 0n, 0n], seats: [] }; }
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }
function fixture(options: { embedded?: boolean; storage?: string; reject?: unknown; wait?: Promise<unknown>; wrongTx?: boolean; replacement?: 'repriced' | 'replaced' | 'cancelled'; status?: 'success' | 'reverted'; wrongReplacementNonce?: boolean; wrongOriginal?: boolean; walletHash?: Hex; receiptHash?: Hex; invalidStatus?: unknown; walletResult?: Promise<Hex>; storageFails?: boolean; storageReadbackFails?: boolean; sharedStorage?: { getItem: (key: string) => string | null; setItem: (key: string, value: string) => void } } = {}) {
  const requests: string[] = []; const listeners = new Map<string, () => void>(); let stored = options.storage ?? null; let writes = 0; let txReads = 0; let expectedData: Hex = '0x'; let expectedTo: Address | null = campaign; let chain: NetworkId = 5042002;
  const provider = { request: ({ method }: { method: string }) => { requests.push(method); if (method === 'eth_chainId') return Promise.resolve(`0x${chain.toString(16)}`); return Promise.resolve([account]); }, on: (event: string, cb: () => void) => { listeners.set(event, cb); }, removeListener: (event: string) => { listeners.delete(event); } } as unknown as EIP1193Provider;
  const reader = {
    readContract: ({ args }: { args: [bigint, bigint[]] }) => { const [count, indices] = args; return Promise.resolve(count < 2n ? 60000n * BigInt(indices.length) : indices.reduce((sum, index) => sum + 60000n - (120000n / count + (index < 120000n % count ? 1n : 0n) - 10000n), 0n)); },
    getTransactionCount: () => Promise.resolve(7), estimateGas: ({ data, to }: { data: Hex; to?: Address }) => { expectedData = data; expectedTo = to ?? null; return Promise.resolve(21000n); }, simulateContract: () => Promise.resolve({}),
    waitForTransactionReceipt: (params: { onReplaced: (change: unknown) => void }) => {
      if (options.replacement) params.onReplaced({ reason: options.replacement, replacedTransaction: { hash, from: account, to: expectedTo, input: options.wrongOriginal ? '0xff' : expectedData, value: 0n, chainId: 5042002, nonce: 7 }, transaction: { hash: replacementHash, from: account, to: expectedTo, input: options.replacement === 'repriced' ? expectedData : '0xff', value: 0n, chainId: 5042002, nonce: options.wrongReplacementNonce ? 8 : 7 } });
      return options.wait ?? Promise.resolve({ status: 'invalidStatus' in options ? options.invalidStatus : options.status ?? 'success', transactionHash: options.receiptHash ?? (options.replacement ? replacementHash : hash) });
    },
    getTransaction: () => { txReads++; return Promise.resolve({ from: account, to: expectedTo, input: options.wrongTx ? '0xff' : expectedData, value: 0n, chainId: 5042002, nonce: 7 }); },
  } as unknown as Reader;
  const write = () => { writes++; return options.walletResult ?? (options.reject ? Promise.reject(options.reject) : Promise.resolve(options.walletHash ?? hash)); };
  const deps = { readClient: () => reader, walletClient: () => ({ writeContract: write, deployContract: write }), verifyNetwork: (_reader: Reader, chainId: NetworkId) => Promise.resolve({ chain: chainId, block: 100n, timestamp: 1000n }), verifyCampaign: (_reader: Reader, chainId: NetworkId) => Promise.resolve(snapshot(chainId)) } as unknown as LiveDependencies;
  const storage = options.sharedStorage ?? { getItem: () => options.storageReadbackFails ? null : stored, setItem: (_key: string, value: string) => { if (options.storageFails) throw new Error('Storage blocked'); stored = value; } };
  const controller = new LiveController(provider, options.embedded ?? false, storage, deps);
  return { controller, deps, requests, listeners, storage, setWalletChain: (id: NetworkId) => { chain = id; }, writes: () => writes, txReads: () => txReads, stored: () => stored };
}
async function ready(f: ReturnType<typeof fixture>) { f.controller.selectChain(5042002); await f.controller.connect(); await f.controller.refresh(deploymentHash); }
describe('Live action guards and receipts, all mocked', () => {
  test('constructor, selected mode and network do not query or connect wallet', () => { const f = fixture(); expect(f.requests).toEqual([]); f.controller.selectChain(5042002); expect(f.requests).toEqual([]); });
  test('no-wallet and iframe fail closed without a provider request', async () => {
    const f = fixture({ embedded: true }); f.controller.selectChain(5042002); await f.controller.connect(); expect(f.requests).toEqual([]); expect(f.controller.getSnapshot().error).toContain('embedded');
    const absent = new LiveController(undefined, false); absent.selectChain(5042002); await absent.connect(); expect(absent.getSnapshot().error).toContain('No injected');
  });
  test('Connect alone requests accounts; there is no network switching', async () => { const f = fixture(); await ready(f); expect(f.requests).toEqual(['eth_requestAccounts', 'eth_chainId']); });
  test('account and chain context mismatches invalidate', () => { expect(() => assertIdentity({ account, chain: 5042002 }, [campaign], '0x4cef52')).toThrow('account'); expect(() => assertIdentity({ account, chain: 5042002 }, [account], '0x13b2')).toThrow('network'); });
  test('epoch prevents stale async review and duplicate operations', () => { const guard = new ActionGuard(); const epoch = guard.begin(); expect(() => guard.begin()).toThrow('twice'); guard.invalidate(); expect(() => guard.assert(epoch)).toThrow('changed'); guard.end(); expect(() => guard.begin()).not.toThrow(); });
  test('quantity, sponsor, allowance and onchain deadline gates', () => {
    const s = snapshot(); expect(validateAction('reserve', s, account, 1n)).toBe(PILOT.deposit);
    expect(() => validateAction('reserve', { ...s, sponsorFunded: false }, account, 1n)).toThrow('prefunding');
    expect(() => validateAction('reserve', s, account, 3n)).toThrow('capacity');
    expect(() => validateAction('finalize', { ...s, unitCount: 3n }, account, 1n)).toThrow('deadline');
    expect(() => validateAction('reserve', { ...s, timestamp: 2000n }, account, 1n)).toThrow();
    expect(validateAction('finalize', { ...s, timestamp: 2000n }, account, 1n)).toBe(0n);
    expect(() => validateAction('fund', { ...s, sponsorFunded: false }, campaign, 1n)).toThrow('named sponsor');
    expect(() => validateAction('reserve', { ...s, allowance: 0n }, account, 1n)).toThrow('approval');
    expect(() => validateAction('claim', s, account, 1n)).toThrow('credit');
  });
  test('each write requires a separate review; confirmation checks exact transaction', async () => { const f = fixture(); await ready(f); await f.controller.prepare('reserve', 1n); expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().review?.amount).toBe(60000n); expect(f.controller.getSnapshot().review?.estimate).toEqual({ projectedCount: 2n, indices: [1n], charge: 50000n, refund: 10000n }); await f.controller.confirm(); expect(f.writes()).toBe(1); expect(f.txReads()).toBe(1); expect(f.controller.getSnapshot().receipts[0].status).toBe('confirmed'); expect(f.controller.getSnapshot().review).toBeUndefined(); await f.controller.confirm(); expect(f.writes()).toBe(1); });
  test('wallet rejection is not confirmation and permits fresh review', async () => { const f = fixture({ reject: { code: 4001 } }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm(); expect(f.controller.getSnapshot().receipts[0].status).toBe('rejected'); expect(hasUnresolved(f.controller.getSnapshot().receipts)).toBe(false); });
  test('unknown submission remains locked and persists expected public metadata', async () => { const f = fixture({ reject: new Error('transport lost') }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm(); const r = f.controller.getSnapshot().receipts[0]; expect(r.status).toBe('unknown'); expect(r.hash).toBeUndefined(); expect(f.stored()).toContain('nonce'); expect(f.stored()).not.toContain('privateKey'); await f.controller.prepare('reserve'); expect(f.writes()).toBe(1); expect(f.controller.getSnapshot().review).toBeUndefined(); });
  test('unknown no-hash recovery attaches only a hash and validates before unlock', async () => { const f = fixture({ reject: new Error('no response') }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm(); f.controller.attachHash(1, hash); expect(f.writes()).toBe(1); await f.controller.checkReceipt(1); expect(f.txReads()).toBe(1); expect(f.controller.getSnapshot().receipts[0].status).toBe('confirmed'); });
  test('unrelated recovery hash never resolves the original action', async () => { const f = fixture({ reject: new Error('no response'), wrongTx: true }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm(); f.controller.attachHash(1, hash); await f.controller.checkReceipt(1); expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(hasUnresolved(f.controller.getSnapshot().receipts)).toBe(true); });
  test('restored metadata still requires exact calldata validation and no reconnect', async () => { const original = fixture({ reject: new Error('unknown') }); await ready(original); await original.controller.prepare('reserve'); await original.controller.confirm(); original.controller.attachHash(1, hash); const restored = fixture({ storage: original.stored()!, wrongTx: true }); expect(restored.requests).toEqual([]); await restored.controller.checkReceipt(1); expect(restored.requests).toEqual([]); expect(restored.txReads()).toBe(1); expect(restored.controller.getSnapshot().receipts[0].status).toBe('unknown'); });
  test('missing restored expected metadata cannot create business confirmation', async () => { const saved = JSON.stringify({ chain: 5042002, pending: [{ chain: 5042002, account, action: 'deploy', hash }] }); const f = fixture({ storage: saved }); f.controller.selectChain(5042); await f.controller.checkReceipt(1); expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(f.controller.getSnapshot().chain).toBe(5042); expect(f.controller.getSnapshot().snapshot).toBeUndefined(); expect(f.controller.getSnapshot().savedHash).toBe(''); });
  test('old chain, account and campaign receipt cannot mutate current campaign', () => {
    const record = { id: 1, chain: 5042002 as const, account, action: 'reserve' as const, amount: 1n, hash, status: 'pending' as const, message: '' }; const expected = { chain: 5042002 as const, account, to: campaign, data: '0xab' as Hex, nonce: 7, deploymentHash };
    expect(receiptMayRefresh({ chain: 5042, account, savedHash: deploymentHash }, record, expected)).toBe(false);
    expect(receiptMayRefresh({ chain: 5042002, account, savedHash: replacementHash }, record, expected)).toBe(false);
    expect(receiptMayRefresh({ chain: 5042002, account: campaign, savedHash: deploymentHash }, record, expected)).toBe(false);
    expect(receiptMayRefresh({ chain: 5042002, account, savedHash: deploymentHash }, record, expected)).toBe(true);
  });
  test('stale in-flight review never re-enables after account change', async () => {
    const f = fixture(); await ready(f); const pending = deferred<CampaignSnapshot>(); f.deps.verifyCampaign = () => pending.promise;
    const prepare = f.controller.prepare('reserve'); await new Promise(r => setTimeout(r, 0)); f.listeners.get('accountsChanged')?.(); pending.resolve(snapshot()); await prepare;
    expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.controller.getSnapshot().account).toBeUndefined(); expect(f.writes()).toBe(0);
  });
  test('duplicate confirms while receipt is pending do not submit twice', async () => {
    const wait = deferred<unknown>(); const f = fixture({ wait: wait.promise }); await ready(f); await f.controller.prepare('reserve'); const first = f.controller.confirm(); await new Promise(r => setTimeout(r, 0)); await f.controller.confirm(); expect(f.writes()).toBe(1); wait.resolve({ status: 'success', transactionHash: hash }); await first; expect(f.writes()).toBe(1);
  });
  test('receipt success, revert, replacement and cancellation are distinct', () => {
    expect(receiptStatus('success')).toBe('confirmed'); expect(receiptStatus('reverted')).toBe('reverted'); expect(receiptStatus('success', { reason: 'repriced', callMatches: true, lineageMatches: true })).toBe('confirmed');
    expect(receiptStatus('success', { reason: 'replaced', callMatches: false, lineageMatches: true })).toBe('replaced'); expect(receiptStatus('success', { reason: 'cancelled', callMatches: false, lineageMatches: true })).toBe('cancelled'); expect(receiptStatus('success', { reason: 'repriced', callMatches: false, lineageMatches: true })).toBe('replaced');
  });
  test('replacement match binds account, chain, nonce, target, zero value and calldata', () => {
    const expected = { chain: 5042002 as const, account, to: campaign, data: '0xab' as Hex, nonce: 7 }; const tx = { chainId: 5042002, from: account, to: campaign, input: '0xab' as Hex, nonce: 7, value: 0n };
    expect(callMatches(tx, expected)).toBe(true);
    for (const changed of [{ nonce: 6 }, { chainId: 5042 }, { to: account }, { from: campaign }, { value: 1n }, { input: '0xac' as Hex }]) expect(callMatches({ ...tx, ...changed }, expected)).toBe(false);
  });
});

describe('Additional mocked preflight and receipt lifecycle coverage', () => {
  test('network verification requires actual chain, token code and six decimals', async () => {
    const mock = (chain = 5042002, code = '0x6000', decimals = 6) => ({ getChainId: () => Promise.resolve(chain), getBlock: () => Promise.resolve({ number: 1n, timestamp: 1000n }), getCode: () => Promise.resolve(code), readContract: () => Promise.resolve(decimals) }) as unknown as Reader;
    expect((await verifyNetwork(mock(), 5042002)).timestamp).toBe(1000n);
    await expect(verifyNetwork(mock(5042), 5042002)).rejects.toThrow('wrong chain');
    await expect(verifyNetwork(mock(5042002, '0x'), 5042002)).rejects.toThrow('bytecode');
    await expect(verifyNetwork(mock(5042002, '0x6000', 18), 5042002)).rejects.toThrow('6 decimals');
  });
  test('confirmation reruns verification, and failure never uses cached review', async () => {
    const f = fixture(); await ready(f); await f.controller.prepare('reserve'); f.deps.verifyCampaign = () => Promise.reject(new Error('corrupt runtime'));
    await f.controller.confirm(); expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.controller.getSnapshot().snapshot).toBeUndefined();
  });
  test('onchain state changed after review forces a new review, not a write', async () => {
    const f = fixture(); await ready(f); await f.controller.prepare('reserve'); f.deps.verifyCampaign = () => Promise.resolve({ ...snapshot(), unitCount: 2n });
    await f.controller.confirm(); expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().error).toContain('changed');
  });
  test('repricing uses the replacement hash and keeps the original hash', async () => {
    const f = fixture({ replacement: 'repriced' }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
    const r = f.controller.getSnapshot().receipts[0]; expect(r.status).toBe('confirmed'); expect(r.hash).toBe(replacementHash); expect(r.originalHash).toBe(hash);
  });
  test('cancelled, replaced and reverted receipts never become success', async () => {
    for (const replacement of ['cancelled', 'replaced'] as const) { const f = fixture({ replacement }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm(); expect(f.controller.getSnapshot().receipts[0].status).toBe(replacement); }
    const f = fixture({ status: 'reverted' }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm(); expect(f.controller.getSnapshot().receipts[0].status).toBe('reverted');
  });
  test('receipt timeout is unresolved, never a failed-then-retried action', async () => {
    const pending = deferred<unknown>(); const f = fixture({ wait: pending.promise }); await ready(f); await f.controller.prepare('reserve');
    const submitted = f.controller.confirm(); await new Promise(r => setTimeout(r, 0)); pending.resolve(Promise.reject(new Error('receipt timeout'))); await submitted;
    expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); await f.controller.prepare('reserve'); expect(f.writes()).toBe(1);
  });
  test('claim receipt and original allocations remain after credit becomes zero', async () => {
    const f = fixture(); await ready(f); let claimed = false;
    f.deps.verifyCampaign = () => Promise.resolve({ ...snapshot(), finalized: true, succeeded: true, timestamp: 2001n, credit: claimed ? 0n : 10000n, claimed: claimed ? 10000n : 0n, allocation: [10000n, 0n, 0n, 10000n, claimed ? 10000n : 0n, claimed ? 0n : 10000n] });
    await f.controller.prepare('claim'); await f.controller.confirm(); claimed = true; await f.controller.refresh(deploymentHash);
    expect(f.controller.getSnapshot().snapshot?.credit).toBe(0n); expect(f.controller.getSnapshot().snapshot?.claimed).toBe(10000n); expect(f.controller.getSnapshot().snapshot?.allocation?.[0]).toBe(10000n); expect(f.controller.getSnapshot().receipts[0].status).toBe('confirmed'); expect(f.controller.getSnapshot().receipts[0].amount).toBe(10000n);
  });
});

describe('Replacement lineage recovery regressions', () => {
  test('an unrelated hash replacement or cancellation never resolves original uncertainty', async () => {
    for (const replacement of ['replaced', 'cancelled', 'repriced'] as const) {
      for (const defect of [{ wrongReplacementNonce: true }, { wrongOriginal: true }]) {
        const f = fixture({ replacement, ...defect }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
        expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(hasUnresolved(f.controller.getSnapshot().receipts)).toBe(true);
      }
    }
  });
  test('lineage must bind the original call and replacement chain/account/nonce', () => {
    const expected = { chain: 5042002 as const, account, to: campaign, data: '0xab' as Hex, nonce: 7 }; const original = { chainId: 5042002, from: account, to: campaign, input: '0xab' as Hex, nonce: 7, value: 0n }; const cancelled = { ...original, to: account, input: '0x' as Hex };
    expect(replacementLineageMatches(original, cancelled, expected)).toBe(true);
    expect(replacementLineageMatches({ ...original, input: '0xff' }, cancelled, expected)).toBe(false);
    for (const patch of [{ chainId: 5042 }, { from: campaign }, { nonce: 8 }]) expect(replacementLineageMatches(original, { ...cancelled, ...patch }, expected)).toBe(false);
    expect(receiptStatus('success', { reason: 'cancelled', callMatches: false, lineageMatches: false })).toBe('unknown');
  });
});

describe('Runtime RPC hash validation', () => {
  test('malformed wallet result remains unknown without a displayed hash', async () => {
    const f = fixture({ walletHash: '0x123' }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
    expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(f.controller.getSnapshot().receipts[0].hash).toBeUndefined(); expect(f.txReads()).toBe(0);
  });
  test('a receipt for an unobserved hash never confirms the submitted action', async () => {
    const f = fixture({ receiptHash: replacementHash }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
    expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(f.controller.getSnapshot().receipts[0].hash).toBe(hash); expect(f.txReads()).toBe(0);
  });
});

describe('Fail-closed receipt status validation', () => {
  test('missing or unsupported runtime receipt statuses stay unresolved', async () => {
    for (const invalidStatus of [undefined, null, 'pending', '0x1', 'failed']) {
      const f = fixture({ invalidStatus }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
      expect(f.controller.getSnapshot().receipts[0].status).toBe('unknown'); expect(hasUnresolved(f.controller.getSnapshot().receipts)).toBe(true);
      await f.controller.prepare('reserve'); expect(f.writes()).toBe(1);
    }
  });
});

describe('Mode-exit and storage safety regressions', () => {
  test('failed or unverifiable public persistence prevents the wallet request entirely', async () => {
    for (const fault of [{ storageFails: true }, { storageReadbackFails: true }]) {
      const f = fixture(fault); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
      expect(f.writes()).toBe(0); expect(f.controller.getSnapshot().receipts).toHaveLength(0); expect(f.controller.getSnapshot().error).toContain('No wallet request was sent');
    }
  });
  test('unreadable saved state fails before preparing any new action', async () => { const f = fixture({ storage: '{invalid json' }); await ready(f); await f.controller.prepare('reserve'); expect(f.controller.getSnapshot().review).toBeUndefined(); expect(f.writes()).toBe(0); });
  test('leaving and re-entering while wallet prompt is pending cannot reconnect or duplicate', async () => {
    const wallet = deferred<Hex>(); const old = fixture({ walletResult: wallet.promise }); await ready(old); await old.controller.prepare('reserve'); const submitted = old.controller.confirm(); await new Promise(r => setTimeout(r, 0));
    expect(old.controller.getSnapshot().receipts[0].status).toBe('awaiting-wallet'); old.controller.dispose();
    const reentry = fixture({ storage: old.stored()! }); expect(reentry.requests).toEqual([]); expect(hasUnresolved(reentry.controller.getSnapshot().receipts)).toBe(true);
    await reentry.controller.prepare('reserve'); expect(reentry.writes()).toBe(0); expect(reentry.requests).toEqual([]);
    wallet.resolve(hash); await submitted; expect(old.writes()).toBe(1); expect(reentry.writes()).toBe(0); expect(reentry.controller.getSnapshot().review).toBeUndefined(); expect(JSON.parse(old.stored()!).pending).toHaveLength(1);
  });
  test('leaving and re-entering during receipt wait restores only public unresolved state', async () => {
    const receipt = deferred<unknown>(); const old = fixture({ wait: receipt.promise }); await ready(old); await old.controller.prepare('reserve'); const submitted = old.controller.confirm(); await new Promise(r => setTimeout(r, 0));
    expect(old.controller.getSnapshot().receipts[0].status).toBe('pending'); old.controller.dispose();
    const reentry = fixture({ storage: old.stored()! }); expect(reentry.requests).toEqual([]); expect(reentry.controller.getSnapshot().receipts[0].hash).toBe(hash); expect(reentry.controller.getSnapshot().receipts[0].status).toBe('unknown');
    await reentry.controller.prepare('reserve'); expect(reentry.writes()).toBe(0);
    receipt.resolve({ status: 'success', transactionHash: hash }); await submitted; expect(old.writes()).toBe(1); expect(reentry.writes()).toBe(0); expect(JSON.parse(old.stored()!).pending).toHaveLength(1);
  });
});

describe('Best-effort shared public-reference guard, not an atomic cross-tab lock', () => {
  function shared() { let value: string | null = null; return { getItem: (_key: string) => value, setItem: (_key: string, next: string) => { value = next; } }; }
  test('a stale mounted window preserves foreign pending references and rereads before review', async () => {
    const storage = shared(); const wait = deferred<unknown>(); const first = fixture({ sharedStorage: storage, wait: wait.promise }); const second = fixture({ sharedStorage: storage });
    await ready(first); await ready(second); await first.controller.prepare('reserve'); const submitted = first.controller.confirm(); await new Promise(r => setTimeout(r, 0));
    await ready(second); expect(JSON.parse(storage.getItem('')!).pending).toHaveLength(1); await second.controller.prepare('reserve');
    expect(second.controller.getSnapshot().review).toBeUndefined(); expect(second.controller.getSnapshot().error).toContain('saved request'); expect(second.writes()).toBe(0);
    wait.resolve({ status: 'success', transactionHash: hash }); await submitted;
  });
  test('an old rejected request cannot erase a later request that reuses its nonce and calldata', async () => {
    const storage = shared(); const wait = deferred<unknown>(); const first = fixture({ sharedStorage: storage, reject: { code: 4001 } }); const second = fixture({ sharedStorage: storage, wait: wait.promise });
    await ready(first); await ready(second); await first.controller.prepare('reserve'); await first.controller.confirm(); await second.controller.prepare('reserve'); const submitted = second.controller.confirm(); await new Promise(r => setTimeout(r, 0));
    first.controller.selectChain(5042); expect(JSON.parse(storage.getItem('')!).pending).toHaveLength(1); expect(JSON.parse(storage.getItem('')!).pending[0].hash).toBe(hash);
    wait.resolve({ status: 'success', transactionHash: hash }); await submitted;
  });
  test('a pending request saved after another window prepared is checked again before confirmation', async () => {
    const storage = shared(); const wait = deferred<unknown>(); const first = fixture({ sharedStorage: storage, wait: wait.promise }); const second = fixture({ sharedStorage: storage });
    await ready(first); await ready(second); await first.controller.prepare('reserve'); await second.controller.prepare('reserve'); const submitted = first.controller.confirm(); await new Promise(r => setTimeout(r, 0));
    await second.controller.confirm(); expect(second.writes()).toBe(0); expect(second.controller.getSnapshot().error).toContain('saved request'); expect(JSON.parse(storage.getItem('')!).pending).toHaveLength(1);
    wait.resolve({ status: 'success', transactionHash: hash }); await submitted;
  });
});

describe('Terminal replacement history regression', () => {
  test('only cancelled/replaced terminal histories lose the in-app recheck control', () => {
    for (const status of ['cancelled', 'replaced'] as const) expect(canCheckReceipt({ status, hash: replacementHash })).toBe(false);
    for (const status of ['pending', 'unknown', 'confirmed', 'reverted'] as const) expect(canCheckReceipt({ status, hash })).toBe(true);
    expect(canCheckReceipt({ status: 'unknown' })).toBe(false);
  });
  test('direct recheck of verified cancellation/replacement preserves history without RPC or an unresolved lock', async () => {
    for (const reason of ['cancelled', 'replaced'] as const) {
      const f = fixture(); await ready(f); await f.controller.prepare('reserve'); const review = f.controller.getSnapshot().review!;
      const original = { hash, from: account, to: review.to, input: review.data, value: 0n, chainId: 5042002, nonce: 7 };
      const replacement = { ...original, hash: replacementHash, to: reason === 'cancelled' ? account : review.to, input: reason === 'cancelled' ? '0x' : '0xff' };
      let waits = 0; let reads = 0;
      const reader = f.deps.readClient(5042002, 'public') as unknown as { waitForTransactionReceipt: (params: { onReplaced: (change: unknown) => void }) => Promise<unknown>; getTransaction: () => Promise<unknown> };
      reader.waitForTransactionReceipt = async params => { waits++; if (waits === 1) params.onReplaced({ reason, replacedTransaction: original, transaction: replacement }); return { status: 'success', transactionHash: replacementHash }; };
      reader.getTransaction = async () => { reads++; return replacement; };
      await f.controller.confirm(); const before = f.controller.getSnapshot().receipts[0]; const saved = f.stored(); const requests = [...f.requests];
      expect(before.status).toBe(reason); await f.controller.checkReceipt(before.id);
      expect(f.controller.getSnapshot().receipts[0]).toEqual(before); expect(waits).toBe(1); expect(reads).toBe(0); expect(f.requests).toEqual(requests);
      expect(f.stored()).toBe(saved); expect(JSON.parse(f.stored()!).pending).toHaveLength(0); expect(hasUnresolved(f.controller.getSnapshot().receipts)).toBe(false);
      expect(before.hash).toBe(replacementHash); expect(before.originalHash).toBe(hash); expect(f.writes()).toBe(1);
      await f.controller.prepare('reserve'); expect(f.controller.getSnapshot().review?.action).toBe('reserve'); expect(f.writes()).toBe(1);
    }
  });
});

describe('Explicit untrusted reference import, no automatic requests', () => {
  const reference = formatCampaignReference({ chain: 5042, deploymentHash });
  for (const chain of [5042, 5042002] as const) test(`import on chain ${chain} invalidates old verification and review without requests or persistence`, async () => {
    const reference = formatCampaignReference({ chain, deploymentHash: replacementHash });
    const f = fixture(); await ready(f); await f.controller.prepare('reserve');
    const requests = [...f.requests]; const stored = f.stored();
    f.deps.readClient = () => { throw new Error('Unexpected RPC client creation'); };
    expect(f.controller.importReference(reference)).toEqual({ chain, deploymentHash: replacementHash });
    const state = f.controller.getSnapshot();
    expect(state.chain).toBe(chain); expect(state.route).toBe('public'); expect(state.account).toBeUndefined();
    expect(state.snapshot).toBeUndefined(); expect(state.network).toBeUndefined(); expect(state.review).toBeUndefined();
    expect(state.savedHash).toBe(''); expect(state.notice).toContain('not verified');
    expect(f.requests).toEqual(requests); expect(f.stored()).toBe(stored); expect(f.writes()).toBe(0);
  });
  test('invalid reference leaves the existing verified context intact', async () => {
    const f = fixture(); await ready(f); const before = f.controller.getSnapshot(); const stored = f.stored();
    expect(f.controller.importReference('https://untrusted.example/?rpc=bad')).toBeUndefined();
    expect(f.controller.getSnapshot().snapshot).toBe(before.snapshot); expect(f.controller.getSnapshot().chain).toBe(before.chain);
    expect(f.controller.getSnapshot().savedHash).toBe(before.savedHash); expect(f.stored()).toBe(stored); expect(f.writes()).toBe(0);
    expect(f.controller.getSnapshot().error).toContain('URLs and extra fields');
  });
  test('unknown local requests prevent context changes and preserve recovery metadata', async () => {
    const f = fixture({ reject: new Error('unknown outcome') }); await ready(f); await f.controller.prepare('reserve'); await f.controller.confirm();
    const before = f.controller.getSnapshot(); const stored = f.stored();
    expect(f.controller.importReference(reference)).toBeUndefined();
    expect(f.controller.getSnapshot().chain).toBe(before.chain); expect(f.controller.getSnapshot().savedHash).toBe(before.savedHash);
    expect(f.controller.getSnapshot().receipts).toEqual(before.receipts); expect(f.stored()).toBe(stored);
    expect(f.controller.getSnapshot().error).toContain('pending or unknown'); expect(f.writes()).toBe(1);
  });
  test('foreign or unreadable saved recovery state blocks imports without overwriting storage', () => {
    for (const storage of ['not JSON', JSON.stringify({ pending: [{ unfamiliar: 'unresolved public reference' }] })]) {
      const f = fixture({ storage }); const before = f.controller.getSnapshot();
      expect(f.controller.importReference(reference)).toBeUndefined(); expect(f.stored()).toBe(storage);
      expect(f.controller.getSnapshot().chain).toBe(before.chain); expect(f.requests).toEqual([]); expect(f.writes()).toBe(0);
    }
  });
  test('an in-flight read prevents import without invalidating its original context', async () => {
    const f = fixture(); f.controller.selectChain(5042002); const wait = deferred<ReturnType<typeof snapshot>>();
    f.deps.verifyCampaign = () => wait.promise;
    const refreshing = f.controller.refresh(deploymentHash); await new Promise(resolve => setTimeout(resolve, 0));
    expect(f.controller.getSnapshot().busy).toBe(true); expect(f.controller.importReference(reference)).toBeUndefined();
    expect(f.controller.getSnapshot().chain).toBe(5042002); wait.resolve(snapshot()); await refreshing;
    expect(f.controller.getSnapshot().snapshot?.deploymentHash).toBe(deploymentHash); expect(f.writes()).toBe(0);
  });
});

describe('Current operation feedback and durable storage warnings', () => {
  test('failed verification cannot retain an earlier inert-import assurance', async () => {
    const f = fixture();
    f.controller.importReference(formatCampaignReference({ chain: 5042002, deploymentHash }));
    expect(f.controller.getSnapshot().notice).toContain('No wallet or network request was made');
    f.deps.verifyNetwork = async () => { throw new Error('Wrong chain, mock only'); };
    await f.controller.refresh(deploymentHash);
    expect(f.controller.getSnapshot().error).toContain('Wrong chain');
    expect(f.controller.getSnapshot().notice).toBe('');
    expect(f.controller.getSnapshot().network).toBeUndefined();
    expect(f.controller.getSnapshot().snapshot).toBeUndefined();
    expect(f.requests).toEqual([]); expect(f.writes()).toBe(0);
  });
  test('starting another check clears an old success notice before the pending result', async () => {
    const f = fixture(); await ready(f);
    expect(f.controller.getSnapshot().notice).toContain('provenance verified');
    const waiting = deferred<ReturnType<typeof snapshot>>();
    f.deps.verifyCampaign = () => waiting.promise.then(() => { throw new Error('Unavailable deployment, mock only'); });
    const checking = f.controller.refresh(deploymentHash); await new Promise(resolve => setTimeout(resolve, 0));
    expect(f.controller.getSnapshot().busy).toBe(true); expect(f.controller.getSnapshot().notice).toBe('');
    waiting.resolve(snapshot()); await checking;
    expect(f.controller.getSnapshot().error).toContain('Unavailable deployment');
    expect(f.controller.getSnapshot().notice).toBe(''); expect(f.writes()).toBe(0);
  });
  test('context invalidation removes the old verification notice', async () => {
    const f = fixture(); await ready(f); f.controller.selectRoute('wallet');
    expect(f.controller.getSnapshot().notice).toBe('');
    expect(f.controller.getSnapshot().snapshot).toBeUndefined(); expect(f.writes()).toBe(0);
  });
  test('failed or unreadable storage warnings survive successful and failed read-only checks', async () => {
    for (const options of [{ storageFails: true }, { storage: '{invalid JSON' }]) {
      const f = fixture(options); await ready(f);
      expect(f.controller.getSnapshot().storageWarning).toContain('could not be saved');
      expect(f.controller.getSnapshot().notice).toContain('provenance verified');
      const warning = f.controller.getSnapshot().storageWarning;
      f.deps.verifyNetwork = async () => { throw new Error('Mock network unavailable'); };
      await f.controller.refresh(deploymentHash);
      expect(f.controller.getSnapshot().notice).toBe('');
      expect(f.controller.getSnapshot().storageWarning).toBe(warning);
      expect(f.controller.getSnapshot().error).toContain('network unavailable');
      expect(f.writes()).toBe(0);
    }
  });
  test('a storage warning clears only after successful persistence and readback', () => {
    let fail = true, stored: string | null = null;
    const sharedStorage = { getItem: (_key: string) => stored, setItem: (_key: string, value: string) => { if (fail) throw new Error('Mock storage unavailable'); stored = value; } };
    const f = fixture({ sharedStorage }); f.controller.selectChain(5042002);
    expect(f.controller.getSnapshot().storageWarning).toContain('could not be saved');
    f.controller.invalidate(); expect(f.controller.getSnapshot().storageWarning).not.toBe('');
    fail = false; f.controller.selectChain(5042002);
    expect(f.controller.getSnapshot().storageWarning).toBe('');
    expect(JSON.parse(stored!).chain).toBe(5042002); expect(f.requests).toEqual([]); expect(f.writes()).toBe(0);
  });
});
