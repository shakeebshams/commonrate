import { describe, expect, test } from 'bun:test';
import { encodeAbiParameters, encodeFunctionData, encodeFunctionResult, erc20Abi, type Address, type EIP1193Provider, type Hex } from 'viem';
import * as baseline from './fixtures/broad-clients';
import * as selective from '../src/live/chain';
import { ARTIFACT } from '../src/live/verification';
import { constructorArgs, NETWORKS, TOKEN } from '../src/live/pilot';

// No browser/provider/network is used. Every provider response is a fixed in-memory fixture.
const chain = 5042002;
const account = '0x1111111111111111111111111111111111111111' as Address;
const target = '0x2222222222222222222222222222222222222222' as Address;
const hash = `0x${'33'.repeat(32)}` as Hex;
const replacementHash = `0x${'44'.repeat(32)}` as Hex;
const blockHash = `0x${'55'.repeat(32)}` as Hex;
const data = encodeFunctionData({ abi: ARTIFACT.abi, functionName: 'reserve', args: [1n] });
const tx = { hash, from: account, to: target, input: data, value: '0x0', nonce: '0x7', chainId: '0x4cef52', blockHash, blockNumber: '0x64', transactionIndex: '0x0', gas: '0x5208', gasPrice: '0x1', v: '0x0', r: hash, s: hash, type: '0x0' };
const receipt = { transactionHash: hash, transactionIndex: '0x0', blockHash, blockNumber: '0x64', from: account, to: target, cumulativeGasUsed: '0x5208', gasUsed: '0x5208', contractAddress: null, logs: [], logsBloom: `0x${'0'.repeat(512)}`, status: '0x1', effectiveGasPrice: '0x1', type: '0x0' };
const block = { hash: blockHash, number: '0x64', timestamp: '0x3e8', transactions: [hash], parentHash: blockHash, nonce: '0x0', sha3Uncles: hash, logsBloom: receipt.logsBloom, transactionsRoot: hash, stateRoot: hash, receiptsRoot: hash, miner: account, difficulty: '0x0', totalDifficulty: '0x0', extraData: '0x', size: '0x1', gasLimit: '0x1c9c380', gasUsed: '0x5208', baseFeePerGas: '0x1', uncles: [] };
type Request = { method: string; params?: any };
function fixture(options: { fail?: string; wrongChain?: boolean; replacement?: 'repriced' | 'replaced' | 'cancelled'; reverted?: boolean } = {}) {
  const requests: Request[] = [];
  const replacement = { ...tx, hash: replacementHash, ...(options.replacement === 'cancelled' ? { to: account, input: '0x' } : options.replacement === 'replaced' ? { input: '0x1234' } : {}) };
  const provider = { request: async (request: Request) => {
    requests.push(structuredClone(request));
    if (options.fail === request.method) throw Object.assign(new Error('Mock user rejected request'), { code: 4001 });
    switch (request.method) {
      case 'eth_chainId': return `0x${(options.wrongChain ? 1 : chain).toString(16)}`;
      case 'eth_blockNumber': return '0x64';
      case 'eth_getBlockByNumber': return { ...block, transactions: request.params[1] ? [replacement] : [hash] };
      case 'eth_getCode': return '0x60006000';
      case 'eth_call': return request.params[0].data === encodeFunctionData({ abi: erc20Abi, functionName: 'decimals' }) ? encodeAbiParameters([{ type: 'uint8' }], [6]) : encodeFunctionResult({ abi: ARTIFACT.abi, functionName: 'reserve', result: 0n });
      case 'eth_getTransactionByHash': return options.replacement ? { ...tx, blockHash: null, blockNumber: null, transactionIndex: null } : tx;
      case 'eth_getTransactionCount': return '0x7';
      case 'eth_getTransactionReceipt': return options.replacement && request.params[0] === hash ? null : { ...receipt, transactionHash: request.params[0], status: options.reverted ? '0x0' : '0x1' };
      case 'eth_estimateGas': return '0x5208';
      case 'eth_sendTransaction': return hash;
      default: throw new Error(`Unexpected mock request ${request.method}`);
    }
  } } as unknown as EIP1193Provider;
  return { requests, provider };
}
const serial = (value: unknown) => JSON.stringify(value, (_key, value) => typeof value === 'bigint' ? `${value}n` : value);
async function compareRead(run: (reader: ReturnType<typeof selective.readClient>) => Promise<unknown>, options: Parameters<typeof fixture>[0] = {}) {
  const traces = [];
  for (const implementation of [baseline, selective]) {
    const f = fixture(options); const reader = implementation.readClient(chain, 'wallet', f.provider);
    try { traces.push({ result: serial(await run(reader)), requests: f.requests }); }
    catch (error) { traces.push({ error: { name: (error as Error).name, message: (error as Error).message }, requests: f.requests }); }
  }
  expect(traces[1]).toEqual(traces[0]);
  if (!options.fail) expect(traces[1].error).toBeUndefined();
  return traces[1];
}

describe('selective viem RPC parity against the guarded broad-client baseline', () => {
  test('constructing either client makes zero requests and preserves options', () => {
    for (const route of ['public', 'wallet'] as const) {
      const a = fixture(); const b = fixture();
      const original = baseline.readClient(chain, route, a.provider); const candidate = selective.readClient(chain, route, b.provider);
      for (const key of ['key', 'name', 'type', 'cacheTime', 'pollingInterval', 'chain', 'account']) expect(serial(candidate[key])).toEqual(serial(original[key]));
      for (const key of ['retryCount', 'timeout', 'key', 'name', 'type', 'url']) expect((candidate.transport as any)[key]).toEqual((original.transport as any)[key]);
      expect(a.requests).toEqual([]); expect(b.requests).toEqual([]);
    }
    const a = fixture(); const b = fixture();
    const original = baseline.walletClient(chain, account, a.provider); const candidate = selective.walletClient(chain, account, b.provider);
    for (const key of ['key', 'name', 'type', 'cacheTime', 'pollingInterval', 'chain', 'account']) expect(serial(candidate[key])).toEqual(serial(original[key]));
    expect(a.requests).toEqual([]); expect(b.requests).toEqual([]);
  });
  test('getChainId', async () => { const trace = await compareRead(reader => reader.getChainId()); expect(trace.result).toBe(String(chain)); });
  test('getBlock latest', async () => { await compareRead(reader => reader.getBlock()); });
  test('getBlock pinned', async () => { await compareRead(reader => reader.getBlock({ blockNumber: 100n })); });
  test('getCode pinned', async () => { await compareRead(reader => reader.getCode({ address: TOKEN, blockNumber: 100n })); });
  test('readContract preserves ABI result and pinned block', async () => { const trace = await compareRead(reader => reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'decimals', blockNumber: 100n })); expect(trace.result).toBe('6'); });
  test('getTransaction', async () => { await compareRead(reader => reader.getTransaction({ hash })); });
  test('getTransactionCount pending', async () => { await compareRead(reader => reader.getTransactionCount({ address: account, blockTag: 'pending' })); });
  test('getTransactionReceipt', async () => { await compareRead(reader => reader.getTransactionReceipt({ hash })); });
  test('estimateGas', async () => { await compareRead(reader => reader.estimateGas({ account, to: target, data, value: 0n })); });
  test('simulateContract', async () => { await compareRead(reader => reader.simulateContract({ address: target, account, abi: ARTIFACT.abi, functionName: 'reserve', args: [1n], value: 0n })); });
  test('receipt immediate success', async () => { await compareRead(reader => reader.waitForTransactionReceipt({ hash, confirmations: 1, timeout: 1000, retryCount: 0 })); });
  test('receipt immediate revert remains revert', async () => { const trace = await compareRead(reader => reader.waitForTransactionReceipt({ hash, confirmations: 1, timeout: 1000, retryCount: 0 }), { reverted: true }); expect(trace.result).toContain('reverted'); });
  for (const reason of ['repriced', 'replaced', 'cancelled'] as const) test(`receipt replacement callback: ${reason}`, async () => {
    const trace = await compareRead(async reader => {
      let observed: unknown;
      const receipt = await reader.waitForTransactionReceipt({ hash, confirmations: 1, timeout: 1000, pollingInterval: 10, retryCount: 0, onReplaced: event => { observed = event; } });
      return { receipt, observed };
    }, { replacement: reason });
    expect(trace.result).toContain(`"reason":"${reason}"`);
  });
  test('read failures do not retry', async () => { const trace = await compareRead(reader => reader.getChainId(), { fail: 'eth_chainId' }); expect(trace.requests).toHaveLength(1); expect(trace.error).toBeDefined(); });
  for (const mode of ['deploy', 'write'] as const) for (const scenario of ['success', 'rejection', 'wrong-chain'] as const) test(`${mode} ${scenario} mocked request parity`, async () => {
    const traces = [];
    for (const implementation of [baseline, selective]) {
      const f = fixture({ fail: scenario === 'rejection' ? 'eth_sendTransaction' : undefined, wrongChain: scenario === 'wrong-chain' });
      const wallet = implementation.walletClient(chain, account, f.provider);
      try {
        const result = mode === 'deploy'
          ? await wallet.deployContract({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs({ seller: account, sponsor: account, deadline: 2000n }), account, chain: NETWORKS[chain], value: 0n, gas: 21000n, nonce: 7 })
          : await wallet.writeContract({ address: target, abi: ARTIFACT.abi, functionName: 'reserve', args: [1n], account, chain: NETWORKS[chain], value: 0n, gas: 21000n, nonce: 7 });
        traces.push({ result, requests: f.requests });
      } catch (error) { traces.push({ error: { name: (error as Error).name, message: (error as Error).message }, requests: f.requests }); }
    }
    expect(traces[1]).toEqual(traces[0]);
    expect(traces[1].requests.map(request => request.method)).toEqual(scenario === 'wrong-chain' ? ['eth_chainId'] : ['eth_chainId', 'eth_sendTransaction']);
    if (scenario !== 'wrong-chain') {
      const sent = traces[1].requests[1].params[0];
      expect(sent.from).toBe(account); expect(sent.chainId).toBeUndefined(); // viem checks eth_chainId first, then omits chainId from eth_sendTransaction in both implementations.
      expect(sent.value).toBe('0x0'); expect(sent.nonce).toBe('0x7'); expect(sent.gas).toBe('0x5208');
      if (mode === 'write') { expect(sent.to).toBe(target); expect(sent.data).toBe(data); }
      else { expect(sent.to).toBeUndefined(); expect(sent.data).toBe(selective.deploymentData({ seller: account, sponsor: account, deadline: 2000n })); }
    }
  });
});
