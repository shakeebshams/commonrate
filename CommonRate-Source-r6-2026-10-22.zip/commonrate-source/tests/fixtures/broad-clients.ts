// Test-only broad-decorator baseline, copied from the reviewed export18 factories.
// Never imported by application source. The same wallet allowlist is intentional.
import { createPublicClient, createWalletClient, custom, http, type Address, type EIP1193Provider } from 'viem';
import { NETWORKS, requireCondition, type NetworkId } from '../../src/live/pilot';

export type ReadRoute = 'public' | 'wallet';
export function readClient(chain: NetworkId, route: ReadRoute, provider?: EIP1193Provider) {
  requireCondition(route !== 'wallet' || provider, 'Connect a wallet before explicitly choosing its RPC for reads.');
  return createPublicClient({ chain: NETWORKS[chain], transport: route === 'wallet' && provider ? custom(provider, { retryCount: 0 }) : http(NETWORKS[chain].rpcUrls.default.http[0], { retryCount: 0, timeout: 15000 }) });
}
export type Reader = ReturnType<typeof readClient>;
export function walletClient(chain: NetworkId, account: Address, provider: EIP1193Provider) {
  // viem may otherwise fall back to wallet_sendTransaction after an ambiguous
  // eth_sendTransaction error. Only one submission method may reach the wallet.
  return createWalletClient({ chain: NETWORKS[chain], account, transport: custom(provider, {
    retryCount: 0, methods: { include: ['eth_chainId', 'eth_sendTransaction'] },
  }) });
}
