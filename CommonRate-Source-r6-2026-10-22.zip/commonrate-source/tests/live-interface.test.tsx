import { describe, expect, test } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { readFileSync } from 'node:fs';
import LivePilot, { deploymentDraftMatches } from '../src/live/LivePilot';
const plain = (html: string) => html.replace(/<[^>]+>/g, '').replace(/&#x27;/g, "'");
describe('Live server-rendered safety and standalone copy (not browser QA)', () => {
  test('never implies audit or real pilot transaction has occurred', () => {
    const copy = plain(renderToStaticMarkup(<LivePilot />));
    expect(copy).toContain('Experimental and unaudited'); expect(copy).toContain('not a real sale'); expect(copy).toContain('0.150000 USDC'); expect(copy).toContain('0.210000 USDC'); expect(copy).toContain('No pre-deadline cancellation'); expect(copy).toContain('same USDC'); expect(copy).toContain('Use a single app window');
    expect(copy).not.toContain('Transaction receipts'); expect(copy).not.toContain('Verified tiny campaign');
  });
  test('SSR/no-window is fail-closed, no-wallet and no preselected network', () => {
    const html = renderToStaticMarkup(<LivePilot />); const copy = plain(html);
    expect(copy).toContain('Open the deployed app directly'); expect(copy).toContain('No injected wallet detected'); expect(html).toContain('<option value="" selected="">Choose a network');
    expect(html).toMatch(/<button[^>]*disabled=""[^>]*>Connect wallet/);
    expect(copy).toContain('Deployment transaction hash'); expect(html).toContain('not an address');
  });
  test('no inherited diagnostics, auto-reconnect provider or signing effects', () => {
    for (const file of ['LivePilot.tsx', 'controller.ts', 'chain.ts']) {
      const source = readFileSync(new URL(`../src/live/${file}`, import.meta.url), 'utf8');
      expect(source).not.toMatch(/tracing|console-capture|wagmi|connectkit|privateKey|eth_sendRawTransaction|wallet_switchEthereumChain/);
    }
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain('useEffect(() => () => controller.dispose(), [controller])');
    expect(source).toContain('{canCheckReceipt(receipt) && <button');
  });

  test('hash synchronization is a nonempty form-only transition, not an implicit verification (source guard)', () => {
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain('const [hash, setHash] = useState(state.savedHash)');
    expect(source).toContain('const [observedSavedHash, setObservedSavedHash] = useState(state.savedHash)');
    // Keeping this guard narrow prevents unchanged saved hashes from
    // overwriting manual edits whenever busy, notice, account or review changes.
    expect(source).toMatch(/if \(state\.savedHash !== observedSavedHash\) \{\s*setObservedSavedHash\(state\.savedHash\);\s*if \(state\.savedHash\) setHash\(state\.savedHash\);\s*\}/);
  });

  test('explicit draft editing, import, network clearing and pending locks remain wired (source guard)', () => {
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain("setHash(''); setActivity('check'); controller.selectChain");
    expect(source).toContain('setHash(event.target.value); changed(); controller.invalidate();');
    expect(source).toContain('setHash(reference.deploymentHash);');
    expect(source).toMatch(/value=\{hash\}[^\n]*disabled=\{state\.busy \|\| unresolved\}/);
    expect(source).toContain('void controller.refresh(hash);');
  });

  test('draft identity uses the same trimming and hash validation as explicit verification', () => {
    const hash = `0x${'ab'.repeat(32)}`;
    expect(deploymentDraftMatches(hash, hash)).toBe(true);
    expect(deploymentDraftMatches(`  0x${'AB'.repeat(32)}\n`, hash)).toBe(true);
    for (const draft of ['', ' ', `0x${'12'.repeat(32)}`, `0x${'ab'.repeat(20)}`, `0X${'AB'.repeat(32)}`, `0x${'ab'.repeat(31)}az`, `${hash}0`, ` ${hash.slice(0, 32)} ${hash.slice(32)}`]) {
      expect(deploymentDraftMatches(draft, hash)).toBe(false);
    }
  });

  test('a restored campaign cannot enable review while a different lookup draft remains (source guard)', () => {
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain('const draftMismatch = !!snapshot && !deploymentDraftMatches(hash, snapshot.deploymentHash)');
    expect(source).toContain('const campaignBlocked = walletBlocked || !snapshot || draftMismatch');
    expect(source.match(/disabled=\{campaignBlocked\}/g)).toHaveLength(5);
    expect(source).toContain('disabled={campaignBlocked || !snapshot.credit}');
    expect(source).toContain("(state.review.action !== 'deploy' && draftMismatch)");
    expect(source).toContain('The lookup entry differs from this verified pilot.');
    expect(source).toContain('disabled={state.busy || unresolved} onClick={() => { setHash(snapshot.deploymentHash); changed(); }}');
    expect(source).toContain("Use this pilot's hash");
  });
});
