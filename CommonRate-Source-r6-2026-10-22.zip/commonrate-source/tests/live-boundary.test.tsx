import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';
import { lazy, Suspense } from 'react';
import { renderToPipeableStream, renderToStaticMarkup } from 'react-dom/server';
import LiveBoundary from '../src/components/LiveBoundary';

describe('Optional Live view failure boundary (unit/SSR, not browser QA)', () => {
  test('healthy children are returned unchanged', () => {
    expect(renderToStaticMarkup(<LiveBoundary onReturn={() => {}}><p>Optional view</p></LiveBoundary>)).toBe('<p>Optional view</p>');
  });

  test('failed view preserves an explicit escape and does not promise cancellation', () => {
    const boundary = new LiveBoundary({ onReturn: () => {}, children: <p>Optional view</p> });
    boundary.state = LiveBoundary.getDerivedStateFromError();
    const html = renderToStaticMarkup(boundary.render());
    expect(html).toContain('role="alert"');
    expect(html).toContain('Return to Sandbox');
    expect(html).toContain('saved transaction references have not been cleared');
    expect(html).toContain('does not cancel a transaction');
    expect(html).not.toContain('Optional view');
  });

  test('the boundary encloses the lazy load and no automatic reload or retry', () => {
    const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
    const boundary = readFileSync(new URL('../src/components/LiveBoundary.tsx', import.meta.url), 'utf8');
    expect(app).toContain('<LiveBoundary onReturn={() => switchMode(\'sandbox\')}><Suspense');
    expect(app).toContain('</Suspense></LiveBoundary>');
    expect(boundary).not.toMatch(/location\.(?:reload|assign)|localStorage|setTimeout|fetch\(/);
  });

  test('a real React.lazy rejected loader is cached, so remounting is not advertised as retry', async () => {
    let attempts = 0;
    const unavailable = new Error('Simulated optional module load failure');
    const Optional = lazy(() => { attempts++; return Promise.reject(unavailable); });
    const render = () => new Promise<unknown[]>(resolve => {
      const errors: unknown[] = [];
      const stream = renderToPipeableStream(<Suspense fallback={<p>Loading</p>}><Optional /></Suspense>, {
        onError: error => { errors.push(error); },
        onAllReady: () => { stream.abort(); resolve(errors); },
      });
    });
    expect(await render()).toContain(unavailable);
    expect(await render()).toContain(unavailable);
    expect(attempts).toBe(1);
    // Streaming SSR exercises the real lazy rejection/cache, not browser focus
    // or client error-boundary catching. Those remain rendered QA checks.
  });
});
