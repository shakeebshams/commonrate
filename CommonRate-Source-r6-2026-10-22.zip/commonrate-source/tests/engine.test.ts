/**
 * CommonRate simulation engine regression tests.
 * Pure BigInt arithmetic — no browser, no wallet, no network.
 * Run with: bun test tests/engine.test.ts
 */

import { describe, test, expect } from 'bun:test';
import {
  SANDBOX_TERMS,
  SANDBOX_SELLER,
  SANDBOX_SPONSOR,
  makeInitialState,
  fundSponsor,
  reserve,
  passDeadline,
  finalize,
  simulateClaim,
  buildScenarioState,
  SCENARIOS,
  participantAddr,
} from '../src/simulation/engine';
import {
  computeSuccessSeats,
  computeFailureSeats,
  previewAllocation,
} from '../src/simulation/math';

// ── Helpers ───────────────────────────────────────────────────────────────────

function finalizeScenario(N: number, sponsored = true) {
  let s = makeInitialState(SANDBOX_TERMS, sponsored);
  if (sponsored && N > 0) s = reserve(s, N, participantAddr(0));
  s = passDeadline(s);
  return finalize(s);
}

// ── Test: conservation N=0..12 ────────────────────────────────────────────────

describe('Conservation N=0..12', () => {
  for (let N = 0; N <= 12; N++) {
    test(`N=${N} conservation`, () => {
      const s = finalizeScenario(N);
      const { finalizeResult, terms, actualReserve } = s;
      if (!finalizeResult) throw new Error('no result');

      const liabilities = BigInt(N) * terms.depositPerUnit + actualReserve;
      expect(finalizeResult.totalCredit).toBe(liabilities);
      expect(s.totalOutstanding).toBe(liabilities);

      if (finalizeResult.branch === 'success') {
        // seller credit == C
        const walletCredits = finalizeResult.walletCredits;
        expect(walletCredits[SANDBOX_SELLER]).toBe(terms.cost);
        // sponsor credit == S - N*B
        const expSponsor = terms.sponsorReserve - BigInt(N) * terms.subsidyPerUnit;
        expect(walletCredits[SANDBOX_SPONSOR] ?? 0n).toBe(expSponsor);
        // total credits sum == N*A + S
        const total = Object.values(walletCredits).reduce((a, b) => a + b, 0n);
        expect(total).toBe(BigInt(N) * terms.depositPerUnit + actualReserve);
      } else {
        // failure: seller gets 0
        expect(finalizeResult.sellerCredit).toBe(0n);
        // sponsor gets actualReserve
        const walletCredits = finalizeResult.walletCredits;
        if (actualReserve > 0n) {
          expect(walletCredits[SANDBOX_SPONSOR]).toBe(actualReserve);
        }
        // buyer gets A each
        const buyerAddr = N > 0 ? participantAddr(0) : null;
        if (buyerAddr) {
          expect(walletCredits[buyerAddr]).toBe(BigInt(N) * terms.depositPerUnit);
        }
      }
    });
  }
});

// ── Test: N=9 exact per-seat rounding ────────────────────────────────────────

describe('N=9 exact rounding', () => {
  const C = 600_000_000n;
  const B = 15_000_000n;
  const A = 60_000_000n;
  const q = C / 9n; // 66_666_666n
  const r = C % 9n; // 6n

  test('q=66_666_666, r=6', () => {
    expect(q).toBe(66_666_666n);
    expect(r).toBe(6n);
  });

  test('per-seat gross/charge/refund independent computation', () => {
    const seats = computeSuccessSeats(SANDBOX_TERMS, 9);
    // seats 0..5 (i < r=6): gross=66_666_667
    for (let i = 0; i < 6; i++) {
      expect(seats[i].gross).toBe(66_666_667n);
      expect(seats[i].charge).toBe(66_666_667n - B);  // 51_666_667
      expect(seats[i].refund).toBe(A - (66_666_667n - B)); // 8_333_333
    }
    // seats 6..8 (i >= r=6): gross=66_666_666
    for (let i = 6; i < 9; i++) {
      expect(seats[i].gross).toBe(66_666_666n);
      expect(seats[i].charge).toBe(66_666_666n - B);  // 51_666_666
      expect(seats[i].refund).toBe(A - (66_666_666n - B)); // 8_333_334
    }
  });

  test('sum gross == C', () => {
    const seats = computeSuccessSeats(SANDBOX_TERMS, 9);
    const sumGross = seats.reduce((s, seat) => s + seat.gross, 0n);
    expect(sumGross).toBe(C);
  });

  test('wallet sum is exact, not average*count', () => {
    const seats = computeSuccessSeats(SANDBOX_TERMS, 9);
    // All 9 seats owned by one wallet
    const totalRefund = seats.reduce((s, seat) => s + seat.refund, 0n);
    // 6 * 8_333_333 + 3 * 8_333_334 = 49_999_998 + 25_000_002 = 75_000_000
    expect(totalRefund).toBe(75_000_000n);
    // Wrong average-based calculation would give 9 * 8_333_333 = 74_999_997
    expect(totalRefund).not.toBe(9n * 8_333_333n);
  });
});

// ── Test: invalid reserve quantities ─────────────────────────────────────────

describe('reserve validation', () => {
  let s = makeInitialState(SANDBOX_TERMS, true);

  test('rejects zero', () => {
    expect(() => reserve(s, 0, 'w')).toThrow('at least 1');
  });

  test('rejects negative', () => {
    // -1 is a safe integer but <= 0, so "at least 1" fires
    expect(() => reserve(s, -1, 'w')).toThrow('at least 1');
  });

  test('rejects fractional', () => {
    expect(() => reserve(s, 1.5, 'w')).toThrow('whole number');
  });

  test('rejects NaN', () => {
    expect(() => reserve(s, NaN, 'w')).toThrow('whole number');
  });

  test('rejects over-capacity', () => {
    expect(() => reserve(s, 13, 'w')).toThrow('remaining');
  });

  test('rejects when deadline passed', () => {
    const sd = passDeadline(s);
    expect(() => reserve(sd, 1, 'w')).toThrow('Deadline');
  });

  test('rejects when sponsor not funded (B>0)', () => {
    const su = makeInitialState(SANDBOX_TERMS, false);
    expect(() => reserve(su, 1, 'w')).toThrow('Sponsor must fund');
  });
});

// ── Test: B=0 opens without sponsor ──────────────────────────────────────────

describe('B=0 path', () => {
  const b0terms = {
    ...SANDBOX_TERMS,
    subsidyPerUnit: 0n,
    sponsorReserve: 0n,
  };

  test('makeInitialState B=0 is Open without funding', () => {
    const s = makeInitialState(b0terms, false);
    expect(s.phase).toBe('Open');
    expect(s.sponsorFunded).toBe(false);
    expect(s.actualReserve).toBe(0n);
  });

  test('can reserve immediately', () => {
    let s = makeInitialState(b0terms, false);
    s = reserve(s, 3, 'wallet.a');
    expect(s.unitCount).toBe(3);
  });

  test('fundSponsor throws when B=0', () => {
    const s = makeInitialState(b0terms, false);
    expect(() => fundSponsor(s)).toThrow('No sponsor required');
  });

  test('finalize success conservation with B=0', () => {
    let s = makeInitialState(b0terms, false);
    s = reserve(s, 10, 'wallet.a');
    s = passDeadline(s);
    s = finalize(s);
    expect(s.finalizeResult?.branch).toBe('success');
    // sponsor credit should be 0
    const walletCredits = s.finalizeResult!.walletCredits;
    expect(walletCredits[SANDBOX_SPONSOR] ?? 0n).toBe(0n);
    // conservation: N*A + 0 = 10 * 60e6
    expect(s.finalizeResult!.totalCredit).toBe(10n * b0terms.depositPerUnit);
  });
});

// ── Test: awaiting-sponsor expiry ─────────────────────────────────────────────

describe('awaiting-sponsor expiry', () => {
  test('deadline passes with N=0 actualReserve=0 → failure, sponsor credit 0', () => {
    let s = makeInitialState(SANDBOX_TERMS, false); // never funded
    s = passDeadline(s);
    s = finalize(s);
    expect(s.finalizeResult!.branch).toBe('failure');
    expect(s.finalizeResult!.sellerCredit).toBe(0n);
    expect(s.finalizeResult!.sponsorCredit).toBe(0n); // actualReserve=0
    expect(s.finalizeResult!.totalCredit).toBe(0n);
  });
});

// ── Test: full capacity does not finalize before deadline ─────────────────────

describe('full capacity deadline gate', () => {
  test('filling all 12 seats does not allow early finalize', () => {
    let s = makeInitialState(SANDBOX_TERMS, true);
    s = reserve(s, 12, 'w');
    expect(s.phase).toBe('FullAwaitDeadline');
    expect(() => finalize(s)).toThrow('Deadline not yet passed');
  });
});

// ── Test: claim retained / duplicate blocked ──────────────────────────────────

describe('claim integrity', () => {
  test('claimed amount deducted from outstanding', () => {
    let s = finalizeScenario(10);
    const buyerAddr = participantAddr(0);
    const credit = s.finalizeResult!.walletCredits[buyerAddr] ?? 0n;
    expect(credit).toBeGreaterThan(0n);
    const before = s.totalOutstanding;
    s = simulateClaim(s, buyerAddr);
    expect(s.claimed[buyerAddr]).toBe(credit);
    expect(s.totalOutstanding).toBe(before - credit);
  });

  test('duplicate claim throws', () => {
    let s = finalizeScenario(10);
    const buyerAddr = participantAddr(0);
    s = simulateClaim(s, buyerAddr);
    expect(() => simulateClaim(s, buyerAddr)).toThrow('Nothing to claim');
  });

  test('wrong wallet has nothing to claim', () => {
    const s = finalizeScenario(10);
    expect(() => simulateClaim(s, 'nobody')).toThrow('Nothing to claim');
  });

  test('remaining held = totalOutstanding after each claim', () => {
    let s = finalizeScenario(10);
    const wallets = Object.keys(s.finalizeResult!.walletCredits);
    for (const w of wallets) {
      if ((s.finalizeResult!.walletCredits[w] ?? 0n) > 0n) {
        s = simulateClaim(s, w);
      }
    }
    expect(s.totalOutstanding).toBe(0n);
    expect(s.totalClaimed).toBe(s.finalizeResult!.totalCredit);
  });
});

// ── Test: previewAllocation sponsor gates ────────────────────────────────────

describe('previewAllocation gates', () => {
  test('N=0 returns null (no quote)', () => {
    expect(previewAllocation(SANDBOX_TERMS, 0, true, 0n)).toBeNull();
  });

  test('N>K returns null', () => {
    expect(previewAllocation(SANDBOX_TERMS, 13, true, 0n)).toBeNull();
  });

  test('unfunded sponsor + N>=min returns null (no backed quote)', () => {
    expect(previewAllocation(SANDBOX_TERMS, 8, false, 0n)).toBeNull();
    expect(previewAllocation(SANDBOX_TERMS, 10, false, 0n)).toBeNull();
  });

  test('unfunded sponsor + N<min returns predicted failure (no sponsor check)', () => {
    const r = previewAllocation(SANDBOX_TERMS, 7, false, 0n);
    expect(r).not.toBeNull();
    expect(r!.isPredictedFailure).toBe(true);
    expect(r!.refundAtQuotient).toBe(SANDBOX_TERMS.depositPerUnit);
  });

  test('B=0 unfunded sponsor + N>=min returns success preview', () => {
    const b0 = { ...SANDBOX_TERMS, subsidyPerUnit: 0n, sponsorReserve: 0n };
    const r = previewAllocation(b0, 10, false, 0n);
    expect(r).not.toBeNull();
    expect(r!.isPredictedFailure).toBe(false);
  });

  test('funded N=10 canonical: charge=45, refund=15', () => {
    const r = previewAllocation(SANDBOX_TERMS, 10, true, SANDBOX_TERMS.sponsorReserve);
    expect(r).not.toBeNull();
    expect(r!.chargeAtQuotient).toBe(45_000_000n);
    expect(r!.refundAtQuotient).toBe(15_000_000n);
    expect(r!.remainder).toBe(0n);
  });
});

// ── Test: scenario presets ────────────────────────────────────────────────────

describe('Scenario presets', () => {
  for (const sc of SCENARIOS) {
    test(`scenario ${sc.id} builds without error`, () => {
      const s = buildScenarioState(sc);
      expect(s.unitCount).toBe(sc.N);
      expect(s.finalized).toBe(sc.finalized);
    });
  }

  test('n7 failure: 600 held, 420 buyer + 180 sponsor refundable', () => {
    const s = buildScenarioState(SCENARIOS.find(s => s.id === 'n7')!);
    expect(s.finalizeResult!.branch).toBe('failure');
    expect(s.finalizeResult!.sellerCredit).toBe(0n);
    expect(s.finalizeResult!.sponsorCredit).toBe(180_000_000n);
    const buyerTotal = Object.entries(s.finalizeResult!.walletCredits)
      .filter(([k]) => k !== SANDBOX_SELLER && k !== SANDBOX_SPONSOR)
      .reduce((a, [, v]) => a + v, 0n);
    expect(buyerTotal).toBe(7n * 60_000_000n); // 420 USDC
  });

  test('await scenario: AwaitingSponsor phase, no units possible', () => {
    const s = buildScenarioState(SCENARIOS.find(s => s.id === 'await')!);
    expect(s.phase).toBe('AwaitingSponsor');
    expect(s.unitCount).toBe(0);
    expect(s.sponsorFunded).toBe(false);
  });
});

// ── Test: N7 eligible vs held callout ────────────────────────────────────────

describe('N=7 eligible vs held', () => {
  test('held=600, eligible=7*(60+15)=525, gap=75', () => {
    const N = 7n;
    const A = SANDBOX_TERMS.depositPerUnit;    // 60e6
    const B = SANDBOX_TERMS.subsidyPerUnit;    // 15e6
    const S = SANDBOX_TERMS.sponsorReserve;    // 180e6
    const held     = N * A + S;               // 420e6 + 180e6 = 600e6
    const eligible = N * (A + B);             // 7 * 75e6 = 525e6
    expect(held).toBe(600_000_000n);
    expect(eligible).toBe(525_000_000n);
    expect(held - eligible).toBe(75_000_000n); // 75 USDC reserved for unfilled capacity
  });
});
