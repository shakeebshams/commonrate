import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';
import { renderToStaticMarkup } from 'react-dom/server';
import LivePilot, { deadlineFromLastCheck } from '../src/live/LivePilot';
import { deadlineFromUTC, MAX_SUPPORTED_DEADLINE, validateDeadline, type NetworkId } from '../src/live/pilot';

describe('explicit last-checked deadline helper (pure/SSR/source, not browser tests)', () => {
  const chain: NetworkId = 5042002;
  const timestamp = deadlineFromUTC('2026-10-22T10:20:37Z');

  test('adds exactly thirty minutes in explicit UTC without consulting the system clock', () => {
    const candidate = deadlineFromLastCheck({ chain, timestamp }, chain);
    expect(candidate).toBe('2026-10-22T10:50:37Z');
    expect(deadlineFromUTC(candidate!)).toBe(timestamp + 1800n);
    expect(deadlineFromLastCheck({ chain: 5042, timestamp }, 5042)).toBe(candidate);
  });

  test('handles leap-day and year rollover without dropping seconds', () => {
    expect(deadlineFromLastCheck({ chain, timestamp: deadlineFromUTC('2028-02-29T23:50:13Z') }, chain)).toBe('2028-03-01T00:20:13Z');
    expect(deadlineFromLastCheck({ chain, timestamp: deadlineFromUTC('2026-12-31T23:45:00Z') }, chain)).toBe('2027-01-01T00:15:00Z');
  });

  test('requires a checked network matching the explicit selection', () => {
    expect(deadlineFromLastCheck(undefined, chain)).toBeUndefined();
    expect(deadlineFromLastCheck({ chain, timestamp })).toBeUndefined();
    expect(deadlineFromLastCheck({ chain, timestamp }, 5042)).toBeUndefined();
    expect(deadlineFromLastCheck({ chain: 5042, timestamp }, chain)).toBeUndefined();
  });

  test('fails closed outside the supported timestamp and resulting UTC range', () => {
    expect(deadlineFromLastCheck({ chain, timestamp: 0n }, chain)).toBe('1970-01-01T00:30:00Z');
    expect(deadlineFromLastCheck({ chain, timestamp: MAX_SUPPORTED_DEADLINE - 1800n }, chain)).toBe('9999-12-31T23:59:59Z');
    for (const invalid of [-1n, MAX_SUPPORTED_DEADLINE - 1799n, MAX_SUPPORTED_DEADLINE, 2n ** 256n, null, undefined, 123, '123']) {
      expect(deadlineFromLastCheck({ chain, timestamp: invalid as bigint }, chain)).toBeUndefined();
    }
  });

  test('a stale suggestion still fails the unchanged fresh deadline checks', () => {
    const deadline = deadlineFromUTC(deadlineFromLastCheck({ chain, timestamp }, chain)!);
    const terms = { seller: '0x1111111111111111111111111111111111111111' as const, sponsor: '0x2222222222222222222222222222222222222222' as const, deadline };
    expect(() => validateDeadline(terms, timestamp, true)).not.toThrow();
    expect(() => validateDeadline(terms, timestamp + 1200n, true)).not.toThrow();
    expect(() => validateDeadline(terms, timestamp + 1201n, true)).toThrow('at least 10 minutes');
  });

  test('without a network check the rendered helper is disabled and explains its basis', () => {
    const html = renderToStaticMarkup(<LivePilot />);
    expect(html).toMatch(/<button[^>]*disabled=""[^>]*>Use last checked chain time \+30 min<\/button>/);
    expect(html).toContain('Verify the selected network first to use this helper.');
    expect(html).toContain('An old check can produce a deadline too soon.');
    expect(html).toContain('review and submission each require at least 10 minutes beyond fresh chain time');
    expect(html).toContain('aria-describedby="live-deadline-basis live-deadline-help"');
  });

  test('only the explicit local click fills the deadline and invalidates prior acceptance (source guard)', () => {
    const source = readFileSync(new URL('../src/live/LivePilot.tsx', import.meta.url), 'utf8');
    expect(source).toContain('disabled={!checkedDeadline || state.busy || unresolved}');
    expect(source).toContain('onClick={() => { if (checkedDeadline) { setDeadline(checkedDeadline); changed(); } }}');
    expect(source.match(/setDeadline\(checkedDeadline\)/g)).toHaveLength(1);
    expect(source).toContain('onChange={event => { setDeadline(event.target.value); changed(); }}');
    expect(source).toContain("const [deadline, setDeadline] = useState('')");
    expect(source).toContain('Last checked chain time: {utc(state.network.timestamp)}.');
    // The existing wrapping button treatment is used, not a new fixed-width control.
    expect(source).toContain('<div className="cr-live-buttons"><button className="cr-btn" type="button" aria-describedby="live-deadline-basis live-deadline-help"');
  });
});
