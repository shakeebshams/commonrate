import { expect, test } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import App from '../src/App';

test('booking sheet explains the outside-provider arrangement without implying a real booking', () => {
  const html = renderToStaticMarkup(<App />);
  const serviceLine = html.match(/<p class="cr-service-line">([^<]*)<\/p>/)?.[1];
  expect(serviceLine).toBe('Agree the session with your provider outside CommonRate. No real provider or date is booked.');
  expect(html).toContain('Sandbox preview. No real money, wallet or booking.');
});
