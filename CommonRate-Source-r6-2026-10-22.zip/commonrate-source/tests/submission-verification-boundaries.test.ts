import { afterAll, describe, expect, test } from 'bun:test';
import type { Address, Hex } from 'viem';
import { LiveController, type LiveDependencies } from '../src/live/controller';
import { deploymentData, verifyCampaign, verifyNetwork, type Reader } from '../src/live/chain';
import { ARTIFACT } from '../src/live/verification';
import { PILOT, PILOT_DESCRIPTION, PILOT_TITLE, TERMS_HASH, TOKEN } from '../src/live/pilot';
import { formatCampaignReference } from '../src/live/reference';

// This exercises production verifyCampaign, not its common controller-test stub.
// Every read is an invented in-memory response. No chain or EVM is involved.
const account = '0x1111111111111111111111111111111111111111' as Address;
const campaign = '0x3333333333333333333333333333333333333333' as Address;
const hash = `0x${'44'.repeat(32)}` as Hex;
const blockHash = `0x${'55'.repeat(32)}` as Hex;
const chain = 5042002 as const;
const terms = { seller: account, sponsor: account, deadline: 2000n };
function fixture() {
  const calls: { method: string; args?: any }[] = [];
  const tx = { hash, from: account, to: null, value: 0n, input: deploymentData(terms), chainId: chain, blockHash };
  const receipt = { transactionHash: hash, status: 'success', contractAddress: campaign, blockNumber: 10n, blockHash, to: null };
  const deploymentBlock = { hash: blockHash, number: 10n, timestamp: 1000n };
  const values: Record<string, unknown> = { token: TOKEN, seller: account, sponsorAddress: account, cost: PILOT.cost, depositPerUnit: PILOT.deposit, subsidyPerUnit: PILOT.subsidy, capacity: PILOT.capacity, minUnits: PILOT.minimum, deadline: terms.deadline, sponsorReserve: PILOT.reserve, title: PILOT_TITLE, description: PILOT_DESCRIPTION, termsHash: TERMS_HASH, unitCount: 1n, sponsorFunded: true, finalized: false, succeeded: false, accountedLiabilities: 90000n, totalDepositsReceived: 60000n, totalClaimed: 0n, balanceOf: 1000000n, allowance: 60000n, credits: 0n, claimedByWallet: 0n, walletAllocation: [0n,0n,0n,0n,0n,0n], seatsOf: [0n], seatAllocation: [0n,0n,0n] };
  const reader = { getChainId: async () => { calls.push({method:'getChainId'}); return chain; }, getBlock: async (args?: any) => { calls.push({ method:'getBlock', args }); return args ? deploymentBlock : { hash: blockHash, number: 100n, timestamp: 1500n }; }, getCode: async (args: any) => { calls.push({ method:'getCode', args }); return args.address === TOKEN ? '0x6000' : ARTIFACT.deployedBytecode; }, getTransaction: async (args: any) => { calls.push({ method:'getTransaction', args }); return tx; }, getTransactionReceipt: async (args: any) => { calls.push({ method:'getTransactionReceipt', args }); return receipt; }, readContract: async (args: any) => { calls.push({ method:'readContract', args }); return args.functionName === 'decimals' ? 6 : values[args.functionName]; } } as unknown as Reader;
  return { reader, tx, receipt, deploymentBlock, values, calls };
}
// The ordinary package test command has no audit preload; fixtures remain inert.
afterAll(() => { const attempts = (globalThis as any).__AUDIT_NETWORK_ATTEMPTS__; if (attempts) expect(attempts).toEqual([]); });
describe('Supplemental deployment verification boundaries, offline fixtures only', () => {
  test('actual verification binds all current code/state reads to one explicit block', async () => {
    const f = fixture(); const snapshot = await verifyCampaign(f.reader, chain, hash, account);
    expect(snapshot.address).toBe(campaign); expect(snapshot.deploymentHash).toBe(hash); expect(snapshot.block).toBe(100n); expect(snapshot.account).toBe(account); expect(snapshot.terms).toEqual(terms);
    const pinned = f.calls.filter(x => x.method === 'readContract' || x.method === 'getCode'); expect(pinned.length).toBeGreaterThan(20); expect(pinned.every(x => x.args.blockNumber === 100n)).toBe(true);
    expect(f.calls.filter(x => x.method === 'getBlock').map(x => x.args)).toEqual([undefined, { blockNumber: 10n }]);
  });
  test('noncanonical, future, hash-mismatched and indirect creations fail before campaign state is read', async () => {
    for (const corrupt of [(f: ReturnType<typeof fixture>) => { f.deploymentBlock.hash = hash; }, (f: ReturnType<typeof fixture>) => { f.receipt.blockNumber = 101n; }, (f: ReturnType<typeof fixture>) => { f.receipt.transactionHash = blockHash; }, (f: ReturnType<typeof fixture>) => { f.tx.hash = blockHash; }, (f: ReturnType<typeof fixture>) => { (f.tx as any).to = campaign; }, (f: ReturnType<typeof fixture>) => { f.tx.value = 1n; }]) {
      const f = fixture(); corrupt(f); await expect(verifyCampaign(f.reader, chain, hash, account)).rejects.toThrow(); expect(f.calls.some(x => x.method === 'readContract' && x.args.address === campaign)).toBe(false);
    }
  });
  test('malformed account allocation and seat reads fail rather than exposing a verified snapshot', async () => {
    for (const patch of [{ unitCount: 4n }, { sponsorFunded: 1 }, { finalized: 'false' }, { seatsOf: [0n, 0n] }, { seatsOf: [1n] }, { seatsOf: [0n, 1n, 2n, 3n] }, { seatsOf: [-1n] }, { walletAllocation: [0n] }, { walletAllocation: [0n,0n,0n,0n,0n,-1n] }, { credits: 1n }, { claimedByWallet: 1n }]) {
      const f = fixture(); Object.assign(f.values, patch); await expect(verifyCampaign(f.reader, chain, hash, account)).rejects.toThrow();
    }
  });
  test('imported lookup text makes no read; explicit failing provenance never becomes saved verification', async () => {
    const f = fixture(); f.receipt.blockNumber = 101n; let stored: string | null = null;
    const deps = { readClient: () => f.reader, verifyNetwork, verifyCampaign, walletClient: () => { throw new Error('Mock wallet factory must not be reached'); } } as unknown as LiveDependencies;
    const c = new LiveController(undefined, false, { getItem: () => stored, setItem: (_key, value) => { stored = value; } }, deps);
    const imported = c.importReference(formatCampaignReference({ chain, deploymentHash: hash })); expect(imported).toEqual({ chain, deploymentHash: hash }); expect(f.calls).toEqual([]); expect(stored).toBeNull(); expect(c.getSnapshot().savedHash).toBe('');
    await c.refresh(hash); expect(c.getSnapshot().error).toContain('canonical chain'); expect(c.getSnapshot().snapshot).toBeUndefined(); expect(c.getSnapshot().network).toBeUndefined(); expect(c.getSnapshot().review).toBeUndefined(); expect(c.getSnapshot().savedHash).toBe(''); expect(stored).toBeNull();
  });
});
