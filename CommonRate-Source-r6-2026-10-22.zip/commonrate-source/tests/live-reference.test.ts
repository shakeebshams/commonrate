import { describe, expect, test } from 'bun:test';
import { formatCampaignReference, parseCampaignReference, type CampaignReference } from '../src/live/reference';

const hash = `0x${'aB01'.repeat(16)}` as const;
const normalized = hash.toLowerCase();
const reference = `commonrate:1:5042002:${hash}`;

describe('Inert CommonRate campaign reference codec', () => {
  test('round-trips each supported network and normalizes hexadecimal case', () => {
    for (const chain of [5042, 5042002] as const) {
      const result = parseCampaignReference(`commonrate:1:${chain}:${hash}`);
      expect(result).toEqual({ chain, deploymentHash: normalized });
      expect(formatCampaignReference(result)).toBe(`commonrate:1:${chain}:${normalized}`);
      expect(formatCampaignReference({ chain, deploymentHash: hash })).toBe(`commonrate:1:${chain}:${normalized}`);
      expect(parseCampaignReference(formatCampaignReference(result))).toEqual(result);
    }
    expect(parseCampaignReference(reference.replace('0x', '0X')).deploymentHash).toBe(normalized);
  });

  test('accepts only ordinary surrounding ASCII whitespace', () => {
    for (const whitespace of [' ', '\t', '\r', '\n', ' \r\n\t  ']) {
      expect(parseCampaignReference(`${whitespace}${reference}${whitespace}`)).toEqual({ chain: 5042002, deploymentHash: normalized });
    }
    for (const whitespace of [' ', '\t', '\r', '\n']) {
      for (const value of [reference.replace(':1:', `:${whitespace}1:`), reference.replace(':5042002:', `:5042002${whitespace}:`), reference.replace('0x', `0x${whitespace}`)]) {
        expect(() => parseCampaignReference(value)).toThrow('only before or after');
      }
    }
  });

  test('rejects empty, non-string and oversized inputs without coercion', () => {
    for (const value of ['', ' \t\r\n ']) expect(() => parseCampaignReference(value)).toThrow('Paste a CommonRate reference.');
    let coercions = 0;
    const notText = { toString: () => { coercions++; return reference; } };
    for (const value of [undefined, null, 5042, false, [reference], notText]) {
      expect(() => parseCampaignReference(value as unknown as string)).toThrow('as text');
    }
    expect(coercions).toBe(0);
    expect(parseCampaignReference(reference.padEnd(256, ' '))).toEqual({ chain: 5042002, deploymentHash: normalized });
    for (const value of [reference.padEnd(257, ' '), `${' '.repeat(257)}${reference}`, 'x'.repeat(100_000)]) {
      expect(() => parseCampaignReference(value)).toThrow('at most 256 characters');
    }
  });

  test('rejects unsupported or noncanonical prefixes, versions and networks', () => {
    for (const prefix of ['CommonRate', 'COMMONRATE', 'commonRate', 'ethereum', '']) {
      expect(() => parseCampaignReference(reference.replace('commonrate', prefix))).toThrow('Use commonrate:1:');
    }
    for (const version of ['', '0', '2', '01', '+1', '1.0', '1e0']) {
      expect(() => parseCampaignReference(`commonrate:${version}:5042002:${hash}`)).toThrow('Unsupported reference version');
    }
    for (const chain of ['', '1', '5042001', '05042', '05042002', '+5042', '-5042', '5042.0', '5.042e3', '0x13b2']) {
      expect(() => parseCampaignReference(`commonrate:1:${chain}:${hash}`)).toThrow('Unsupported network');
    }
  });

  test('requires an exact 32-byte hash, not an address or decorated input', () => {
    for (const value of ['', '0x', `0x${'a'.repeat(40)}`, `0x${'a'.repeat(63)}`, `0x${'a'.repeat(65)}`, `0x${'g'.repeat(64)}`, 'a'.repeat(64), `${hash}.`, `${hash}?rpc=evil`, `${hash}#fragment`, `${hash}&chainId=5042`, `"${hash}"`, `<${hash}>`]) {
      expect(() => parseCampaignReference(`commonrate:1:5042002:${value}`)).toThrow('exactly 64 hexadecimal');
    }
  });

  test('does not interpret URLs, encoded text, extra fields or duplicate fields', () => {
    for (const value of [`https://example.test/?ref=${reference}`, `commonrate://1/5042002/${hash}`, `https://example.test/#${reference}`, encodeURIComponent(reference), `${reference}:5042`, `${reference}:${hash}`, `${reference}:`, `${reference}:rpc=https://example.test`, `commonrate:1:5042002:5042002:${hash}`, `commonrate:1:1:5042002:${hash}`, JSON.stringify({ chain: 5042002, deploymentHash: hash })]) {
      expect(() => parseCampaignReference(value)).toThrow();
    }
  });

  test('rejects Unicode confusables, invisible characters and non-ordinary controls', () => {
    for (const character of ['\u00a0', '\u2000', '\u200b', '\u200d', '\u2028', '\u2029', '\u202e', '\u2066', '\u2069', '\u3000', '\ufeff', '\u0000', '\u000b', '\u000c', '\u001b', '\u007f']) {
      for (const value of [`${character}${reference}`, `${reference}${character}`, reference.replace(':1:', `:${character}1:`)]) {
        expect(() => parseCampaignReference(value)).toThrow('plain ASCII');
      }
    }
    for (const value of [reference.replace('commonrate', 'cоmmonrate'), reference.replace(':1:', ':１:'), reference.replaceAll(':', '：'), reference.replace('5042002', '５０４２００２'), reference.replace('aB01', 'ａB01')]) {
      expect(() => parseCampaignReference(value)).toThrow('plain ASCII');
    }
  });

  test('formatter validates runtime data and does not silently sanitize it', () => {
    for (const value of [null, undefined, false, reference]) {
      expect(() => formatCampaignReference(value as unknown as CampaignReference)).toThrow('Provide a network');
    }
    for (const chain of [1, 5042001, '5042', NaN, Infinity, undefined]) {
      expect(() => formatCampaignReference({ chain, deploymentHash: hash } as unknown as CampaignReference)).toThrow('Unsupported network');
    }
    for (const deploymentHash of [undefined, null, 123, '', ` ${hash}`, `${hash}\n`, `${hash}\r`, `${hash}\t`, `${hash}:rpc=evil`, `0x${'a'.repeat(40)}`]) {
      expect(() => formatCampaignReference({ chain: 5042, deploymentHash } as unknown as CampaignReference)).toThrow('exactly 64 hexadecimal');
    }
  });

  test('uses bounded errors that do not echo untrusted input', () => {
    const marker = 'private-untrusted-marker';
    for (const value of [`${marker}:${reference}`, `${reference}:${marker}`, `commonrate:${marker}:5042:${hash}`, `commonrate:1:${marker}:${hash}`, `commonrate:1:5042:${marker}`, marker.repeat(50)]) {
      let error: unknown;
      try { parseCampaignReference(value); } catch (caught) { error = caught; }
      expect(error).toBeInstanceOf(Error);
      expect((error as Error).message.length).toBeLessThanOrEqual(160);
      expect((error as Error).message).not.toContain(marker);
    }
  });

  test('creates independent plain coordinates without mutating the input or claiming verification', () => {
    const input = Object.freeze({ chain: 5042 as const, deploymentHash: hash });
    expect(formatCampaignReference(input)).toBe(`commonrate:1:5042:${normalized}`);
    expect(input.deploymentHash).toBe(hash);
    const first = parseCampaignReference(reference);
    const second = parseCampaignReference(reference);
    expect(first).not.toBe(second);
    expect(Object.keys(first).sort()).toEqual(['chain', 'deploymentHash']);
    first.chain = 5042;
    expect(second.chain).toBe(5042002);
    // Syntactic validity is deliberately not a chain lookup or provenance claim.
    expect(parseCampaignReference(`commonrate:1:5042:0x${'0'.repeat(64)}`).deploymentHash).toBe(`0x${'0'.repeat(64)}`);
  });

  test('is a dependency-free codec without runtime or type imports', async () => {
    const source = await Bun.file(new URL('../src/live/reference.ts', import.meta.url)).text();
    expect(new Bun.Transpiler({ loader: 'ts' }).scanImports(source)).toEqual([]);
  });
});
