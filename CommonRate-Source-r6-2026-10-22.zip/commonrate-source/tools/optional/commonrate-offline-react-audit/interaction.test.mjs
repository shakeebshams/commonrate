import './block-network.mjs';
import { test, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import Renderer from 'react-test-renderer';
import { createRequire } from 'node:module';
import { createFixture, campaignSnapshot, deferred, ACCOUNT, CAMPAIGN, DEPLOYMENT, OTHER_HASH, HASH } from './fixture.mjs';
const { LivePilot, LiveBoundary, ReferenceExport } = createRequire(import.meta.url)('./component-under-test.cjs');
const { act, create } = Renderer;
const mounted = [];
const fixtures = [];
const flush = () => new Promise(resolve => setImmediate(resolve));
const text = node => typeof node === 'string' ? node : typeof node === 'number' ? String(node) : node?.children?.map(text).join('') ?? '';
const button = (tree, label) => tree.root.findAllByType('button').find(node => text(node) === label);
const field = (tree, prefix, type = 'input') => tree.root.findAllByType('label').find(node => text(node).startsWith(prefix)).findByType(type);
const selectChain = tree => field(tree, 'Network', 'select');
const review = tree => tree.root.findAll(node => node.type === 'section' && node.props.className === 'cr-live-review');
async function change(node, value) { await act(async () => { node.props.onChange({ target: { value } }); await flush(); }); }
async function click(tree, label) {
  const node = button(tree, label); assert.ok(node, `Button exists: ${label}`); assert.equal(!!node.props.disabled, false, `Button enabled: ${label}`);
  await act(async () => { node.props.onClick(); await flush(); });
}
async function mount(options = {}, element) {
  const fixture = createFixture(options); fixtures.push(fixture);
  let tree;
  await act(async () => { tree = create(element ?? React.createElement(LivePilot), { createNodeMock: () => ({ focus() {}, select() {} }) }); await flush(); });
  mounted.push(tree); return { fixture, tree };
}
async function unmount(tree) { await act(async () => { tree.unmount(); await flush(); }); mounted.splice(mounted.indexOf(tree), 1); }
async function ready(options = {}) {
  const f = await mount(options);
  await change(selectChain(f.tree), '5042002');
  await click(f.tree, 'Connect wallet');
  await change(field(f.tree, 'Deployment transaction hash'), DEPLOYMENT);
  await click(f.tree, 'Verify / refresh reads');
  return f;
}
async function accept(tree) { await act(async () => { tree.root.findByProps({ type: 'checkbox' }).props.onChange({ target: { checked: true } }); }); }
async function prepareDeployment(tree) {
  await act(async () => { tree.root.findByProps({ className: 'cr-disclosure cr-live-deploy' }).props.onToggle({ currentTarget: { open: true } }); });
  await click(tree, 'Use my connected wallet for both roles');
  await change(field(tree, 'Explicit UTC deadline'), '1970-01-01T00:33:20Z');
  await click(tree, 'Review deployment'); await accept(tree);
}
async function deployed(options = {}) {
  const result = await mount(options);
  await change(selectChain(result.tree), '5042002'); await click(result.tree, 'Connect wallet');
  await prepareDeployment(result.tree); await click(result.tree, 'Confirm in wallet');
  return result;
}
const campaignButtons = ['Review 0.03 sponsor approval', 'Review sponsor funding', 'Review exact reservation approval', 'Review reservation', 'Review finalization', 'Review claim'];
const externalActivity = f => f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write', 'storage.set'].includes(event[0]));
const deadlineHelperLabel = 'Use last checked chain time +30 min';
afterEach(async () => {
  for (const tree of [...mounted]) await unmount(tree);
  for (const fixture of fixtures.splice(0)) assert.deepEqual(fixture.denied, [], 'No unexpected fake provider/RPC method');
  assert.deepEqual(globalThis.__AUDIT_NETWORK_ATTEMPTS__, [], 'No actual network attempt, even if swallowed');
  delete globalThis.window; delete globalThis.document; delete globalThis.HTMLElement; delete globalThis.__COMMONRATE_REACT_AUDIT__;
});

test('fresh client mount and network selection perform no RPC, account query, wallet write or reconnect', async () => {
  const { fixture: f, tree } = await mount();
  assert.equal(f.controllers.length, 1); assert.deepEqual(f.methods(), []); assert.equal(f.count('readClient'), 0); assert.equal(f.count('write'), 0);
  assert.equal(button(tree, 'Connect wallet').props.disabled, true); assert.equal(button(tree, 'Verify / refresh reads').props.disabled, true);
  await change(selectChain(tree), '5042002');
  assert.deepEqual(f.methods(), []); assert.equal(f.count('readClient'), 0); assert.equal(f.count('write'), 0);
  assert.equal(button(tree, 'Connect wallet').props.disabled, false);
});

test('restoring saved public coordinates mounts inert and never restores account permission', async () => {
  const { fixture: f, tree } = await mount({ saved: JSON.stringify({ chain: 5042002, deploymentHash: DEPLOYMENT, pending: [] }) });
  assert.equal(selectChain(tree).props.value, 5042002); assert.equal(field(tree, 'Deployment transaction hash').props.value, DEPLOYMENT);
  assert.deepEqual(f.methods(), []); assert.equal(f.count('readClient'), 0); assert.equal(f.controller.getSnapshot().account, undefined);
  assert.doesNotMatch(text(tree.toJSON()), /Verified tiny campaign|Connected account:/);
});

test('Verify performs only explicit read dependencies and Connect alone requests account permission', async () => {
  const { fixture: f, tree } = await mount();
  await change(selectChain(tree), '5042002'); await click(tree, 'Verify / refresh reads');
  assert.deepEqual(f.methods(), []); assert.equal(f.count('verifyNetwork'), 1); assert.equal(f.count('verifyCampaign'), 0); assert.equal(f.count('write'), 0);
  await click(tree, 'Connect wallet');
  assert.deepEqual(f.methods(), ['eth_requestAccounts', 'eth_chainId']); assert.equal(f.count('verifyNetwork'), 1); assert.equal(f.count('write'), 0);
});

for (const options of [{ noProvider: true }, { embedded: true }]) test(`wallet gating remains fail-closed with ${Object.keys(options)[0]}, while explicit public Verify works`, async () => {
  const { fixture: f, tree } = await mount(options);
  await change(selectChain(tree), '5042002'); assert.equal(button(tree, 'Connect wallet').props.disabled, true);
  await click(tree, 'Verify / refresh reads'); assert.equal(f.count('verifyNetwork'), 1); assert.deepEqual(f.methods(), []); assert.equal(f.count('write'), 0);
});

test('import handler fills the displayed draft without requests; Verify uses exactly that draft and clearing it is network-only', async () => {
  const { fixture: f, tree } = await mount();
  await change(field(tree, 'Pilot reference'), `commonrate:1:5042002:${OTHER_HASH}`);
  await act(async () => { tree.root.findByType('form').props.onSubmit({ preventDefault() {} }); await flush(); });
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH); assert.equal(selectChain(tree).props.value, 5042002);
  assert.equal(f.count('readClient'), 0); assert.deepEqual(f.methods(), []); assert.equal(f.count('storage.set'), 0);
  await click(tree, 'Verify / refresh reads');
  assert.equal(f.log.find(event => event[0] === 'verifyCampaign')[2], OTHER_HASH);
  await change(field(tree, 'Deployment transaction hash'), ''); await click(tree, 'Verify / refresh reads');
  assert.equal(f.count('verifyCampaign'), 1); assert.equal(f.count('verifyNetwork'), 2); assert.doesNotMatch(text(tree.toJSON()), /Verified tiny campaign/);
});

test('a real review renders exact terms, requires a fresh checkbox, and Cancel never submits', async () => {
  const { fixture: f, tree } = await ready(); await click(tree, 'Review reservation');
  assert.equal(review(tree).length, 1); assert.match(text(review(tree)[0]), /reserve\(1\)/); assert.match(text(review(tree)[0]), /0\.060000 USDC/);
  assert.equal(f.count('write'), 0); assert.equal(button(tree, 'Confirm in wallet').props.disabled, true);
  await accept(tree); assert.equal(button(tree, 'Confirm in wallet').props.disabled, false);
  await click(tree, 'Cancel review'); assert.equal(review(tree).length, 0); assert.equal(f.count('write'), 0);
  await click(tree, 'Review reservation'); assert.equal(button(tree, 'Confirm in wallet').props.disabled, true);
});

test('quantity and displayed deployment edits invalidate the rendered review and acceptance', async () => {
  const { fixture: f, tree } = await ready(); await click(tree, 'Review reservation'); await accept(tree);
  await change(field(tree, 'Reservation quantity', 'select'), '2'); assert.equal(review(tree).length, 0); assert.equal(f.count('write'), 0);
  await change(field(tree, 'Reservation quantity', 'select'), '1'); await click(tree, 'Review reservation');
  assert.equal(button(tree, 'Confirm in wallet').props.disabled, true);
  await change(field(tree, 'Deployment transaction hash'), OTHER_HASH); assert.equal(review(tree).length, 0); assert.doesNotMatch(text(tree.toJSON()), /Verified tiny campaign/);
});

for (const scenario of [
  { label: 'Review 0.03 sponsor approval', patch: { sponsorFunded: false, allowance: 0n }, amount: '0.030000 USDC', atomic: 30000n, forbidden: 'fundSponsor' },
  { label: 'Review exact reservation approval', patch: { allowance: 0n }, amount: '0.060000 USDC', atomic: 60000n, forbidden: 'reserve' },
]) test(`${scenario.label} confirms only exact approval with no automatic follow-on transfer`, async () => {
  const { fixture: f, tree } = await ready(); f.controls.snapshotPatch = scenario.patch;
  await click(tree, scenario.label); assert.match(text(review(tree)[0]), /approve\(campaign, exact amount\)/);
  assert.ok(text(review(tree)[0]).includes(scenario.amount)); assert.equal(f.count('write'), 0);
  await accept(tree); await click(tree, 'Confirm in wallet');
  const writes = f.log.filter(event => event[0] === 'write'); assert.equal(writes.length, 1); assert.equal(writes[0][1], 'approve');
  assert.deepEqual(writes[0][2].args, [CAMPAIGN, scenario.atomic]);
  assert.notEqual(writes[0][1], scenario.forbidden); assert.equal(review(tree).length, 0);
});

test('deployment form validates locally, opens a separate exact review and does not write before confirmation', async () => {
  const { fixture: f, tree } = await ready();
  await act(async () => { tree.root.findByProps({ className: 'cr-disclosure cr-live-deploy' }).props.onToggle({ currentTarget: { open: true } }); });
  const before = f.count('readClient'); await click(tree, 'Review deployment');
  assert.equal(review(tree).length, 0); assert.equal(f.count('readClient'), before); assert.equal(f.count('write'), 0);
  await click(tree, 'Use my connected wallet for both roles'); await change(field(tree, 'Explicit UTC deadline'), '1970-01-01T00:33:20Z');
  await click(tree, 'Review deployment'); assert.equal(review(tree).length, 1); assert.match(text(review(tree)[0]), /New contract creation/);
  assert.match(text(review(tree)[0]), /constructor\(/); assert.equal(button(tree, 'Confirm in wallet').props.disabled, true); assert.equal(f.count('write'), 0);
  await accept(tree); await change(field(tree, 'Sponsor public address'), '0x3333333333333333333333333333333333333333');
  assert.equal(review(tree).length, 0); assert.equal(f.count('write'), 0);
});

test('explicit fake-wallet rejection renders rejected, not successful, and the next review needs fresh acceptance', async () => {
  const { fixture: f, tree } = await ready({ walletError: { code: 4001 } });
  await click(tree, 'Review reservation'); await accept(tree); await click(tree, 'Confirm in wallet');
  assert.equal(f.count('write'), 1); assert.match(text(tree.toJSON()), /Reserve units · rejected/); assert.doesNotMatch(text(tree.toJSON()), /Reserve units · confirmed/);
  await click(tree, 'Review reservation'); assert.equal(button(tree, 'Confirm in wallet').props.disabled, true); assert.equal(f.count('write'), 1);
});

test('duplicate retained confirm handlers produce exactly one fake write and visible unresolved lock', async () => {
  const receipt = deferred(); const { fixture: f, tree } = await ready({ receipt });
  await click(tree, 'Review reservation'); await accept(tree);
  const handler = button(tree, 'Confirm in wallet').props.onClick;
  await act(async () => { handler(); handler(); await flush(); });
  assert.equal(f.count('write'), 1); assert.equal(f.controller.getSnapshot().receipts[0].status, 'pending');
  assert.equal(review(tree).length, 0); assert.equal(button(tree, 'Review reservation').props.disabled, true);
  assert.equal(selectChain(tree).props.disabled, true); assert.equal(field(tree, 'Deployment transaction hash').props.disabled, true); assert.equal(button(tree, 'Import reference only').props.disabled, true);
  await act(async () => { receipt.resolve({ status: 'success', transactionHash: HASH }); await flush(); });
  assert.equal(f.count('write'), 1); assert.match(text(tree.toJSON()), /Reserve units · confirmed/); assert.equal(review(tree).length, 0);
});

test('duplicate Connect clicks while permission is pending never create two permission requests', async () => {
  const accountPermission = deferred(); const { fixture: f, tree } = await mount({ accountPermission });
  await change(selectChain(tree), '5042002'); const handler = button(tree, 'Connect wallet').props.onClick;
  await act(async () => { handler(); handler(); await flush(); }); assert.equal(button(tree, 'Connect wallet').props.disabled, true);
  assert.deepEqual(f.methods(), ['eth_requestAccounts']);
  await act(async () => { accountPermission.resolve([ACCOUNT]); await flush(); });
  assert.deepEqual(f.methods(), ['eth_requestAccounts', 'eth_chainId']); assert.match(text(tree.toJSON()), /Connected account:/);
});

for (const event of ['accountsChanged', 'chainChanged', 'disconnect']) test(`${event} removes the visible review, account and campaign without reconnecting`, async () => {
  const { fixture: f, tree } = await ready(); await click(tree, 'Review reservation'); await accept(tree);
  const before = f.methods().length;
  await act(async () => { f.emit(event); await flush(); });
  assert.equal(review(tree).length, 0); assert.doesNotMatch(text(tree.toJSON()), /Connected account:|Verified tiny campaign/);
  assert.equal(f.methods().length, before); assert.equal(f.count('write'), 0); assert.equal(button(tree, 'Review deployment').props.disabled, true);
});

test('account invalidation while Review is pending cannot resurrect a stale review', async () => {
  const { fixture: f, tree } = await ready(); const campaign = deferred(); f.controls.campaignPromise = campaign.promise;
  await click(tree, 'Review reservation'); assert.equal(f.controller.getSnapshot().busy, true);
  await act(async () => { f.emit('accountsChanged'); campaign.resolve(campaignSnapshot()); await flush(); });
  assert.equal(review(tree).length, 0); assert.equal(f.controller.getSnapshot().account, undefined); assert.equal(f.count('write'), 0);
  assert.match(text(tree.toJSON()), /changed|fresh review/i);
});

test('changed onchain state at Confirm removes review and reports an error rather than using cached authorization', async () => {
  const { fixture: f, tree } = await ready(); await click(tree, 'Review reservation'); await accept(tree);
  f.controls.snapshotPatch = { unitCount: 2n }; await click(tree, 'Confirm in wallet');
  assert.equal(f.count('write'), 0); assert.equal(review(tree).length, 0); assert.match(text(tree.toJSON()), /Onchain state or reviewed inputs changed/);
});

test('storage failure during Confirm renders actionable feedback without opening a fake wallet request', async () => {
  const { fixture: f, tree } = await ready({ failStorage: true }); await click(tree, 'Review reservation'); await accept(tree); await click(tree, 'Confirm in wallet');
  assert.equal(f.count('write'), 0); assert.equal(f.controller.getSnapshot().receipts.length, 0);
  assert.match(text(tree.toJSON()), /No wallet request was sent/); assert.match(text(tree.toJSON()), /could not be saved/);
});

test('unmount while fake wallet prompt is pending removes listeners; remount recovers uncertainty without reconnect or resubmit', async () => {
  const wallet = deferred(); const first = await ready({ wallet }); await click(first.tree, 'Review reservation'); await accept(first.tree); await click(first.tree, 'Confirm in wallet');
  assert.equal(first.fixture.controller.getSnapshot().receipts[0].status, 'awaiting-wallet'); const saved = first.fixture.stored();
  await unmount(first.tree); assert.ok([...first.fixture.listeners.values()].every(set => set.size === 0));
  const second = await mount({ saved }); assert.deepEqual(second.fixture.methods(), []); assert.equal(second.fixture.count('readClient'), 0); assert.equal(second.fixture.count('write'), 0);
  assert.match(text(second.tree.toJSON()), /Reserve units · unknown/); assert.equal(button(second.tree, 'Review deployment').props.disabled, true);
  await act(async () => { wallet.resolve(HASH); await flush(); });
  assert.equal(first.fixture.stored(), saved); assert.equal(second.fixture.count('write'), 0); assert.equal(second.fixture.controller.getSnapshot().receipts[0].status, 'unknown');
});

test('unmount during receipt wait preserves the public lock; remount Check receipt is explicitly read-only and accepts the matched happy path', async () => {
  const receipt = deferred(); const first = await ready({ receipt }); await click(first.tree, 'Review reservation'); await accept(first.tree); await click(first.tree, 'Confirm in wallet');
  const saved = first.fixture.stored(); await unmount(first.tree); const second = await mount({ saved });
  assert.match(text(second.tree.toJSON()), /Reserve units · unknown/); assert.deepEqual(second.fixture.methods(), []);
  await click(second.tree, 'Check receipt'); assert.equal(second.fixture.count('write'), 0); assert.deepEqual(second.fixture.methods(), []);
  assert.match(text(second.tree.toJSON()), /Reserve units · confirmed/); assert.equal(JSON.parse(second.fixture.stored()).pending.length, 0);
  await act(async () => { receipt.resolve({ status: 'success', transactionHash: HASH }); await flush(); });
  assert.equal(first.fixture.stored(), saved); assert.equal(second.fixture.count('write'), 0);
});

test('mismatched recovered receipt remains visibly unknown and locked until an explicit exact-match recheck', async () => {
  const receipt = deferred(); const first = await ready({ receipt });
  await click(first.tree, 'Review reservation'); await accept(first.tree); await click(first.tree, 'Confirm in wallet');
  const saved = first.fixture.stored(); await unmount(first.tree);
  const second = await mount({ saved }); second.fixture.controls.transactionPatch = { input: '0xdeadbeef' };
  await click(second.tree, 'Check receipt');
  assert.equal(second.fixture.controller.getSnapshot().receipts[0].status, 'unknown');
  assert.match(text(second.tree.toJSON()), /Reserve units · unknown/);
  assert.doesNotMatch(text(second.tree.toJSON()), /Reserve units · confirmed/);
  assert.equal(selectChain(second.tree).props.disabled, true);
  assert.equal(button(second.tree, 'Review deployment').props.disabled, true);
  assert.equal(button(second.tree, 'Import reference only').props.disabled, true);
  assert.equal(JSON.parse(second.fixture.stored()).pending.length, 1);
  assert.equal(second.fixture.count('write'), 0); assert.deepEqual(second.fixture.methods(), []);
  second.fixture.controls.transactionPatch = {};
  await click(second.tree, 'Check receipt');
  assert.match(text(second.tree.toJSON()), /Reserve units · confirmed/);
  assert.equal(JSON.parse(second.fixture.stored()).pending.length, 0);
  assert.equal(second.fixture.count('write'), 0); assert.deepEqual(second.fixture.methods(), []);
  await act(async () => { receipt.resolve({ status: 'success', transactionHash: HASH }); await flush(); });
});

test('unknown no-hash outcome exposes manual attach/check recovery, never an automatic retry', async () => {
  const { fixture: f, tree } = await ready({ walletError: new Error('Invented ambiguous outcome') });
  await click(tree, 'Review reservation'); await accept(tree); await click(tree, 'Confirm in wallet');
  assert.equal(f.count('write'), 1); assert.match(text(tree.toJSON()), /Reserve units · unknown/); assert.equal(button(tree, 'Check receipt'), undefined);
  await change(field(tree, 'Transaction hash from your wallet history'), HASH); await click(tree, 'Attach hash without resubmitting');
  assert.equal(f.count('write'), 1); await click(tree, 'Check receipt'); assert.equal(f.count('write'), 1); assert.match(text(tree.toJSON()), /Reserve units · confirmed/);
});

test('client renderer actually catches a child render error and Return to Sandbox invokes its escape once', async () => {
  let returns = 0; function Crashes() { throw new Error('Invented child render failure'); }
  const errors = [], original = console.error; console.error = (...args) => errors.push(args);
  try {
    const { tree } = await mount({}, React.createElement(LiveBoundary, { onReturn: () => returns++ }, React.createElement(Crashes)));
    assert.equal(tree.root.findByType(LiveBoundary).instance.state.failed, true);
    assert.equal(tree.root.findByProps({ role: 'alert' }).props['aria-labelledby'], 'live-unavailable-title');
    assert.match(text(tree.toJSON()), /saved transaction references have not been cleared/); assert.match(text(tree.toJSON()), /does not cancel a transaction/);
    await click(tree, 'Return to Sandbox'); assert.equal(returns, 1); assert.ok(errors.length > 0);
  } finally { console.error = original; }
});

test('client boundary catches a real rejected React.lazy loader; remount retains lazy failure instead of silently retrying', async () => {
  let attempts = 0; const promise = deferred(); const Lazy = React.lazy(() => { attempts++; return promise.promise; });
  const element = () => React.createElement(LiveBoundary, { onReturn() {} }, React.createElement(React.Suspense, { fallback: React.createElement('p', null, 'Loading optional Live') }, React.createElement(Lazy)));
  const errors = [], original = console.error; console.error = (...args) => errors.push(args);
  try {
    const first = await mount({}, element()); assert.match(text(first.tree.toJSON()), /Loading optional Live/);
    await act(async () => { promise.reject(Error('Invented optional module failure')); await flush(); });
    assert.match(text(first.tree.toJSON()), /The Live pilot could not open/); assert.equal(attempts, 1);
    await unmount(first.tree); const second = await mount({}, element());
    assert.match(text(second.tree.toJSON()), /The Live pilot could not open/); assert.equal(attempts, 1); assert.ok(errors.length >= 2);
  } finally { console.error = original; }
});

test('clipboard copy lifecycle ignores stale success after a new reference and keeps failure feedback local', async () => {
  const copy = deferred(); const calls = [];
  const original = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
  Object.defineProperty(globalThis, 'navigator', { configurable: true, value: { clipboard: { writeText(value) { calls.push(value); return copy.promise; } } } });
  try {
    const { tree } = await mount({}, React.createElement(ReferenceExport, { reference: `commonrate:1:5042002:${DEPLOYMENT}` }));
    await click(tree, 'Copy reference'); assert.equal(calls.length, 1);
    await act(async () => { tree.update(React.createElement(ReferenceExport, { reference: `commonrate:1:5042002:${OTHER_HASH}` })); copy.resolve(); await flush(); });
    assert.doesNotMatch(text(tree.toJSON()), /Reference copied/);
    globalThis.navigator.clipboard.writeText = async () => { throw Error('Invented clipboard rejection'); };
    await click(tree, 'Copy reference'); assert.match(text(tree.toJSON()), /Copy was unavailable/);
  } finally { if (original) Object.defineProperty(globalThis, 'navigator', original); else delete globalThis.navigator; }
});

test('a confirmed fake deployment fills the displayed hash and explicit Verify keeps its campaign visible', async () => {
  const { fixture: f, tree } = await mount();
  await change(selectChain(tree), '5042002'); await click(tree, 'Connect wallet');
  await prepareDeployment(tree); await click(tree, 'Confirm in wallet');
  assert.equal(f.count('write'), 1); assert.equal(f.controller.getSnapshot().savedHash, HASH);
  assert.equal(f.count('verifyNetwork'), 2); assert.equal(f.count('verifyCampaign'), 1);
  const displayedAfterDeployment = field(tree, 'Deployment transaction hash').props.value;
  const campaignBeforeVerify = text(tree.toJSON()).includes('Verified tiny campaign');
  const campaignReadsBefore = f.count('verifyCampaign');
  await click(tree, 'Verify / refresh reads');
  assert.deepEqual({ displayedAfterDeployment, campaignBeforeVerify,
    campaignAfterVerify: text(tree.toJSON()).includes('Verified tiny campaign'),
    campaignReadsAddedByVerify: f.count('verifyCampaign') - campaignReadsBefore,
  }, { displayedAfterDeployment: HASH, campaignBeforeVerify: true, campaignAfterVerify: true, campaignReadsAddedByVerify: 1 });
  assert.equal(f.count('write'), 1);
});

test('a new fake deployment replaces a prior verified pilot hash without synchronization-triggered rereads or extra writes', async () => {
  const { fixture: f, tree } = await ready();
  assert.equal(field(tree, 'Deployment transaction hash').props.value, DEPLOYMENT);
  const networkBefore = f.count('verifyNetwork'), campaignBefore = f.count('verifyCampaign');
  await prepareDeployment(tree); await click(tree, 'Confirm in wallet');
  assert.equal(field(tree, 'Deployment transaction hash').props.value, HASH);
  assert.equal(f.controller.getSnapshot().savedHash, HASH);
  assert.equal(f.count('verifyNetwork') - networkBefore, 2);
  assert.equal(f.count('verifyCampaign') - campaignBefore, 1);
  assert.equal(f.count('write'), 1);
  const calls = f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0]));
  await act(async () => { await flush(); });
  assert.deepEqual(f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0])), calls);
});

test('repriced fake deployment updates the authoritative hash after receipt while pending controls remain locked', async () => {
  const receipt = deferred(); const { fixture: f, tree } = await mount({ receipt, replacement: 'repriced' });
  await change(selectChain(tree), '5042002'); await click(tree, 'Connect wallet');
  await prepareDeployment(tree); await click(tree, 'Confirm in wallet');
  assert.equal(f.controller.getSnapshot().savedHash, HASH);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, HASH);
  assert.equal(field(tree, 'Deployment transaction hash').props.disabled, true);
  assert.equal(selectChain(tree).props.disabled, true);
  assert.equal(button(tree, 'Import reference only').props.disabled, true);
  assert.equal(f.count('write'), 1); assert.equal(f.count('verifyCampaign'), 0);
  const networkBefore = f.count('verifyNetwork');
  await act(async () => { receipt.resolve({ status: 'success', transactionHash: OTHER_HASH }); await flush(); });
  assert.equal(f.controller.getSnapshot().savedHash, OTHER_HASH);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH);
  assert.equal(f.controller.getSnapshot().snapshot.deploymentHash, OTHER_HASH);
  assert.equal(f.count('verifyNetwork'), networkBefore); assert.equal(f.count('verifyCampaign'), 1); assert.equal(f.count('write'), 1);
  assert.match(text(tree.toJSON()), /Deploy tiny pilot · confirmed/);
  assert.equal(field(tree, 'Deployment transaction hash').props.disabled, false);
});

test('import after a previously verified pilot preserves the new unverified draft when savedHash clears without requests', async () => {
  const { fixture: f, tree } = await ready();
  await change(field(tree, 'Pilot reference'), `commonrate:1:5042:${OTHER_HASH}`);
  const before = f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write', 'storage.set'].includes(event[0]));
  await act(async () => { tree.root.findByType('form').props.onSubmit({ preventDefault() {} }); await flush(); });
  assert.equal(f.controller.getSnapshot().savedHash, '');
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH);
  assert.equal(selectChain(tree).props.value, 5042);
  assert.doesNotMatch(text(tree.toJSON()), /Verified tiny campaign/);
  assert.deepEqual(f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write', 'storage.set'].includes(event[0])), before);
  const methods = f.methods(); await click(tree, 'Verify / refresh reads');
  assert.equal(f.controller.getSnapshot().savedHash, OTHER_HASH);
  assert.deepEqual(f.log.filter(event => event[0] === 'verifyCampaign').at(-1).slice(1, 3), [5042, OTHER_HASH]);
  assert.deepEqual(f.methods(), methods); assert.equal(f.count('write'), 0);
});

test('manual hash edits remain the draft across unrelated invalidation and make no automatic requests', async () => {
  const { fixture: f, tree } = await ready();
  const before = f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0]));
  await change(field(tree, 'Deployment transaction hash'), OTHER_HASH);
  assert.equal(f.controller.getSnapshot().savedHash, DEPLOYMENT);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH);
  await act(async () => { f.emit('accountsChanged'); await flush(); });
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH);
  assert.deepEqual(f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0])), before);
  await change(field(tree, 'Deployment transaction hash'), '');
  assert.equal(field(tree, 'Deployment transaction hash').props.value, '');
  assert.equal(f.controller.getSnapshot().savedHash, DEPLOYMENT);
  assert.deepEqual(f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0])), before);
});

test('network selection resets verified and edited hash drafts without requests or automatic connection', async () => {
  const { fixture: f, tree } = await ready();
  await change(field(tree, 'Deployment transaction hash'), OTHER_HASH);
  const before = f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0]));
  await change(selectChain(tree), '5042');
  assert.equal(field(tree, 'Deployment transaction hash').props.value, '');
  assert.equal(f.controller.getSnapshot().savedHash, ''); assert.equal(f.controller.getSnapshot().account, undefined);
  assert.doesNotMatch(text(tree.toJSON()), /Verified tiny campaign/);
  assert.deepEqual(f.log.filter(event => ['provider', 'readClient', 'walletClient', 'verifyNetwork', 'verifyCampaign', 'write'].includes(event[0])), before);
});

test('a blank lookup draft blocks all restored campaign reviews until explicit local hash restoration', async () => {
  const { fixture: f, tree } = await deployed();
  await change(field(tree, 'Deployment transaction hash'), ''); await click(tree, 'Check receipt');
  assert.equal(f.controller.getSnapshot().snapshot.deploymentHash, HASH);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, '');
  for (const label of campaignButtons) assert.equal(button(tree, label).props.disabled, true, label);
  const calls = externalActivity(f); await click(tree, "Use this pilot's hash");
  assert.equal(field(tree, 'Deployment transaction hash').props.value, HASH);
  assert.equal(f.controller.getSnapshot().review, undefined);
  assert.deepEqual(externalActivity(f), calls);
  assert.equal(button(tree, 'Review reservation').props.disabled, false);
  await change(field(tree, 'Deployment transaction hash'), ''); await click(tree, 'Check receipt');
  const reads = f.count('verifyCampaign'); await click(tree, 'Verify / refresh reads');
  assert.equal(f.count('verifyCampaign'), reads);
  assert.doesNotMatch(text(tree.toJSON()), /Verified tiny campaign/);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, ''); assert.equal(f.count('write'), 1);
});

test('a different lookup draft blocks even an eligible claim, local restoration is inert, and Verify follows the draft', async () => {
  const { fixture: f, tree } = await deployed();
  f.controls.snapshotPatch = { finalized: true, timestamp: 2100n, credit: 10000n };
  await change(field(tree, 'Deployment transaction hash'), OTHER_HASH); await click(tree, 'Check receipt');
  assert.equal(f.controller.getSnapshot().snapshot.deploymentHash, HASH);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH);
  for (const label of campaignButtons) assert.equal(button(tree, label).props.disabled, true, label);
  const calls = externalActivity(f); await click(tree, "Use this pilot's hash");
  assert.deepEqual(externalActivity(f), calls);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, HASH);
  assert.equal(button(tree, 'Review claim').props.disabled, false);
  await change(field(tree, 'Deployment transaction hash'), OTHER_HASH); await click(tree, 'Check receipt');
  const reads = f.count('verifyCampaign'); await click(tree, 'Verify / refresh reads');
  assert.equal(f.count('verifyCampaign'), reads + 1);
  assert.equal(f.controller.getSnapshot().snapshot.deploymentHash, OTHER_HASH);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, OTHER_HASH);
  assert.equal(button(tree, 'Review claim').props.disabled, false); assert.equal(f.count('write'), 1);
});

test('equivalent hexadecimal hash casing does not falsely block a receipt-restored campaign', async () => {
  const lower = `0x${'ab'.repeat(32)}`, upper = `0x${'AB'.repeat(32)}`;
  const wallet = deferred(), receipt = deferred(); wallet.resolve(lower); receipt.resolve({ status: 'success', transactionHash: lower });
  const { fixture: f, tree } = await deployed({ wallet, receipt });
  await change(field(tree, 'Deployment transaction hash'), upper); await click(tree, 'Check receipt');
  assert.equal(field(tree, 'Deployment transaction hash').props.value, upper);
  assert.equal(f.controller.getSnapshot().snapshot.deploymentHash, lower);
  assert.equal(button(tree, "Use this pilot's hash"), undefined);
  assert.equal(button(tree, 'Review reservation').props.disabled, false);
  await click(tree, 'Review reservation'); assert.equal(f.controller.getSnapshot().review.deploymentHash, lower);
  assert.equal(f.count('write'), 1);
});

test('local hash restoration remains locked during receipt checks and unresolved recovery, without resubmission', async () => {
  const { fixture: f, tree } = await deployed();
  await change(field(tree, 'Deployment transaction hash'), OTHER_HASH); await click(tree, 'Check receipt');
  const receipt = deferred(); f.controls.receipt = receipt; f.controls.transactionPatch = { input: '0xdeadbeef' };
  await click(tree, 'Check receipt');
  assert.equal(f.controller.getSnapshot().busy, true);
  assert.equal(button(tree, "Use this pilot's hash").props.disabled, true);
  for (const label of campaignButtons) assert.equal(button(tree, label).props.disabled, true, label);
  await act(async () => { receipt.resolve({ status: 'success', transactionHash: HASH }); await flush(); });
  assert.equal(f.controller.getSnapshot().busy, false);
  assert.match(text(tree.toJSON()), /Deploy tiny pilot · unknown/);
  assert.equal(button(tree, "Use this pilot's hash").props.disabled, true);
  assert.equal(field(tree, 'Deployment transaction hash').props.disabled, true);
  for (const label of campaignButtons) assert.equal(button(tree, label).props.disabled, true, label);
  f.controls.transactionPatch = {}; f.controls.receipt = undefined;
  await click(tree, 'Check receipt');
  const calls = externalActivity(f); await click(tree, "Use this pilot's hash");
  assert.deepEqual(externalActivity(f), calls);
  assert.equal(field(tree, 'Deployment transaction hash').props.value, HASH);
  assert.equal(button(tree, 'Review reservation').props.disabled, false); assert.equal(f.count('write'), 1);
});

test('the deadline helper explicitly fills exact checked seconds without requests or enabling wallet-blocked review', async () => {
  const { fixture: f, tree } = await mount();
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  await change(selectChain(tree), '5042002');
  f.controls.networkPromise = Promise.resolve({ chain: 5042002, block: 100n, timestamp: 1019n });
  await click(tree, 'Verify / refresh reads');
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '');
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, false);
  assert.equal(button(tree, 'Review deployment').props.disabled, true);
  const calls = externalActivity(f); await click(tree, deadlineHelperLabel);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T00:46:59Z');
  assert.deepEqual(externalActivity(f), calls); assert.deepEqual(f.methods(), []);
  assert.equal(button(tree, 'Review deployment').props.disabled, true);
  assert.equal(f.count('write'), 0);
});

test('explicit deadline assistance invalidates review and acceptance and round-trips exact seconds into a fresh review', async () => {
  const { fixture: f, tree } = await mount();
  await change(selectChain(tree), '5042002'); await click(tree, 'Connect wallet');
  f.controls.networkPromise = Promise.resolve({ chain: 5042002, block: 100n, timestamp: 1019n });
  await prepareDeployment(tree);
  assert.equal(tree.root.findByProps({ type: 'checkbox' }).props.checked, true);
  assert.equal(f.controller.getSnapshot().review.terms.deadline, 2000n);
  const calls = externalActivity(f); await click(tree, deadlineHelperLabel);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T00:46:59Z');
  assert.equal(f.controller.getSnapshot().review, undefined); assert.equal(review(tree).length, 0);
  assert.deepEqual(externalActivity(f), calls);
  await click(tree, 'Review deployment');
  assert.equal(f.controller.getSnapshot().review.terms.deadline, 2819n);
  assert.equal(tree.root.findByProps({ type: 'checkbox' }).props.checked, false);
  assert.equal(button(tree, 'Confirm in wallet').props.disabled, true); assert.equal(f.count('write'), 0);
});

test('manual deadlines survive refreshed verified time and network selection until the helper is explicitly used again', async () => {
  const { fixture: f, tree } = await mount();
  await change(selectChain(tree), '5042002'); await click(tree, 'Verify / refresh reads');
  await click(tree, deadlineHelperLabel);
  await change(field(tree, 'Explicit UTC deadline'), '1970-01-01T01:00:00Z');
  f.controls.networkPromise = Promise.resolve({ chain: 5042002, block: 101n, timestamp: 2000n });
  await click(tree, 'Verify / refresh reads');
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T01:00:00Z');
  const calls = externalActivity(f); await click(tree, deadlineHelperLabel);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T01:03:20Z');
  assert.deepEqual(externalActivity(f), calls);
  await change(selectChain(tree), '5042');
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T01:03:20Z');
  assert.equal(f.count('write'), 0);
});

test('missing or mismatched checked network data cannot supply a deadline or change a manual draft', async () => {
  const { fixture: f, tree } = await mount();
  await change(field(tree, 'Explicit UTC deadline'), '1970-01-01T01:00:00Z');
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  await change(selectChain(tree), '5042002');
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  f.controls.networkPromise = Promise.resolve({ chain: 5042, block: 100n, timestamp: 1000n });
  await click(tree, 'Verify / refresh reads');
  assert.equal(f.controller.getSnapshot().network.chain, 5042);
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T01:00:00Z');
  assert.deepEqual(f.methods(), []); assert.equal(f.count('write'), 0);
});

test('deadline assistance accepts exact UTC bounds and fails closed on invalid or overflowing checked timestamps', async () => {
  const max = 253402300799n;
  const rows = [
    { timestamp: 0n, expected: '1970-01-01T00:30:00Z' },
    { timestamp: max - 1800n, expected: '9999-12-31T23:59:59Z' },
    ...[-1n, max - 1799n, max + 1n, undefined, 1000, '1000'].map(timestamp => ({ timestamp })),
  ];
  for (const row of rows) {
    const { fixture: f, tree } = await mount();
    await change(selectChain(tree), '5042002');
    await change(field(tree, 'Explicit UTC deadline'), '1970-01-01T01:00:00Z');
    f.controls.networkPromise = Promise.resolve({ chain: 5042002, block: 100n, timestamp: row.timestamp });
    await click(tree, 'Verify / refresh reads');
    assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T01:00:00Z');
    assert.equal(button(tree, deadlineHelperLabel).props.disabled, !row.expected, `timestamp ${String(row.timestamp)}`);
    if (row.expected) {
      const calls = externalActivity(f); await click(tree, deadlineHelperLabel);
      assert.equal(field(tree, 'Explicit UTC deadline').props.value, row.expected);
      assert.deepEqual(externalActivity(f), calls);
    }
    assert.equal(f.count('write'), 0); await unmount(tree);
  }
});

test('deadline assistance stays disabled during independent read-busy and unknown receipt recovery states', async () => {
  const { fixture: f, tree } = await mount();
  await change(selectChain(tree), '5042002'); await click(tree, 'Verify / refresh reads');
  const network = deferred(); f.controls.networkPromise = network.promise;
  await click(tree, 'Verify / refresh reads');
  assert.equal(f.controller.getSnapshot().busy, true); assert.equal(f.controller.getSnapshot().receipts.length, 0);
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  await act(async () => { network.resolve({ chain: 5042002, block: 101n, timestamp: 1000n }); await flush(); });
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, false);
  await click(tree, 'Connect wallet'); await prepareDeployment(tree);
  const receipt = deferred(); f.controls.receipt = receipt; f.controls.transactionPatch = { input: '0xdeadbeef' };
  await click(tree, 'Confirm in wallet');
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  await act(async () => { receipt.resolve({ status: 'success', transactionHash: HASH }); await flush(); });
  assert.equal(f.controller.getSnapshot().busy, false); assert.match(text(tree.toJSON()), /Deploy tiny pilot · unknown/);
  assert.equal(button(tree, deadlineHelperLabel).props.disabled, true);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T00:33:20Z');
  f.controls.transactionPatch = {}; f.controls.receipt = undefined; await click(tree, 'Check receipt');
  const calls = externalActivity(f); await click(tree, deadlineHelperLabel);
  assert.equal(field(tree, 'Explicit UTC deadline').props.value, '1970-01-01T00:46:40Z');
  assert.deepEqual(externalActivity(f), calls); assert.equal(f.count('write'), 1);
});
