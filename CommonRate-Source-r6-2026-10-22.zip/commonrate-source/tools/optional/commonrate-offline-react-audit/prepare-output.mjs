import { lstat, realpath, mkdir } from 'node:fs/promises';
import { resolve, relative, dirname, basename, isAbsolute, sep } from 'node:path';

export function isWithin(root, target) {
  const rel = relative(root, target);
  return rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
}

// Resolve even a nonexistent suffix through its nearest existing ancestor.
// lstat distinguishes a dangling symlink from an absent directory; it must fail.
export async function canonicalProspectivePath(input) {
  let cursor = resolve(input);
  const suffix = [];
  for (;;) {
    try {
      await lstat(cursor);
      const ancestor = await realpath(cursor);
      return { path: resolve(ancestor, ...suffix.reverse()), missingCount: suffix.length };
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      // A dangling symlink has an lstat entry but cannot be canonicalized.
      try { await lstat(cursor); throw new Error('Output path contains a dangling symlink.'); }
      catch (check) { if (check.code !== 'ENOENT') throw check; }
      const parent = dirname(cursor);
      if (parent === cursor) throw new Error('Output path has no resolvable existing ancestor.');
      suffix.push(basename(cursor)); cursor = parent;
    }
  }
}

export async function prepareFreshOutput(input, protectedDirectories) {
  const requested = resolve(input);
  try { await lstat(requested); throw new Error('Output must be a new directory: all existing targets, including symlinks, are rejected.'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  const roots = await Promise.all(protectedDirectories.map(path => realpath(path)));
  const prospective = await canonicalProspectivePath(requested);
  const rejectProtected = path => {
    if (roots.some(root => isWithin(root, path))) throw new Error('Canonical output must be outside caller source, caller dependencies, and the sidecar.');
  };
  rejectProtected(prospective.path);
  // Do not create arbitrary ancestor trees. This also keeps admission bounded.
  if (prospective.missingCount !== 1) throw new Error('Output parent must already exist. Create a separate report parent first.');
  const parent = await realpath(dirname(prospective.path));
  const output = resolve(parent, basename(prospective.path));
  rejectProtected(output);
  // No recursive option: mkdir is exclusive and rejects files, directories,
  // normal symlinks and dangling symlinks created before admission completes.
  try { await mkdir(output, { mode: 0o700 }); }
  catch (error) {
    if (error.code === 'EEXIST') throw new Error('Output must be a new directory: another target already exists.');
    throw error;
  }
  const admitted = await realpath(output);
  rejectProtected(admitted);
  if (admitted !== output) throw new Error('Output identity changed during admission.');
  return output;
}
