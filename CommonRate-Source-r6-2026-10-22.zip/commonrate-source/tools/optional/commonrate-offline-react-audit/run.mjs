import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, mkdtemp, copyFile, symlink, rm, realpath } from 'node:fs/promises';
import { resolve, relative, dirname, isAbsolute, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { prepareFreshOutput } from './prepare-output.mjs';

const here = await realpath(dirname(fileURLToPath(import.meta.url)));
const ownRequire = createRequire(import.meta.url);
const args = process.argv.slice(2);
const usage = 'node run.mjs --source-dir <project/src> --dependencies-dir <project/node_modules> --out <new-report-directory> [--label <short-name>]';
const options = {};
for (let i = 0; i < args.length; i += 2) {
  if (!['--source-dir', '--dependencies-dir', '--out', '--label'].includes(args[i]) || !args[i + 1] || args[i + 1].startsWith('--')) throw new Error(usage);
  if (args[i] in options) throw new Error(`Duplicate option: ${args[i]}`);
  options[args[i]] = args[i + 1];
}
if (!options['--source-dir'] || !options['--dependencies-dir'] || !options['--out']) throw new Error(usage);
const label = options['--label'] ?? 'caller-source';
if (!/^[a-zA-Z0-9._-]{1,80}$/.test(label)) throw new Error('Label must be a short identifier, not a path.');
const source = await realpath(resolve(options['--source-dir']));
const dependencies = await realpath(resolve(options['--dependencies-dir']));
const out = await prepareFreshOutput(options['--out'], [source, dependencies, here]);
const within = (root, file) => { const rel = relative(root, file); return rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel); };
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = file => readFile(file, 'utf8').then(JSON.parse);
let work;
let report = { label, status: 'INCOMPLETE', sourceChangedDuringRun: false, runtimeNetworkPolicy: 'Test tripwires deny fetch, XMLHttpRequest, WebSocket, Node HTTP(S), sockets, TLS and common DNS for trusted source; not an OS security sandbox or guarantee against malicious source.', outputPolicy: 'Canonical protected-root checks, exclusive fresh output directory, exclusive report-file creation; not kernel-enforced confinement or a guarantee against adversarial filesystem races.', actualProviderCompatibility: 'not tested', browserEvidence: 'not tested' };
const clean = value => String(value).split(source).join('<caller-source>').split(dependencies).join('<caller-dependencies>').split(here).join('<sidecar>').split(work ?? '\0').join('<disposable-stage>').split(out).join('<report-output>');
const emit = (file, value) => writeFile(resolve(out, file), typeof value === 'string' ? clean(value) : JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
async function runNode(argv, cwd) {
  return new Promise((resolveRun, reject) => {
    const child = spawn(process.execPath, argv, { cwd, env: { ...process.env, NODE_OPTIONS: '', NODE_PATH: '' }, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = ''; child.stdout.on('data', x => { output += x; }); child.stderr.on('data', x => { output += x; });
    child.on('error', reject); child.on('close', (code, signal) => resolveRun({ code, signal, output }));
  });
}
try {
  const callerVersions = {}, isolatedVersions = {}, dependencyEvidence = [];
  for (const name of ['react', 'react-dom']) {
    const file = resolve(dependencies, name, 'package.json'); const bytes = await readFile(file); callerVersions[name] = JSON.parse(bytes).version;
    dependencyEvidence.push({ role: 'caller', package: name, version: callerVersions[name], packageJsonSHA256: sha(bytes) });
  }
  const isolatedPackageDirs = {};
  for (const name of ['react', 'react-dom', 'react-test-renderer']) {
    const file = ownRequire.resolve(`${name}/package.json`); const bytes = await readFile(file); isolatedVersions[name] = JSON.parse(bytes).version; isolatedPackageDirs[name] = dirname(file);
    dependencyEvidence.push({ role: 'sidecar', package: name, version: isolatedVersions[name], packageJsonSHA256: sha(bytes) });
  }
  report.versions = { node: process.version, caller: callerVersions, sidecar: isolatedVersions };
  if (new Set([...Object.values(callerVersions), ...Object.values(isolatedVersions)]).size !== 1) {
    throw new Error(`React version mismatch. Caller ${JSON.stringify(callerVersions)}, sidecar ${JSON.stringify(isolatedVersions)}. Update the sidecar pins explicitly; no automatic install is performed.`);
  }
  const esbuild = ownRequire(resolve(dependencies, 'esbuild'));
  for (const name of ['esbuild', 'viem']) {
    const bytes = await readFile(resolve(dependencies, name, 'package.json'));
    dependencyEvidence.push({ role: 'caller', package: name, version: JSON.parse(bytes).version, packageJsonSHA256: sha(bytes) });
  }
  report.versions.esbuild = esbuild.version;
  await emit('dependency-evidence.json', dependencyEvidence);
  const template = await readFile(resolve(here, 'controller-adapter.template.ts'), 'utf8');
  await emit('controller-adapter.template.ts', template);
  const harnessFiles = ['run.mjs', 'prepare-output.mjs', 'output-containment.test.mjs', 'interaction.test.mjs', 'fixture.mjs', 'block-network.mjs', 'safety-canary.mjs', 'controller-adapter.template.ts', 'package.json', 'package-lock.json'];
  const harnessHashes = [];
  for (const file of harnessFiles) harnessHashes.push({ file, sha256: sha(await readFile(resolve(here, file))) });
  await emit('harness-hashes.json', harnessHashes);
  work = await mkdtemp(resolve(out, '.stage-'));
  const buildOptions = (root, write) => ({
    absWorkingDir: work,
    stdin: { contents: `export { default as LivePilot } from ${JSON.stringify(root + '/live/LivePilot.tsx')}; export { default as LiveBoundary } from ${JSON.stringify(root + '/components/LiveBoundary.tsx')}; export { ReferenceExport } from ${JSON.stringify(root + '/live/PilotReference.tsx')};`, resolveDir: root, loader: 'tsx' },
    outfile: resolve(work, 'component-under-test.cjs'), bundle: true, platform: 'node', format: 'cjs', jsx: 'automatic', sourcemap: false, metafile: true, write,
    external: ['react', 'react/jsx-runtime'], nodePaths: [dependencies], loader: { '.css': 'empty' },
    plugins: [{ name: 'offline-existing-constructor-injection', setup(build) {
      build.onResolve({ filter: /^\.\/controller$/ }, args => args.importer === root + '/live/LivePilot.tsx' ? { path: 'controller-adapter', namespace: 'audit' } : undefined);
      build.onLoad({ filter: /.*/, namespace: 'audit' }, () => ({ loader: 'ts', resolveDir: root, contents: template.replace('__AUDIT_SOURCE__', root.replaceAll('\\', '/')) }));
    } }],
  });
  // Dependency discovery parses/bundles only. Application code is never executed here.
  const discovery = await esbuild.build(buildOptions(source, false));
  const necessary = [];
  for (const input of Object.keys(discovery.metafile.inputs)) {
    if (input === '<stdin>' || input.startsWith('audit:')) continue;
    const file = resolve(work, input); const actual = await realpath(file);
    if (within(source, actual)) necessary.push(relative(source, actual));
    else if (!within(dependencies, actual)) throw new Error('Source dependency escapes both supplied source and dependency roots; bounded staging refused.');
  }
  const staged = resolve(work, 'source'); await mkdir(staged);
  const sourceFiles = [];
  for (const file of [...new Set(necessary)].sort()) {
    const bytes = await readFile(resolve(source, file)); const target = resolve(staged, file);
    await mkdir(dirname(target), { recursive: true }); await writeFile(target, bytes);
    const hash = sha(bytes);
    if (sha(await readFile(resolve(source, file))) !== hash || sha(await readFile(target)) !== hash) throw new Error('Caller source changed during staging.');
    sourceFiles.push({ file: file.split(sep).join('/'), sha256: hash });
  }
  if (!sourceFiles.some(x => x.file === 'live/LivePilot.tsx') || !sourceFiles.some(x => x.file === 'live/controller.ts')) throw new Error('Required Live source was not discovered.');
  await emit('tested-source-hashes.json', { label, sourceFiles });
  report.stagedSourceCount = sourceFiles.length;
  const built = await esbuild.build(buildOptions(staged, true));
  const normalizeInput = input => {
    if (input === '<stdin>' || input.startsWith('audit:')) return input;
    const file = resolve(work, input);
    if (within(staged, file)) return `<source>/${relative(staged, file).split(sep).join('/')}`;
    if (within(dependencies, file)) return `<dependencies>/${relative(dependencies, file).split(sep).join('/')}`;
    throw new Error('Unexpected final bundle input outside staged source and caller dependencies.');
  };
  await emit('bundle-inputs.json', Object.entries(built.metafile.inputs).map(([input, info]) => ({ input: normalizeInput(input), bytes: info.bytes, imports: info.imports.map(imp => ({ kind: imp.kind, external: !!imp.external, path: imp.external ? imp.path : normalizeInput(imp.path) })) })));
  await emit('transformation.json', { sourceChanged: false, templateSHA256: sha(template), exactSubstitution: 'Replace __AUDIT_SOURCE__ in the recorded adapter template with the disposable staged source root.', interception: "Only the ./controller import from staged live/LivePilot.tsx resolves to the adapter. Other source imports remain unchanged.", semanticChange: 'The adapter subclasses the real LiveController and supplies fixture.dependencies as its existing fourth constructor argument, then records the instance. No controller method is replaced.', compiler: { jsx: 'automatic', platform: 'node', format: 'cjs', cssLoader: 'empty', external: ['react', 'react/jsx-runtime'] } });
  for (const file of ['interaction.test.mjs', 'fixture.mjs', 'block-network.mjs', 'safety-canary.mjs']) await copyFile(resolve(here, file), resolve(work, file));
  await mkdir(resolve(work, 'node_modules'));
  for (const [name, target] of Object.entries(isolatedPackageDirs)) await symlink(target, resolve(work, 'node_modules', name), 'dir');
  const canary = await runNode(['safety-canary.mjs'], work); await emit('network-canary.txt', canary.output);
  if (canary.code !== 0) throw new Error('Runtime network-denial canary failed.');
  const result = await runNode(['--import', './block-network.mjs', '--test', '--test-reporter=tap', '--test-concurrency=1', 'interaction.test.mjs'], work);
  await emit('test-results.tap', result.output);
  const count = key => Number(result.output.match(new RegExp(`^# ${key} (\\d+)$`, 'm'))?.[1] ?? NaN);
  report.tests = { total: count('tests'), passed: count('pass'), failed: count('fail'), skipped: count('skipped'), exitCode: result.code, signal: result.signal };
  for (const file of sourceFiles) if (sha(await readFile(resolve(source, file.file))) !== file.sha256) report.sourceChangedDuringRun = true;
  if (report.sourceChangedDuringRun) throw new Error('Caller source changed during test; result cannot attest its current state.');
  if (result.code !== 0 || !Number.isFinite(report.tests.total) || report.tests.total !== 43 || report.tests.passed !== 43 || report.tests.failed !== 0) throw new Error('The bounded 43-case interaction matrix did not pass completely.');
  report.status = 'PASS'; report.networkGuardCanariesPassed = 9; report.runtimeNetworkAttempts = 0; report.realWalletActions = 0;
  await rm(work, { recursive: true, force: true }); report.disposableStage = 'removed after success';
  console.log(`PASS: ${label}: ${report.tests.passed}/${report.tests.total} tests; ${sourceFiles.length} staged source files; staging removed.`);
} catch (error) {
  report.status = 'FAIL'; report.error = clean(error.stack ?? error.message ?? error);
  report.disposableStage = work ? 'retained under report output for local failed-case diagnosis; never include in portable candidate' : 'not created';
  console.error(clean(error.message ?? error)); process.exitCode = 1;
} finally {
  report.finishedAtUTC = new Date().toISOString(); await emit('RESULT.json', report);
}
