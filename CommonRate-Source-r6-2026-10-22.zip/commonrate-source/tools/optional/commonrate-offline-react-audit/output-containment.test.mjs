import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, symlink, lstat, readdir, rm, realpath } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { prepareFreshOutput } from './prepare-output.mjs';

const here = dirname(fileURLToPath(import.meta.url));
async function fixture(callback) {
  const root = await mkdtemp(resolve(tmpdir(), 'commonrate-output-regression-'));
  const source = resolve(root, 'source'), dependencies = resolve(root, 'dependencies'), sidecar = resolve(root, 'sidecar'), reports = resolve(root, 'reports');
  for (const path of [source, dependencies, sidecar, reports]) { await mkdir(path); await writeFile(resolve(path, 'sentinel.txt'), 'untouched'); }
  try { await callback({ root, source, dependencies, sidecar, reports, protectedDirectories: [source, dependencies, sidecar] }); }
  finally { await rm(root, { recursive: true, force: true }); }
}
async function unchanged(f) {
  for (const root of f.protectedDirectories) {
    assert.deepEqual(await readdir(root), ['sentinel.txt']);
    assert.equal(await readFile(resolve(root, 'sentinel.txt'), 'utf8'), 'untouched');
  }
}
for (const target of ['source', 'dependencies', 'sidecar']) test(`rejects a fresh output directly inside protected ${target}`, async () => fixture(async f => {
  await assert.rejects(prepareFreshOutput(resolve(f[target], 'new-report'), f.protectedDirectories), /Canonical output/); await unchanged(f);
}));
for (const target of ['source', 'dependencies', 'sidecar']) test(`rejects a symlinked output parent into protected ${target}`, async () => fixture(async f => {
  await symlink(f[target], resolve(f.root, 'alias'), 'dir');
  await assert.rejects(prepareFreshOutput(resolve(f.root, 'alias', 'report'), f.protectedDirectories), /Canonical output/); await unchanged(f);
}));
test('rejects chained symlink parents with a nonexistent suffix into source before creating anything', async () => fixture(async f => {
  await symlink(f.source, resolve(f.root, 'first'), 'dir'); await symlink(resolve(f.root, 'first'), resolve(f.root, 'second'), 'dir');
  await assert.rejects(prepareFreshOutput(resolve(f.root, 'second', 'missing', 'report'), f.protectedDirectories), /Canonical output/); await unchanged(f);
}));
test('rejects every existing output target, including directories without RESULT and normal/dangling symlinks', async () => fixture(async f => {
  const directory = resolve(f.reports, 'existing'); await mkdir(directory);
  const file = resolve(f.reports, 'file'); await writeFile(file, 'untouched');
  const link = resolve(f.reports, 'source-link'); await symlink(f.source, link, 'dir');
  const dangling = resolve(f.reports, 'dangling'); await symlink(resolve(f.root, 'missing-target'), dangling, 'dir');
  for (const target of [directory, file, link, dangling]) await assert.rejects(prepareFreshOutput(target, f.protectedDirectories), /existing targets/);
  assert.deepEqual(await readdir(directory), []); assert.equal(await readFile(file, 'utf8'), 'untouched'); await unchanged(f);
}));
test('rejects pre-existing report child symlink to caller source without overwriting its sentinel', async () => fixture(async f => {
  const out = resolve(f.reports, 'existing'); await mkdir(out);
  await symlink(resolve(f.source, 'sentinel.txt'), resolve(out, 'dependency-evidence.json'));
  await assert.rejects(prepareFreshOutput(out, f.protectedDirectories), /existing targets/); await unchanged(f);
  assert.equal((await lstat(resolve(out, 'dependency-evidence.json'))).isSymbolicLink(), true);
}));
test('rejects missing report parents outside protected roots without creating ancestor trees', async () => fixture(async f => {
  await assert.rejects(prepareFreshOutput(resolve(f.reports, 'missing', 'report'), f.protectedDirectories), /parent must already exist/);
  assert.deepEqual(await readdir(f.reports), ['sentinel.txt']); await unchanged(f);
}));
test('admits a safe canonical fresh leaf through an external symlink parent exactly once', async () => fixture(async f => {
  await symlink(f.reports, resolve(f.root, 'safe-alias'), 'dir');
  const output = await prepareFreshOutput(resolve(f.root, 'safe-alias', 'fresh'), f.protectedDirectories);
  assert.equal(output, resolve(await realpath(f.reports), 'fresh')); assert.deepEqual(await readdir(output), []);
  await assert.rejects(prepareFreshOutput(output, f.protectedDirectories), /existing targets/); await unchanged(f);
}));
test('full CLI rejects reviewer symlink-parent and existing-child-symlink reproductions before any report write', async () => fixture(async f => {
  await symlink(f.source, resolve(f.root, 'source-alias'), 'dir');
  const existing = resolve(f.reports, 'existing'); await mkdir(existing);
  await symlink(resolve(f.source, 'sentinel.txt'), resolve(existing, 'dependency-evidence.json'));
  for (const out of [resolve(f.root, 'source-alias', 'report'), resolve(f.root, 'source-alias', 'missing', 'report'), existing]) {
    const result = spawnSync(process.execPath, [resolve(here, 'run.mjs'), '--source-dir', f.source, '--dependencies-dir', f.dependencies, '--out', out], { encoding: 'utf8', env: { ...process.env, NODE_OPTIONS: '', NODE_PATH: '' } });
    assert.equal(result.status, 1); assert.match(result.stderr, /Canonical output|existing targets/);
  }
  assert.deepEqual(await readdir(existing), ['dependency-evidence.json']); await unchanged(f);
}));
