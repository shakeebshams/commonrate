# CommonRate offline React audit sidecar

A portable, test-only 43-case interaction runner for trusted, caller-supplied CommonRate Live source. **No application runtime is included.** It does not edit app source, package metadata or lockfiles, start a service, install a browser, or use a real wallet/provider.

## Install and run

Node 20 or newer is required. The caller supplies an existing dependency directory containing `esbuild`, `viem`, React and React DOM. Tested with Node 24.19.0, esbuild 0.25.12 and React 18.3.1.

```sh
npm ci --ignore-scripts --no-audit --no-fund --registry=https://registry.npmjs.org
npm test
node run.mjs \
  --source-dir "$PROJECT/src" \
  --dependencies-dir "$PROJECT/node_modules" \
  --out "$REPORTS/new-run" \
  --label current-source
```

Only this sidecar's exact React/react-dom/react-test-renderer 18.3.1 pins and their locked dependencies are installed. All lockfile tarballs use the official npm registry. The caller's React and React DOM must exactly match the sidecar's installed React, React DOM and renderer. A mismatch fails before source staging; the runner never automatically installs or upgrades anything.

The report parent directory must already exist. The output itself must be a new directory outside the canonical app source, dependency directory and sidecar. The runner canonicalizes symlinked parents and nonexistent suffixes, rejects **every existing output target**, creates the leaf directory exclusively with private permissions, and writes report files with exclusive `wx` creation. It will not reuse a report directory merely because RESULT.json is absent. `npm test` runs 12 output-containment regressions and the network-guard canary before project testing.

For an offline installation after the packages have been cached, add `--offline --cache <your-cache-directory>` to `npm ci`. Tests themselves are always guarded against network use.

## What runs

1. Discover the transitive source set from `live/LivePilot.tsx`, `live/PilotReference.tsx` and `components/LiveBoundary.tsx` without executing application code.
2. Copy/hash only that source set into a disposable staging tree under the report output. Reject imports outside the supplied source/dependency roots. No permanent second app runtime is maintained.
3. Bundle the staged source with the caller's existing esbuild/viem dependencies read-only. All React imports use the matching sidecar instance.
4. Apply the recorded `controller-adapter.template.ts` at one build-time import edge: LivePilot's `./controller`. The subclass supplies the real controller's existing fourth dependency-injection argument, then records the instance. No controller methods or component handlers are rewritten. CSS is loaded as empty, so this cannot provide visual evidence.
5. Run network-denial canaries, then the 43-case React renderer matrix with fake provider/storage/read/write/verification dependencies. The actual React hooks, component handlers, subscription updates, controller guards and receipt recovery execute. The provider allows only invented account/chain responses. Fake wallet writes only record arguments in memory.
6. Rehash the caller sources after the run. A changed caller source invalidates the result. Remove successful staging; retain failed staging locally for diagnosis and a failed-case reproducer. Never include that failed staging in a reusable sidecar artifact or upload it automatically.

## Reports

- `RESULT.json`: scoped pass/fail, versions, test counts, network policy and limitations.
- `test-results.tap`: full matrix output.
- `tested-source-hashes.json`: exact files/SHA-256 values tested.
- `controller-adapter.template.ts` and `transformation.json`: exact adapter template, substitution rule, interception edge and compiler transformations.
- `dependency-evidence.json`, `harness-hashes.json`, `bundle-inputs.json`: tool/input provenance without private machine paths.
- `network-canary.txt`: guard self-test result.

Report paths are normalized to labels such as `<caller-source>` and `<dependencies>`. The reusable source package contains no frozen app copy, built app bundle, credentials, report staging tree or machine-specific path. You may keep source-hash evidence separately without maintaining a duplicate runtime.

## Scope and limits

The matrix covers mount inertia, Verify vs Connect, no-provider/embedded gates, reference import/draft clearing, exact review and fresh acceptance, cancellation/edit invalidation, independent exact approvals, deployment form validation, rejected/ambiguous outcomes, duplicate callbacks and pending locks, account/chain invalidation, storage failure, real unmount/remount cleanup and manual recovery, actual client error-boundary catching, React.lazy rejected-loader caching and clipboard lifecycle. The receipt-mismatch case added in revision2 explicitly returns mismatched recovery calldata and asserts that the UI remains visibly unknown and locked before a subsequent exact-match check succeeds. The prior 26-case matrix covered matched recovery only; it did not establish rejection of mismatched receipt calldata.

This is **mocked UI/controller transport evidence**, not genuine provider, wallet extension or Arc compatibility. It does not re-test real provenance, issuer behavior, gas, token transfer, finality or a financial transaction. It mounts the Live component directly rather than the entire App or deployed site.

The renderer is not a DOM or browser. Focus/select refs are no-op stubs. No focus restoration, keyboard navigation, screen reader, real disabled-event suppression, browser form defaults, details visibility, responsive pixels, CSS, layout, performance or React StrictMode effect replay is established. Normal test clicks check the rendered disabled prop; duplicate-callback cases intentionally stress retained callbacks, not browser timing.

Runtime fetch, XHR, WebSocket, Node HTTP(S), socket, TLS and common DNS calls throw before transport, and the suite fails if any such attempt was caught by application code. These are test tripwires for trusted project source, **not an OS security sandbox or a guarantee against intentionally malicious source**. Output-path admission covers the tested canonical paths and exclusive creation behavior; it is not a claim of kernel-enforced confinement, resistance to an adversarial concurrent filesystem race, or permission to run untrusted source.

The maintained matrix intentionally expects exactly 43 cases. Changes to app structure, semantics or React version may require an explicit sidecar test update. A passing result applies only to its recorded source hashes. No publication, upload or app integration is performed by this runner.

## Revision history

Revision2 corrected the original candidate's output-ownership defect: lexical containment and the absence of RESULT.json did not make an existing or symlinked output safe. The original artifact is preserved as non-distributable historical evidence; revision2 was independently reviewed. Revision3 was independently reviewed separately; revision4 must receive its own review before inclusion. Its original 22/26 interaction results remain historical mocked-test evidence, not evidence that the unsafe original output runner was acceptable.

## Hash-draft synchronization regressions (revision 3)

Ten separately labeled cases extend the reviewed 27-case matrix to 37. The first six cover the hash synchronization and draft invariants. These cover successful deployment from a blank input, deployment replacing a prior verified pilot, a repriced deployment hash while pending controls remain locked, import after a prior verified pilot, manual draft edits across unrelated invalidation, and explicit network reset. They distinguish the controller’s existing post-receipt verification from any extra request caused by the UI synchronization; the synchronization must make no extra read, account or wallet request.

Before the fix, the rendered fake-deployment reproducer confirms controller.savedHash changes while the displayed input remains blank, then explicit Verify removes the campaign with a network-only check. The historical failed reproducer is retained separately. The candidate still contains no application source or fix; the caller must supply the exact source version to audit. Reviewed v2 output-containment protections and its original 27-case evidence are preserved separately.

Four additional cases address the adjacent receipt-restored campaign/lookup-draft mismatch. Blank or different drafts block all six campaign-review buttons; an explicit local-only restore action makes no provider, reader, storage or wallet write call; Verify continues to use the draft; valid hex-body case equivalence does not falsely block; and busy/unknown receipt recovery keeps restoration and review actions locked. The original diagnostic preserves the observed distinction between the explicitly displayed campaign and the draft, rather than claiming a hidden transaction-target change.

## Explicit checked-time deadline helper (revision 4)

Six cases extend the independently reviewed 37-case matrix to 43. They require explicit use of the currently selected network’s last checked timestamp, adding exactly 1,800 seconds with no rounding. They check the real controller parser receives the same exact seconds; using the helper invalidates prior review and acceptance; manual deadlines survive later network refreshes and chain selection; missing/mismatched/type-invalid/out-of-range state fails closed; and ordinary read-busy and unknown-receipt recovery independently lock the helper. Local use must make no provider, reader, storage or wallet write call and must not enable an otherwise wallet-blocked deployment review.

The timestamp table includes zero, the highest supported timestamp that can still add 30 minutes, one second beyond that boundary, negative, missing and non-bigint values. Malformed injected verification data is synthetic defensive coverage, not evidence that a genuine provider will return or accept it. A timestamp ending in :59 is also tested through the actual UI and review parser. The helper’s freshness caveat and checked basis are source-rendered UI; this package does not establish visual layout, browser accessibility or real chain-time freshness.

Revision 4 example evidence applies to the final frozen checkpoint09 source only. Prior v3 and all historical failing evidence remain separately preserved. No interim candidate result or duplicated application runtime is packaged. Source changes, including the UI helper, remain the application owner’s work; this sidecar only stages and tests the caller’s source.
