import './block-network.mjs';
import assert from 'node:assert/strict';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import tls from 'node:tls';
import dns from 'node:dns';
for (const [label, attempt] of [
  ['fetch', () => fetch('https://audit.invalid')],
  ['http.request', () => http.request('http://audit.invalid')],
  ['https.get', () => https.get('https://audit.invalid')],
  ['net.connect', () => net.connect(1, 'audit.invalid')],
  ['tls.connect', () => tls.connect(1, 'audit.invalid')],
  ['dns.lookup', () => dns.lookup('audit.invalid', () => {})],
  ['dns.promises.lookup', () => dns.promises.lookup('audit.invalid')],
  ['WebSocket', () => new WebSocket('wss://audit.invalid')],
  ['XMLHttpRequest', () => new XMLHttpRequest()],
]) {
  assert.throws(attempt, /OFFLINE AUDIT: forbidden network attempt/);
  assert.equal(globalThis.__AUDIT_NETWORK_ATTEMPTS__.at(-1), label);
}
assert.equal(globalThis.__AUDIT_NETWORK_ATTEMPTS__.length, 9);
console.log('PASS: 9 network-denial canaries threw synchronously before transport; no request was sent.');
