import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import tls from 'node:tls';
import dns from 'node:dns';
import { syncBuiltinESMExports } from 'node:module';
globalThis.__AUDIT_NETWORK_ATTEMPTS__ = [];
const deny = label => (...args) => {
  globalThis.__AUDIT_NETWORK_ATTEMPTS__.push(label);
  throw new Error(`OFFLINE AUDIT: forbidden network attempt: ${label}`);
};
globalThis.fetch = deny('fetch');
globalThis.XMLHttpRequest = class { constructor() { deny('XMLHttpRequest')(); } };
globalThis.WebSocket = class { constructor() { deny('WebSocket')(); } };
for (const [name, mod, keys] of [
  ['http', http, ['request', 'get']], ['https', https, ['request', 'get']],
  ['net', net, ['connect', 'createConnection']], ['tls', tls, ['connect']],
  ['dns', dns, ['lookup', 'resolve', 'resolve4', 'resolve6']],
]) for (const key of keys) mod[key] = deny(`${name}.${key}`);
net.Socket.prototype.connect = deny('net.Socket.connect');
for (const key of ['lookup', 'resolve', 'resolve4', 'resolve6']) dns.promises[key] = deny(`dns.promises.${key}`);
syncBuiltinESMExports();
