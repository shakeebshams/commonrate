export const ACCOUNT = '0x1111111111111111111111111111111111111111';
export const CAMPAIGN = '0x2222222222222222222222222222222222222222';
export const HASH = `0x${'44'.repeat(32)}`;
export const DEPLOYMENT = `0x${'55'.repeat(32)}`;
export const OTHER_HASH = `0x${'66'.repeat(32)}`;
export const KEY = 'commonrate.live.public.v1';
export function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
export function campaignSnapshot(chain = 5042002, hash = DEPLOYMENT, account = ACCOUNT) {
  return { chain, block: 100n, timestamp: 1000n, address: CAMPAIGN, deploymentHash: hash,
    terms: { seller: ACCOUNT, sponsor: ACCOUNT, deadline: 2000n }, unitCount: 1n,
    sponsorFunded: true, finalized: false, succeeded: false, outstanding: 90000n,
    lifetimeDeposits: 60000n, totalClaimed: 0n, account, balance: 1000000n,
    allowance: 60000n, credit: 0n, claimed: 0n, allocation: [0n,0n,0n,0n,0n,0n], seats: [],
  };
}
export function createFixture(options = {}) {
  const log = [], denied = [], controllers = [], listeners = new Map();
  const values = new Map(options.saved ? [[KEY, options.saved]] : []);
  const storage = options.storage ?? {
    getItem(key) { log.push(['storage.get', key]); return values.get(key) ?? null; },
    setItem(key, value) { log.push(['storage.set', key]); if (options.failStorage) throw Error('Invented unavailable storage'); values.set(key, value); },
  };
  let expectedData = '0x', expectedTo = CAMPAIGN;
  const controls = { campaignPromise: undefined, networkPromise: undefined, snapshotPatch: {}, transactionPatch: {}, receipt: options.receipt, walletChain: 5042002, walletAccount: ACCOUNT };
  const provider = {
    request({ method }) {
      log.push(['provider', method]);
      if (method === 'eth_chainId') return Promise.resolve(`0x${controls.walletChain.toString(16)}`);
      if (method === 'eth_requestAccounts') return options.accountPermission?.promise ?? Promise.resolve([controls.walletAccount]);
      if (method === 'eth_accounts') return Promise.resolve([controls.walletAccount]);
      denied.push(method); throw Error(`Unexpected fake-provider method: ${method}`);
    },
    on(event, callback) { log.push(['listen', event]); if (!listeners.has(event)) listeners.set(event, new Set()); listeners.get(event).add(callback); },
    removeListener(event, callback) { log.push(['unlisten', event]); listeners.get(event)?.delete(callback); },
  };
  const reader = {
    getTransactionCount: async () => { log.push(['nonce']); return 7; },
    estimateGas: async ({ data, to }) => { log.push(['estimate']); expectedData = data; expectedTo = to ?? null; return 21000n; },
    simulateContract: async () => { log.push(['simulate']); return {}; },
    readContract: async ({ functionName, args }) => {
      log.push(['readContract', functionName]);
      if (functionName !== 'previewWalletRefundExact') { denied.push(functionName); throw Error('Unexpected fake read'); }
      const [count, indices] = args;
      return count < 2n ? 60000n * BigInt(indices.length) : indices.reduce((sum, index) => sum + 60000n - (120000n / count + (index < 120000n % count ? 1n : 0n) - 10000n), 0n);
    },
    waitForTransactionReceipt: async ({ onReplaced }) => {
      log.push(['waitReceipt']);
      if (options.replacement === 'repriced') {
        const original = { hash: HASH, from: ACCOUNT, to: expectedTo, input: expectedData, value: 0n, chainId: 5042002, nonce: 7 };
        onReplaced({ reason: 'repriced', replacedTransaction: original, transaction: { ...original, hash: OTHER_HASH } });
      }
      return controls.receipt?.promise ?? { status: 'success', transactionHash: options.replacement ? OTHER_HASH : HASH };
    },
    getTransaction: async () => { log.push(['getTransaction']); return { from: ACCOUNT, to: expectedTo, input: expectedData, value: 0n, chainId: 5042002, nonce: 7, ...controls.transactionPatch }; },
  };
  // On remount, receipt verification must use the original persisted call, not a new review.
  const saved = options.saved ? JSON.parse(options.saved) : null;
  if (saved?.pending?.[0]?.expected) {
    expectedData = saved.pending[0].expected.data;
    expectedTo = saved.pending[0].expected.to;
  }
  const write = async args => {
    log.push(['write', args.functionName ?? 'deploy', args]);
    if (options.walletError) throw options.walletError;
    return options.wallet?.promise ?? HASH;
  };
  const dependencies = {
    readClient(chain, route) { log.push(['readClient', chain, route]); return reader; },
    walletClient(chain, account) { log.push(['walletClient', chain, account]); return { writeContract: write, deployContract: write }; },
    async verifyNetwork(_reader, chain) { log.push(['verifyNetwork', chain]); return controls.networkPromise ?? { chain, block: 100n, timestamp: 1000n }; },
    async verifyCampaign(_reader, chain, hash, account) {
      log.push(['verifyCampaign', chain, hash, account]);
      const snapshot = { ...campaignSnapshot(chain, hash, account), ...controls.snapshotPatch };
      if (!account) for (const key of ['account', 'balance', 'allowance', 'credit', 'claimed', 'allocation']) delete snapshot[key];
      return controls.campaignPromise ?? snapshot;
    },
  };
  const window = { ethereum: options.noProvider ? undefined : provider, localStorage: storage, requestAnimationFrame(callback) { callback(); return 1; } };
  window.self = window;
  window.top = options.embedded ? {} : window;
  class Element { focus() {} select() {} }
  globalThis.window = window;
  globalThis.document = { activeElement: new Element() };
  globalThis.HTMLElement = Element;
  const fixture = { log, denied, controllers, listeners, dependencies, storage, controls, provider,
    stored: () => storage.getItem(KEY),
    count: kind => log.filter(event => event[0] === kind).length,
    methods: () => log.filter(event => event[0] === 'provider').map(event => event[1]),
    emit(event) { for (const callback of listeners.get(event) ?? []) callback(); },
    get controller() { return controllers.at(-1); },
  };
  globalThis.__COMMONRATE_REACT_AUDIT__ = fixture;
  return fixture;
}
