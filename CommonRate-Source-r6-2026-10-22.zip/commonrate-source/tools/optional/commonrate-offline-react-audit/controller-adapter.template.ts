import { LiveController as RealLiveController } from '__AUDIT_SOURCE__/live/controller.ts';

// Build-time test adapter only. All controller behavior remains production code.
// The only semantic substitution is the existing fourth constructor argument.
export class LiveController extends RealLiveController {
  constructor(provider, embedded, storage) {
    const fixture = globalThis.__COMMONRATE_REACT_AUDIT__;
    if (!fixture) throw new Error('Audit fixture is required; real dependencies are forbidden');
    super(provider, embedded, storage, fixture.dependencies);
    fixture.controllers.push(this);
  }
}
