// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title  CommonRate
 * @notice Sponsored group checkout for a shared fixed cost.
 *
 * ── Mechanics ────────────────────────────────────────────────────────────────
 *
 * Immutable terms set at construction; no admin, upgrade, or owner withdrawal.
 * All amounts are USDC micro-units (6 decimals, integer arithmetic only).
 *
 * A seller sets a fixed cost C.  Each participant deposits A per reserved unit.
 * An optional sponsor (fixed address, nonzero iff B > 0) prefunds S = B*K once,
 * fully, before any participant reservation.  B == 0 means no sponsor required.
 *
 * After timestamp >= deadline, anyone calls finalize() exactly once:
 *
 *   SUCCESS  N >= minUnits, N > 0, sponsor funded (if required), N*(A+B) >= C
 *            and accounted liabilities == N*A + actualReserve:
 *     q  = C / N
 *     r  = C % N
 *     seat i: gross  = q + (i < r ? 1 : 0)
 *             charge = gross - B          (>= 0 proven by C>=B*K and N<=K)
 *             refund = A - charge         (<= A proven by (A+B)*m>=C and N>=m)
 *     seller  credit += C
 *     sponsor credit += S - N*B
 *
 *   FAILURE  any success condition false, including N==0:
 *     seat i: gross=0, charge=0, refund=A  (stored for read-model parity)
 *     seller  credit: 0
 *     sponsor credit += actualReserve (0 if never funded)
 *
 * Credits are pull-claim only.  += accumulation, never overwrite.
 * EVM revert in claim() rolls back ALL effects; no manual credit-restore needed.
 * Each address claims independently.
 *
 * ── Invariants ───────────────────────────────────────────────────────────────
 *
 * Finalize:
 *   totalCredit == N*A + actualReserve           (strict equality checked)
 *   token.balanceOf(this) >= totalCredit         (>= tolerates donations)
 *
 * Claim:
 *   token.balanceOf(this) >= totalOutstanding    (pre-decrement; guards all)
 *
 * ── Proofs ───────────────────────────────────────────────────────────────────
 *
 * charge >= 0: C >= B*K and N <= K  =>  C/N >= B  =>  floor(C/N) >= B
 * charge <= A: C <= m*(A+B) <= N*(A+B)  =>  ceil(C/N) <= A+B  =>  charge <= A
 */

// ─────────────────────────────────────────────────────────────────────────────
// SafeTransfer library
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @dev Low-level ERC-20 call wrapper.
 *
 *  Handles three token return patterns:
 *   1. Returns true                 — success.
 *   2. Returns false                — decoded to false, reverts SafeTransferFailed.
 *   3. Returns nothing (no-return)  — empty data treated as success (USDT-style).
 *
 *  NOTE: A reverting token does NOT bubble its revert reason unchanged.
 *  The low-level call captures the revert into (ok=false, data=revertPayload).
 *  The !ok branch re-reverts with SafeTransferFailed, discarding the original
 *  reason.  Tests expecting a token's own revert selector must catch
 *  SafeTransferFailed instead.
 */
library SafeTransfer {
    error SafeTransferFailed();

    function safeTransferFrom(
        address tok,
        address from,
        address to,
        uint256 amount
    ) internal {
        (bool ok, bytes memory data) = tok.call(
            abi.encodeWithSignature("transferFrom(address,address,uint256)", from, to, amount)
        );
        if (!ok || (data.length != 0 && !abi.decode(data, (bool))))
            revert SafeTransferFailed();
    }

    function safeTransfer(
        address tok,
        address to,
        uint256 amount
    ) internal {
        (bool ok, bytes memory data) = tok.call(
            abi.encodeWithSignature("transfer(address,uint256)", to, amount)
        );
        if (!ok || (data.length != 0 && !abi.decode(data, (bool))))
            revert SafeTransferFailed();
    }

    /// @dev Static balanceOf call; reverts if token does not respond.
    function balanceOf(address tok, address account) internal view returns (uint256) {
        (bool ok, bytes memory data) = tok.staticcall(
            abi.encodeWithSignature("balanceOf(address)", account)
        );
        require(ok && data.length == 32, "SafeTransfer: balanceOf failed");
        return abi.decode(data, (uint256));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CommonRate
// ─────────────────────────────────────────────────────────────────────────────

contract CommonRate {
    using SafeTransfer for address;

    // ── Constants ─────────────────────────────────────────────────────────────

    /// @notice Upper bound for C, A, B: 1e12 micro-USDC = 1,000,000 USDC.
    uint256 public constant MAX_AMOUNT = 1_000_000_000_000;

    // ── Immutable terms ───────────────────────────────────────────────────────

    /// @notice ERC-20 token; must be six-decimal (verified off-chain before deploy).
    address  public immutable token;

    /// @notice Seller receives cost on success.  Nonzero.
    address  public immutable seller;

    /// @notice Sponsor; nonzero iff subsidyPerUnit > 0; zero iff subsidyPerUnit == 0.
    address  public immutable sponsorAddress;

    /// @notice C — fixed seller cost.
    uint256  public immutable cost;

    /// @notice A — participant deposit per unit.
    uint256  public immutable depositPerUnit;

    /// @notice B — sponsor subsidy per successful paid unit (0 = no sponsor).
    uint256  public immutable subsidyPerUnit;

    /// @notice S = B * K — required sponsor reserve (0 when B == 0).
    uint256  public immutable sponsorReserve;

    /// @notice K — maximum units (1-12).
    uint256  public immutable capacity;

    /// @notice m — minimum paid units for success (1-K).
    uint256  public immutable minUnits;

    /// @notice Unix timestamp; finalize() callable at or after this.
    uint256  public immutable deadline;

    /// @notice keccak256 of the agreed terms document.
    bytes32  public immutable termsHash;

    /// @notice Short campaign title (display only).
    string   public title;

    /// @notice Campaign description (display only).
    string   public description;

    // ── Mutable state ─────────────────────────────────────────────────────────

    /// @notice Actual USDC received from sponsor (0 if never funded).
    uint256  public actualReserve;

    /// @notice True once sponsor has deposited the full reserve.
    bool     public sponsorFunded;

    /// @notice Number of units reserved (also next seat index).
    uint256  public unitCount;

    /// @notice 0-based seat index => owner address.
    mapping(uint256 => address) public seatOwner;

    /// @notice Claimable credit per address after finalize.
    mapping(address => uint256) public credits;

    /// @notice True once finalize() has run.
    bool     public finalized;

    /// @notice True on the success branch of finalize.
    bool     public succeeded;

    /// @notice block.timestamp recorded at finalize.
    uint256  public finalizedAt;

    /// @notice Lifetime deposits received (N*A per reserve call, never decremented).
    uint256  public totalDepositsReceived;

    /// @notice Sum of all credits assigned at finalize; decremented by each claim().
    uint256  public totalOutstanding;

    /// @notice Sum of all successfully completed claim() transfers.
    uint256  public totalClaimed;

    /// @notice Per-address cumulative claimed amount (incremented atomically with claim()).
    mapping(address => uint256) public claimedByWallet;

    // ── Per-seat allocation (read model, populated by finalize) ───────────────

    struct SeatAllocation {
        uint256 gross;   // success: q+(i<r?1:0); failure: 0
        uint256 charge;  // success: gross-B;     failure: 0
        uint256 refund;  // success: A-charge;    failure: A
    }
    mapping(uint256 => SeatAllocation) private _seatAlloc;

    // ── Original role allocations (written once at finalize, never decremented) ─

    /// @notice Original credit assigned to seller at finalize (0 on failure).
    uint256  public sellerAllocation;

    /// @notice Original credit assigned to sponsor at finalize (0 if never funded or failure with B=0).
    uint256  public sponsorAllocation;

    // ── Events ────────────────────────────────────────────────────────────────

    event SponsorFunded(address indexed sponsor, uint256 amount);
    event UnitsReserved(
        address indexed participant,
        uint256 firstSeatIndex,
        uint256 units,
        uint256 totalDeposited
    );
    event Finalized(bool indexed success, uint256 unitCount, uint256 timestamp);
    event Claimed(address indexed recipient, uint256 amount);

    // ── Errors ────────────────────────────────────────────────────────────────

    error ZeroAddress();
    error ZeroSeller();
    error ZeroSponsorRequired();
    error SponsorMustBeZeroWhenNoSubsidy();
    error InvalidCapacity();
    error InvalidMinUnits();
    error ZeroCost();
    error ZeroDepositPerUnit();
    error AmountExceedsMax();
    error MinUnitsCoverageFailure();
    error CostSubsidyRatioFailure();
    error InvalidDeadline();
    error NotSponsor();
    error SponsorAlreadyFunded();
    error NoSponsorRequired();
    error DeadlinePassed();
    error SponsorNotFunded();
    error NotYetDeadline();
    error AlreadyFinalized();
    error CampaignNotOpen();
    error ZeroBatchSize();
    error BatchExceedsCapacity();
    error ConservationViolation();
    error InsufficientDepositsHeld();
    error NothingToClaim();
    error ReentrancyDetected();
    error PreviewUnavailable();      // N == 0: no division defined
    error PreviewExceedsCapacity();  // N > K
    error SeatNotFinalized();        // seatAllocation called before finalize
    error SeatIndexOutOfBounds();    // seatIndex >= unitCount
    error PreviewIndexOutOfBounds(); // a seat index in previewWalletRefundExact >= N
    error DuplicateSeatIndex();      // duplicate in previewWalletRefundExact

    // ── Reentrancy guard ──────────────────────────────────────────────────────

    uint256 private _lock;

    modifier nonReentrant() {
        if (_lock == 2) revert ReentrancyDetected();
        _lock = 2;
        _;
        _lock = 1;
    }

    // ── Constructor ───────────────────────────────────────────────────────────

    constructor(
        address _token,
        address _seller,
        address _sponsorAddress,
        uint256 _cost,
        uint256 _depositPerUnit,
        uint256 _subsidyPerUnit,
        uint256 _capacity,
        uint256 _minUnits,
        uint256 _deadline,
        string  memory _title,
        string  memory _description,
        bytes32 _termsHash
    ) {
        if (_token  == address(0)) revert ZeroAddress();
        if (_seller == address(0)) revert ZeroSeller();
        if (_subsidyPerUnit > 0 && _sponsorAddress == address(0))
            revert ZeroSponsorRequired();
        if (_subsidyPerUnit == 0 && _sponsorAddress != address(0))
            revert SponsorMustBeZeroWhenNoSubsidy();
        if (_capacity < 1 || _capacity > 12)         revert InvalidCapacity();
        if (_minUnits  < 1 || _minUnits > _capacity)  revert InvalidMinUnits();
        if (_cost == 0)           revert ZeroCost();
        if (_depositPerUnit == 0) revert ZeroDepositPerUnit();
        if (_cost           > MAX_AMOUNT) revert AmountExceedsMax();
        if (_depositPerUnit > MAX_AMOUNT) revert AmountExceedsMax();
        if (_subsidyPerUnit > MAX_AMOUNT) revert AmountExceedsMax();
        if (_deadline <= block.timestamp) revert InvalidDeadline();
        // (A+B)*m >= C
        if ((_depositPerUnit + _subsidyPerUnit) * _minUnits < _cost)
            revert MinUnitsCoverageFailure();
        // C >= B*K
        if (_cost < _subsidyPerUnit * _capacity)
            revert CostSubsidyRatioFailure();

        token          = _token;
        seller         = _seller;
        sponsorAddress = _sponsorAddress;
        cost           = _cost;
        depositPerUnit = _depositPerUnit;
        subsidyPerUnit = _subsidyPerUnit;
        sponsorReserve = _subsidyPerUnit * _capacity;
        capacity       = _capacity;
        minUnits       = _minUnits;
        deadline       = _deadline;
        termsHash      = _termsHash;
        title          = _title;
        description    = _description;
        _lock          = 1;
    }

    // ── Phase 1: Sponsor funding ──────────────────────────────────────────────

    /**
     * @notice Fixed sponsor deposits S = B*K exactly once before the deadline.
     *         Only sponsorAddress may call.  Uses exact balance-delta to reject
     *         fee-on-transfer tokens atomically.
     */
    function fundSponsor() external nonReentrant {
        if (subsidyPerUnit == 0)          revert NoSponsorRequired();
        if (msg.sender != sponsorAddress) revert NotSponsor();
        if (sponsorFunded)                revert SponsorAlreadyFunded();
        if (block.timestamp >= deadline)  revert DeadlinePassed();

        uint256 required = sponsorReserve;
        uint256 before   = token.balanceOf(address(this));

        // CEI: write effect before interaction; EVM unwinds on revert.
        sponsorFunded = true;
        token.safeTransferFrom(msg.sender, address(this), required);

        uint256 delta = token.balanceOf(address(this)) - before;
        if (delta != required) revert SafeTransfer.SafeTransferFailed();

        actualReserve = delta;
        emit SponsorFunded(msg.sender, delta);
    }

    // ── Phase 2: Reservation ──────────────────────────────────────────────────

    /**
     * @notice Reserve `units` seats in one transaction.  Deposits A * units.
     *         Same wallet may reserve multiple times; seat IDs are stable 0-based.
     *
     * @param  units      1 .. remaining capacity.
     * @return firstSeat  First seat index assigned in this batch.
     */
    function reserve(uint256 units) external nonReentrant returns (uint256 firstSeat) {
        if (block.timestamp >= deadline)            revert CampaignNotOpen();
        if (subsidyPerUnit > 0 && !sponsorFunded)   revert SponsorNotFunded();
        if (units == 0)                             revert ZeroBatchSize();
        if (units > capacity - unitCount)           revert BatchExceedsCapacity();

        firstSeat = unitCount;
        for (uint256 i = 0; i < units; ) {
            seatOwner[firstSeat + i] = msg.sender;
            unchecked { ++i; }
        }
        unitCount = firstSeat + units;

        uint256 totalDeposit = depositPerUnit * units;
        totalDepositsReceived += totalDeposit;   // lifetime accumulator, never decremented

        uint256 before = token.balanceOf(address(this));
        token.safeTransferFrom(msg.sender, address(this), totalDeposit);
        uint256 delta  = token.balanceOf(address(this)) - before;
        if (delta != totalDeposit) revert SafeTransfer.SafeTransferFailed();

        emit UnitsReserved(msg.sender, firstSeat, units, totalDeposit);
    }

    // ── Phase 3: Finalize ─────────────────────────────────────────────────────

    /**
     * @notice Finalize the campaign at or after the deadline.
     *         Permissionless, once-only.  Pure storage writes; no token transfers.
     *         Bounded loop <= K <= 12 iterations.
     *
     *         Checks:
     *           totalCredit == N*A + actualReserve  (strict conservation)
     *           token.balanceOf(this) >= totalCredit (donations tolerated)
     */
    function finalize() external {
        if (block.timestamp < deadline) revert NotYetDeadline();
        if (finalized)                  revert AlreadyFinalized();

        finalized   = true;
        finalizedAt = block.timestamp;

        uint256 N = unitCount;
        bool sponsorReady = (subsidyPerUnit == 0) || sponsorFunded;
        bool coverageOk   = (N > 0) && ((depositPerUnit + subsidyPerUnit) * N >= cost);
        bool success      = (N >= minUnits) && (N > 0) && sponsorReady && coverageOk;
        succeeded = success;

        uint256 totalCredit;

        if (success) {
            uint256 q = cost / N;
            uint256 r = cost % N;

            for (uint256 i = 0; i < N; ) {
                (uint256 g, uint256 ch, uint256 ref) = _seatAllocSuccess(q, r, i);
                _seatAlloc[i] = SeatAllocation(g, ch, ref);
                credits[seatOwner[i]] += ref;
                totalCredit           += ref;
                unchecked { ++i; }
            }

            credits[seller] += cost;
            totalCredit     += cost;
            sellerAllocation = cost;                     // record original (write once)

            if (subsidyPerUnit > 0) {
                uint256 sponsorBack = sponsorReserve - N * subsidyPerUnit;
                credits[sponsorAddress] += sponsorBack;
                totalCredit             += sponsorBack;
                sponsorAllocation = sponsorBack;         // record original (write once)
            }
        } else {
            // Failure: all buyer deposits refunded, sponsor deposit returned if funded.
            for (uint256 i = 0; i < N; ) {
                _seatAlloc[i] = SeatAllocation(0, 0, depositPerUnit);
                credits[seatOwner[i]] += depositPerUnit;
                totalCredit           += depositPerUnit;
                unchecked { ++i; }
            }
            if (actualReserve > 0) {
                credits[sponsorAddress] += actualReserve;
                totalCredit             += actualReserve;
                sponsorAllocation = actualReserve;       // record original (write once)
            }
            // sellerAllocation remains 0.
        }

        // Strict conservation: totalCredit must equal accounted liabilities.
        uint256 liabilities = N * depositPerUnit + actualReserve;
        if (totalCredit != liabilities) revert ConservationViolation();

        // Token-balance sufficiency (>= tolerates unsolicited donations).
        uint256 held = token.balanceOf(address(this));
        if (held < totalCredit) revert InsufficientDepositsHeld();

        totalOutstanding = totalCredit;
        emit Finalized(success, N, block.timestamp);
    }

    // ── Phase 4: Claim ────────────────────────────────────────────────────────

    /**
     * @notice Pull claimable credit.  Pre-decrement solvency guard prevents
     *         an early claimant from draining a deficient pool.
     *
     *         Guard: held >= totalOutstanding (full pre-claim outstanding).
     *         Then: zero credit, decrement outstanding, increment claimed/claimedByWallet.
     *         Then: safeTransfer — EVM revert restores all four writes automatically.
     */
    function claim() external nonReentrant {
        uint256 amount = credits[msg.sender];
        if (amount == 0) revert NothingToClaim();

        // Pre-decrement solvency guard: full outstanding BEFORE any state change.
        uint256 held = token.balanceOf(address(this));
        if (held < totalOutstanding) revert InsufficientDepositsHeld();

        credits[msg.sender]        = 0;
        totalOutstanding          -= amount;
        totalClaimed              += amount;
        claimedByWallet[msg.sender] += amount;          // atomic with other effects

        // EVM rolls back all four writes above if safeTransfer reverts.
        token.safeTransfer(msg.sender, amount);
        emit Claimed(msg.sender, amount);
    }

    // ── Views: phase ──────────────────────────────────────────────────────────

    /**
     * @notice Campaign phase.
     *   0 = AwaitingSponsor    (B>0, sponsor not yet funded)
     *   1 = Open               (accepting reservations)
     *   2 = FullAwaitDeadline  (capacity reached, deadline not yet passed)
     *   3 = ReadyFinalize      (deadline passed, not yet finalized)
     *   4 = Succeeded
     *   5 = Failed
     */
    function phase() external view returns (uint8) {
        if (finalized)                              return succeeded ? 4 : 5;
        if (block.timestamp >= deadline)            return 3;
        if (subsidyPerUnit > 0 && !sponsorFunded)   return 0;
        if (unitCount >= capacity)                  return 2;
        return 1;
    }

    /**
     * @notice Current campaign liabilities.
     *         Pre-finalize: totalDepositsReceived + actualReserve (all received funds).
     *         Post-finalize: totalOutstanding (credits not yet claimed).
     */
    function accountedLiabilities() external view returns (uint256) {
        if (finalized) return totalOutstanding;
        return totalDepositsReceived + actualReserve;
    }

    // ── Views: seats ──────────────────────────────────────────────────────────

    /// @notice All seat indices owned by `owner`.
    function seatsOf(address owner) external view returns (uint256[] memory) {
        uint256 n = unitCount;
        uint256 cnt;
        for (uint256 i = 0; i < n; ) {
            if (seatOwner[i] == owner) cnt++;
            unchecked { ++i; }
        }
        uint256[] memory res = new uint256[](cnt);
        uint256 idx;
        for (uint256 i = 0; i < n; ) {
            if (seatOwner[i] == owner) res[idx++] = i;
            unchecked { ++i; }
        }
        return res;
    }

    /**
     * @notice Stored per-seat allocation (populated by finalize).
     *         Reverts SeatNotFinalized before finalize() has run.
     *         Reverts SeatIndexOutOfBounds for index >= unitCount.
     */
    function seatAllocation(uint256 seatIndex)
        external view
        returns (uint256 gross, uint256 charge, uint256 refund)
    {
        if (!finalized)              revert SeatNotFinalized();
        if (seatIndex >= unitCount)  revert SeatIndexOutOfBounds();
        SeatAllocation storage a = _seatAlloc[seatIndex];
        return (a.gross, a.charge, a.refund);
    }

    // ── Views: wallet allocation breakdown ───────────────────────────────────

    /**
     * @notice Aggregate allocation for a wallet across all roles it may hold.
     *
     *   buyerAllocation  = sum of refunds for all seats owned by `wallet`
     *                      (success: per-seat refund; failure: A per seat)
     *   sellerAlloc      = sellerAllocation if wallet == seller, else 0
     *   sponsorAlloc     = sponsorAllocation if wallet == sponsorAddress, else 0
     *   totalAllocated   = buyerAllocation + sellerAlloc + sponsorAlloc
     *                      (original credits; never decremented after claim)
     *   totalClaimedAmt  = claimedByWallet[wallet]
     *   outstandingAmt   = credits[wallet]  (remaining claimable)
     *
     * Returns zeros if not yet finalized.
     */
    function walletAllocation(address wallet)
        external view
        returns (
            uint256 buyerAllocation,
            uint256 sellerAlloc,
            uint256 sponsorAlloc,
            uint256 totalAllocated,
            uint256 totalClaimedAmt,
            uint256 outstandingAmt
        )
    {
        if (!finalized) {
            // Not yet finalized: no allocations exist.
            return (0, 0, 0, 0, 0, 0);
        }

        // Buyer allocation: sum refunds for all seats owned by wallet.
        uint256 N = unitCount;
        for (uint256 i = 0; i < N; ) {
            if (seatOwner[i] == wallet) {
                buyerAllocation += _seatAlloc[i].refund;
            }
            unchecked { ++i; }
        }

        // Seller and sponsor role allocations (additive when roles overlap).
        if (wallet == seller)          sellerAlloc  = sellerAllocation;
        if (wallet == sponsorAddress)  sponsorAlloc = sponsorAllocation;

        totalAllocated  = buyerAllocation + sellerAlloc + sponsorAlloc;
        totalClaimedAmt = claimedByWallet[wallet];
        outstandingAmt  = credits[wallet];
    }

    // ── Views: preview ────────────────────────────────────────────────────────

    /**
     * @notice Preview per-seat allocation for a hypothetical N.
     *         Uses the same _seatAllocSuccess formula as finalize().
     *
     *   N == 0:               reverts PreviewUnavailable (no q=C/N division).
     *   N > capacity:         reverts PreviewExceedsCapacity.
     *   B > 0, unfunded:      reverts SponsorNotFunded for every N > 0.
     *   N in [1, minUnits):   funded/B=0 predicted-failure row:
     *                           quotient=0, remainder=0,
     *                           chargeAtQuotient=0, chargeAtRemainder=0,
     *                           refundAtQuotient=A, refundAtRemainder=0
     *                           Callers should use N, minUnits, sponsorFunded and
     *                           phase() to determine success vs. failure — do not
     *                           rely on the refundAtQuotient==A sentinel alone.
     *   N in [minUnits, K]:   funded/B=0 normal success preview.
     *       r == 0: chargeAtRemainder=0, refundAtRemainder=0 (no remainder seats).
     *       r > 0:  chargeAtRemainder and refundAtRemainder reflect gross=q+1.
     */
    function previewAllocation(uint256 N)
        external view
        returns (
            uint256 quotient,
            uint256 remainder,
            uint256 chargeAtQuotient,
            uint256 chargeAtRemainder,
            uint256 refundAtQuotient,
            uint256 refundAtRemainder
        )
    {
        if (N == 0)        revert PreviewUnavailable();
        if (N > capacity)  revert PreviewExceedsCapacity();

        // Sponsored paid-unit quotes require the reserve, even below the minimum.
        if (subsidyPerUnit > 0 && !sponsorFunded) revert SponsorNotFunded();

        // Predicted-failure range: return full-refund row without any division.
        if (N < minUnits) {
            return (0, 0, 0, 0, depositPerUnit, 0);
        }

        quotient  = cost / N;
        remainder = cost % N;

        // Non-remainder seat (gross = q): use _seatAllocSuccess with i >= r (e.g. i=r when r>0, or i=0 when r=0).
        (, chargeAtQuotient, refundAtQuotient) = _seatAllocSuccess(quotient, remainder, remainder);
        // Remainder seat (gross = q+1): use i=0 (always < r when r>0).
        if (remainder > 0) {
            (, chargeAtRemainder, refundAtRemainder) = _seatAllocSuccess(quotient, remainder, 0);
        }
        // remainder == 0: chargeAtRemainder and refundAtRemainder remain 0.
    }

    /**
     * @notice Preview sponsor credit for a hypothetical N.
     *   B == 0:                                          always 0.
     *   N in [0, minUnits):                              actualReserve (0 if never funded).
     *   N in [minUnits, K] and sponsor not yet funded:   0 (sponsor has not deposited).
     *   N in [minUnits, K] and sponsor funded:           S - N*B.
     *   N > capacity:                                   0.
     */
    function previewSponsorCredit(uint256 N) external view returns (uint256) {
        if (subsidyPerUnit == 0)  return 0;
        if (N > capacity)         return 0;
        // N == 0 or N < minUnits: failure predicted — return actual deposit (0 if never funded).
        if (N == 0 || N < minUnits) return actualReserve;
        // N >= minUnits (success range): sponsor must have funded; return unused portion.
        if (!sponsorFunded)       return 0;             // sponsor has not deposited; no promise
        return sponsorReserve - N * subsidyPerUnit;
    }

    /**
     * @notice Exact total refund preview for a wallet given specific seat indices and N.
     *
     *   Validates:
     *     N in [1, capacity] (reverts PreviewUnavailable if 0, PreviewExceedsCapacity if >K).
     *     seatIndices.length in [1, K] (returns 0 if empty).
     *     Each index < N (reverts PreviewIndexOutOfBounds).
     *     No duplicate indices (reverts DuplicateSeatIndex).
     *     Nonempty B>0 quotes require sponsorFunded for every N>0.
     *   N < minUnits: returns A * seatIndices.length (predicted full refund, no division).
     *   N >= minUnits: sums _seatAllocSuccess refunds for each seat index.
     */
    function previewWalletRefundExact(uint256 N, uint256[] calldata seatIndices)
        external view
        returns (uint256 total)
    {
        if (N == 0)        revert PreviewUnavailable();
        if (N > capacity)  revert PreviewExceedsCapacity();
        // Reject oversized arrays before any nested scan.
        if (seatIndices.length > capacity) revert PreviewExceedsCapacity();
        if (seatIndices.length == 0) return 0;
        // Nonempty sponsored quotes require actual funding for every N > 0.
        if (subsidyPerUnit > 0 && !sponsorFunded) revert SponsorNotFunded();

        // Validate all indices < N and check for duplicates (O(n^2), n<=12, acceptable).
        for (uint256 k = 0; k < seatIndices.length; ) {
            if (seatIndices[k] >= N) revert PreviewIndexOutOfBounds();
            for (uint256 j = k + 1; j < seatIndices.length; ) {
                if (seatIndices[j] == seatIndices[k]) revert DuplicateSeatIndex();
                unchecked { ++j; }
            }
            unchecked { ++k; }
        }

        if (N < minUnits) {
            // Failure predicted: full deposit refunded per seat.
            return depositPerUnit * seatIndices.length;
        }

        uint256 q = cost / N;
        uint256 r = cost % N;
        for (uint256 k = 0; k < seatIndices.length; ) {
            (, , uint256 ref) = _seatAllocSuccess(q, r, seatIndices[k]);
            total += ref;
            unchecked { ++k; }
        }
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    /**
     * @dev Shared success-branch allocation formula.
     *      Returns (gross, charge, refund) for seat index `i` given q and r.
     *      Guaranteed non-negative by constructor invariants.
     */
    function _seatAllocSuccess(uint256 q, uint256 r, uint256 i)
        internal view
        returns (uint256 gross, uint256 charge, uint256 refund)
    {
        gross  = q + (i < r ? 1 : 0);
        charge = gross - subsidyPerUnit;
        refund = depositPerUnit - charge;
    }
}
