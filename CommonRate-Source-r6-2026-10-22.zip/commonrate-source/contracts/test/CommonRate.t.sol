// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ─────────────────────────────────────────────────────────────────────────────
// CommonRate.t.sol  — Minimal canonical fixture, N=10 success case
//
// History:
//   contracts/test/CommonRate.t.sol  ← this file (current)
//   docs/legacy/CommonRate.initial.t.sol.txt ← original incompatible tests
//     (used old 8-arg constructor, deposit(), settle(), prefundSponsor() API;
//      preserved for history but not compiled)
//
// This file targets the corrected 12-argument CommonRate contract:
//   token, seller, sponsorAddress, cost, depositPerUnit, subsidyPerUnit,
//   capacity, minUnits, deadline, title, description, termsHash
//
// Canonical sandbox parameters (micro-USDC = 6 decimals):
//   C = 600_000_000   (600 USDC)
//   A =  60_000_000   ( 60 USDC)
//   B =  15_000_000   ( 15 USDC)
//   K = 12, m = 8
//   S = B * K = 180_000_000
//
// N = 10 success scenario:
//   q = 600_000_000 / 10 = 60_000_000
//   r = 600_000_000 % 10 = 0          (no remainder seats)
//   charge per seat = q - B = 45_000_000
//   refund  per seat = A - charge = 15_000_000
//   seller  credit  = C              = 600_000_000
//   sponsor credit  = S - 10*B      =  30_000_000
//   buyer   credits = 10 * 15_000_000 = 150_000_000
//   total   credits = 600 + 30 + 150  = 780_000_000  == N*A + S == 600 + 180
//
// Assertions: all credits written, none transferred (finalize is pure storage).
// ─────────────────────────────────────────────────────────────────────────────

import "forge-std/Test.sol";
import "../CommonRate.sol";

// ─────────────────────────────────────────────────────────────────────────────
// Six-decimal mock ERC-20
// Supports mint, burn (for token-loss regression), approve, transfer,
// transferFrom, configurable false-return injection, no-return variant,
// and a revert-on-transfer mode.
// ─────────────────────────────────────────────────────────────────────────────
contract MockUSDC {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    // Injection modes (only one active at a time)
    bool public returnFalse;    // transferFrom/transfer return false
    bool public revertOnCall;   // transferFrom/transfer revert

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    /// @dev Simulate token loss (e.g. fee-on-transfer or external drain after finalize).
    function burn(address from, uint256 amount) external {
        require(balanceOf[from] >= amount, "burn: insufficient");
        balanceOf[from] -= amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        if (revertOnCall) revert("MockUSDC: forced revert");
        if (returnFalse)  return false;
        require(allowance[from][msg.sender] >= amount, "MockUSDC: allowance");
        require(balanceOf[from] >= amount, "MockUSDC: balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to]   += amount;
        return true;
    }

    // blockedRecipient: transfer() to this address reverts; transferFrom unaffected.
    address public blockedRecipient;
    function setBlockedRecipient(address a) external { blockedRecipient = a; }

    function transfer(address to, uint256 amount) external returns (bool) {
        if (to == blockedRecipient && blockedRecipient != address(0))
            revert("MockUSDC: recipient blocked");
        if (revertOnCall) revert("MockUSDC: forced revert");
        if (returnFalse)  return false;
        require(balanceOf[msg.sender] >= amount, "MockUSDC: balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]         += amount;
        return true;
    }

    function setReturnFalse(bool v)   external { returnFalse  = v; }
    function setRevertOnCall(bool v)  external { revertOnCall = v; }
}

// ─────────────────────────────────────────────────────────────────────────────
// NoReturnMockUSDC: real balance updates but assembly return(0,0) — no return data.
// SafeTransfer must treat empty return as success (USDT-style).
// ─────────────────────────────────────────────────────────────────────────────
contract NoReturnMockUSDC {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 amount) external { balanceOf[to] += amount; }

    function approve(address spender, uint256 amount) external {
        allowance[msg.sender][spender] = amount;
        assembly { mstore(0, 1) return(0, 0) } // update state, return no data
    }

    function transferFrom(address from, address to, uint256 amount) external {
        require(allowance[from][msg.sender] >= amount, "allowance");
        require(balanceOf[from] >= amount, "balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to]   += amount;
        assembly { return(0, 0) } // no return data
    }

    function transfer(address to, uint256 amount) external {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]         += amount;
        assembly { return(0, 0) } // no return data
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FeeMockUSDC: deducts exactly 1 micro from the recipient on transferFrom,
// simulating a fee-on-transfer token.  transfer is normal (no fee).
// ─────────────────────────────────────────────────────────────────────────────
contract FeeMockUSDC {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 amount) external { balanceOf[to] += amount; }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    // Deducts 1 micro from the amount credited to `to`; `from` still pays `amount`.
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount, "allowance");
        require(balanceOf[from] >= amount, "balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to]   += amount - 1; // fee: 1 micro never arrives
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]         += amount;
        return true;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ReentrantClaimToken: a token that is itself a participant.
// When claim() pays it via transfer(), its receive hook re-enters claim().
// Records whether the reentrant call was attempted and what it reverted with.
// ─────────────────────────────────────────────────────────────────────────────
contract ReentrantClaimToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    CommonRate public campaign;       // set after deploy
    bool        public reentrantAttempted;
    bytes       public reentrantRevertData;

    function setCampaign(CommonRate cr) external { campaign = cr; }

    function mint(address to, uint256 amount) external { balanceOf[to] += amount; }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount, "allowance");
        require(balanceOf[from] >= amount, "balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to]   += amount;
        return true;
    }

    // On outgoing transfer (claim payout): attempt re-entrant claim, record result.
    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]         += amount;

        // Re-enter claim() — must be rejected with ReentrancyDetected.
        if (address(campaign) != address(0) && !reentrantAttempted) {
            reentrantAttempted = true;
            (bool ok, bytes memory data) = address(campaign).call(
                abi.encodeWithSignature("claim()")
            );
            require(!ok, "reentrant claim must fail");
            reentrantRevertData = data;
        }
        return true;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Test suite
// ─────────────────────────────────────────────────────────────────────────────

// =============================================================================
// Mock: ReentrantIncomingToken
// Overrides transferFrom to reenter fundSponsor() or reserve(1) on the campaign.
// Captures the revert selector from the inner call for assertion.
// =============================================================================
contract ReentrantIncomingToken {
    uint8 public decimals;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    enum Mode { None, FundSponsor, Reserve }

    address public reenterCampaign;
    Mode    public reenterMode;
    bool    public reentryAttempted;
    bytes4  public reentryRevertSelector;

    constructor(uint8 _decimals) { decimals = _decimals; }

    function mint(address to, uint256 amount) external { balanceOf[to] += amount; }
    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }
    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "insufficient");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]         += amount;
        return true;
    }

    function setReenterTarget(address campaign, Mode mode) external {
        reenterCampaign = campaign;
        reenterMode     = mode;
        reentryAttempted    = false;
        reentryRevertSelector = bytes4(0);
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(balanceOf[from] >= amount, "insufficient balance");
        require(allowance[from][msg.sender] >= amount, "insufficient allowance");
        // Effects first (like a real ERC-20), THEN the malicious callback.
        balanceOf[from]              -= amount;
        allowance[from][msg.sender]  -= amount;
        balanceOf[to]                += amount;

        // Attempt reentry if configured.
        if (reenterCampaign != address(0) && reenterMode != Mode.None) {
            reentryAttempted = true;
            if (reenterMode == Mode.FundSponsor) {
                try ICommonRateReenter(reenterCampaign).fundSponsor() {
                    // Should never reach here.
                } catch (bytes memory reason) {
                    if (reason.length >= 4) {
                        bytes4 sel;
                        assembly { sel := mload(add(reason, 32)) }
                        reentryRevertSelector = sel;
                    }
                }
            } else if (reenterMode == Mode.Reserve) {
                try ICommonRateReenter(reenterCampaign).reserve(1) {
                    // Should never reach here.
                } catch (bytes memory reason) {
                    if (reason.length >= 4) {
                        bytes4 sel;
                        assembly { sel := mload(add(reason, 32)) }
                        reentryRevertSelector = sel;
                    }
                }
            }
            // Disable after first use to avoid infinite loop.
            reenterMode = Mode.None;
        }
        return true;
    }
}

interface ICommonRateReenter {
    function fundSponsor() external;
    function reserve(uint256 units) external;
}

contract CommonRateN10Test is Test {

    // ── Canonical parameters ──────────────────────────────────────────────────

    uint256 constant C = 600_000_000; // 600 USDC
    uint256 constant A =  60_000_000; //  60 USDC
    uint256 constant B =  15_000_000; //  15 USDC
    uint256 constant K = 12;
    uint256 constant M = 8;
    uint256 constant S = B * K;       // 180_000_000

    // ── Expected N=10 allocations (computed independently, not from impl) ──────
    // q = C/N = 60_000_000, r = C%N = 0 (no remainder seats)
    // charge  = q - B    = 45_000_000
    // refund  = A - charge = 15_000_000
    // seller  = C        = 600_000_000
    // sponsor = S - N*B  = 180_000_000 - 150_000_000 = 30_000_000
    // total   = seller + 10*refund + sponsor = 600 + 150 + 30 = 780_000_000
    uint256 constant N10              = 10;
    uint256 constant EXPECTED_SELLER  = 600_000_000;
    uint256 constant EXPECTED_BUYER   = 15_000_000;   // per-seat refund
    uint256 constant EXPECTED_SPONSOR = 30_000_000;
    uint256 constant EXPECTED_TOTAL   = 780_000_000;  // == N*A + S

    // ── Actors ────────────────────────────────────────────────────────────────

    MockUSDC usdc;
    address  seller     = address(0xBEEF);
    address  sponsor    = address(0xCAFE);
    address  buyer      = address(0xD00D); // sole buyer; reserves all 10 units

    uint256  deadline;

    // ── Helper: deploy campaign with correct 12-arg constructor ───────────────

    function _deploy() internal returns (CommonRate cr) {
        cr = new CommonRate(
            address(usdc),  // token
            seller,         // seller
            sponsor,        // sponsorAddress (nonzero because B > 0)
            C,              // cost
            A,              // depositPerUnit
            B,              // subsidyPerUnit
            K,              // capacity
            M,              // minUnits
            deadline,       // deadline (future)
            "Test Workshop",                            // title
            "Illustrative workshop cost-sharing",       // description
            bytes32(0)                                  // termsHash (zero for test)
        );
    }

    function setUp() public {
        usdc     = new MockUSDC();
        deadline = block.timestamp + 7 days;

        // Fund actors generously.
        usdc.mint(sponsor, S * 10);
        usdc.mint(buyer,   A * K * 2);
    }

    // =========================================================================
    // TEST 1: Canonical N=10 success — the definitive integration test
    // =========================================================================

    function test_N10_canonicalSuccess() public {
        CommonRate cr = _deploy();

        // ── Step 1: Sponsor funds exactly S ───────────────────────────────────
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();

        // Sponsor funding recorded; contract holds exactly S.
        assertTrue(cr.sponsorFunded(),            "sponsor should be funded");
        assertEq(cr.actualReserve(), S,            "actualReserve == S");
        assertEq(usdc.balanceOf(address(cr)), S,   "contract holds S after fundSponsor");

        // ── Step 2: One buyer reserves 10 units ───────────────────────────────
        uint256 totalBuyerDeposit = A * N10; // 600_000_000
        vm.startPrank(buyer);
        usdc.approve(address(cr), totalBuyerDeposit);
        cr.reserve(N10);
        vm.stopPrank();

        // 10 seats assigned to buyer; contract holds S + 10*A.
        assertEq(cr.unitCount(), N10,                         "unitCount == 10");
        assertEq(usdc.balanceOf(address(cr)), S + totalBuyerDeposit,
                 "contract holds S + 10*A after reserve");
        assertEq(cr.totalDepositsReceived(), totalBuyerDeposit,
                 "totalDepositsReceived == 10*A");

        // All 10 seats owned by buyer.
        for (uint256 i = 0; i < N10; i++) {
            assertEq(cr.seatOwner(i), buyer, string(abi.encodePacked("seat ", vm.toString(i), " owner")));
        }

        // ── Step 3: Warp to deadline; finalize ────────────────────────────────
        vm.warp(deadline);              // block.timestamp == deadline → finalize allowed
        cr.finalize();

        // ── Step 4: Assert terminal state ─────────────────────────────────────
        assertTrue(cr.finalized(),   "finalized flag set");
        assertTrue(cr.succeeded(),   "success branch taken");
        assertEq(cr.finalizedAt(), deadline, "finalizedAt == deadline");

        // ── Step 5: Assert credits — the main correctness assertions ──────────

        // Seller gets exactly C = 600_000_000.
        assertEq(cr.credits(seller), EXPECTED_SELLER,
                 "seller credit == C");

        // Buyer gets 10 * 15_000_000 = 150_000_000 (accumulated from all 10 seats).
        assertEq(cr.credits(buyer), EXPECTED_BUYER * N10,
                 "buyer credit == 10 * refund_per_seat");

        // Sponsor gets S - N*B = 30_000_000.
        assertEq(cr.credits(sponsor), EXPECTED_SPONSOR,
                 "sponsor credit == S - N*B");

        // ── Step 6: totalOutstanding == EXPECTED_TOTAL ────────────────────────
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL,
                 "totalOutstanding == 780_000_000");

        // ── Step 7: Conservation — sum of credits == N*A + S ─────────────────
        // Independent algebra: totalCredit = C + (N*A - (C - N*B)) + (S - N*B)
        //                                  = C + N*A - C + N*B + S - N*B
        //                                  = N*A + S   ✓
        uint256 sumCredits = cr.credits(seller)
                           + cr.credits(buyer)
                           + cr.credits(sponsor);
        assertEq(sumCredits, N10 * A + S,
                 "sum of all credits == N*A + S");
        assertEq(sumCredits, EXPECTED_TOTAL,
                 "sum of all credits == EXPECTED_TOTAL");

        // ── Step 8: No token transfers on finalize — balances unchanged ────────
        // Contract balance still equals what was deposited: S + 10*A = 780_000_000.
        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL,
                 "contract balance unchanged after finalize (no transfers)");
        // Seller balance: unchanged (no claim yet).
        assertEq(usdc.balanceOf(seller), 0,
                 "seller balance unchanged after finalize");
        // Buyer balance: unchanged (no claim yet).
        assertEq(usdc.balanceOf(buyer), A * K * 2 - totalBuyerDeposit,
                 "buyer balance unchanged after finalize");

        // ── Step 9: Per-seat allocation read-model ────────────────────────────
        // All seats are non-remainder (r=0): gross=60e6, charge=45e6, refund=15e6.
        for (uint256 i = 0; i < N10; i++) {
            (uint256 gross, uint256 charge, uint256 refund) = cr.seatAllocation(i);
            assertEq(gross,  60_000_000, "gross == q (no remainder)");
            assertEq(charge, 45_000_000, "charge == q - B");
            assertEq(refund, 15_000_000, "refund == A - charge");
        }

        // ── Step 10: previewAllocation(10) agrees with finalize math ──────────
        // r == 0 → chargeAtRemainder=0, refundAtRemainder=0 (no remainder seats).
        (
            uint256 pQ,
            uint256 pR,
            uint256 pChargeQ,
            uint256 pChargeR,
            uint256 pRefundQ,
            uint256 pRefundR
        ) = cr.previewAllocation(N10);
        assertEq(pQ,       60_000_000, "preview quotient == 60e6");
        assertEq(pR,       0,          "preview remainder == 0 (evenly divisible)");
        assertEq(pChargeQ, 45_000_000, "preview chargeAtQuotient == 45e6");
        assertEq(pChargeR, 0,          "preview chargeAtRemainder == 0 when r==0");
        assertEq(pRefundQ, 15_000_000, "preview refundAtQuotient == 15e6");
        assertEq(pRefundR, 0,          "preview refundAtRemainder == 0 when r==0");

        // ── Step 11: Claims transfer tokens correctly ─────────────────────────
        uint256 sellerBefore  = usdc.balanceOf(seller);
        uint256 buyerBefore   = usdc.balanceOf(buyer);
        uint256 sponsorBefore = usdc.balanceOf(sponsor);

        vm.prank(seller);  cr.claim();
        vm.prank(buyer);   cr.claim();
        vm.prank(sponsor); cr.claim();

        assertEq(usdc.balanceOf(seller),  sellerBefore  + EXPECTED_SELLER,
                 "seller received C after claim");
        assertEq(usdc.balanceOf(buyer),   buyerBefore   + EXPECTED_BUYER * N10,
                 "buyer received 10*refund after claim");
        assertEq(usdc.balanceOf(sponsor), sponsorBefore + EXPECTED_SPONSOR,
                 "sponsor received S-N*B after claim");

        // Contract balance drains to zero.
        assertEq(usdc.balanceOf(address(cr)), 0,
                 "contract empty after all claims");

        // totalOutstanding drains to zero; totalClaimed equals original total.
        assertEq(cr.totalOutstanding(), 0,             "totalOutstanding == 0 after all claims");
        assertEq(cr.totalClaimed(),     EXPECTED_TOTAL, "totalClaimed == original total");

        // Credits zeroed.
        assertEq(cr.credits(seller),  0, "seller credit zeroed");
        assertEq(cr.credits(buyer),   0, "buyer credit zeroed");
        assertEq(cr.credits(sponsor), 0, "sponsor credit zeroed");
    }

    // =========================================================================
    // TEST 2: Solvency guard — one-micro token loss blocks all claims
    // =========================================================================
    // Regression for the claim() pre-decrement solvency guard.
    // The naive version (check held >= totalOutstanding AFTER decrementing)
    // would allow a large first claim to drain the pool leaving insufficient
    // backing for remaining claimants.
    //
    // Scenario:
    //   totalOutstanding = 780_000_000 (N=10 success)
    //   burn 1 micro from contract  → held = 779_999_999 < 780_000_000
    //   seller tries to claim 600_000_000:
    //     naive guard: remaining = 780e6 - 600e6 = 180e6; held 779_999_999 >= 180e6 → PASSES (WRONG)
    //     correct guard: held 779_999_999 < totalOutstanding 780_000_000 → REVERTS (CORRECT)
    //   All claimants blocked until the deficit is covered.
    //   After minting 1 micro back, held == totalOutstanding → all claims succeed.

    function test_solvencyGuard_oneMicroLoss() public {
        CommonRate cr = _deploy();

        // Fund and run to finalized state.
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();

        vm.startPrank(buyer);
        usdc.approve(address(cr), A * N10);
        cr.reserve(N10);
        vm.stopPrank();

        vm.warp(deadline);
        cr.finalize();

        // Verify starting state.
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL, "setup: outstanding == 780e6");
        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL, "setup: held == 780e6");

        // ── Burn 1 micro from the contract balance (simulate token loss) ──────
        // Direct burn: we call burn() on the mock which reduces balanceOf[cr]
        // without going through reserve/fundSponsor, simulating an external drain.
        usdc.burn(address(cr), 1);

        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL - 1,
                 "contract holds 779_999_999 after 1-micro burn");
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL,
                 "totalOutstanding still 780_000_000 (burn is external)");

        // ── All claims must be blocked ─────────────────────────────────────────
        vm.expectRevert(CommonRate.InsufficientDepositsHeld.selector);
        vm.prank(seller);
        cr.claim();

        vm.expectRevert(CommonRate.InsufficientDepositsHeld.selector);
        vm.prank(buyer);
        cr.claim();

        vm.expectRevert(CommonRate.InsufficientDepositsHeld.selector);
        vm.prank(sponsor);
        cr.claim();

        // Credits unchanged (no state mutation on revert).
        assertEq(cr.credits(seller),  EXPECTED_SELLER,         "seller credit intact");
        assertEq(cr.credits(buyer),   EXPECTED_BUYER * N10,    "buyer credit intact");
        assertEq(cr.credits(sponsor), EXPECTED_SPONSOR,        "sponsor credit intact");
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL,        "outstanding unchanged");
        assertEq(cr.totalClaimed(),     0,                     "nothing claimed yet");

        // ── Restore 1 micro → claims unblocked ───────────────────────────────
        usdc.mint(address(cr), 1);

        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL,
                 "held restored to 780_000_000");

        // All three claims succeed in sequence.
        vm.prank(seller);  cr.claim();
        vm.prank(buyer);   cr.claim();
        vm.prank(sponsor); cr.claim();

        assertEq(cr.totalOutstanding(), 0,             "all claimed");
        assertEq(cr.totalClaimed(),     EXPECTED_TOTAL, "totalClaimed == EXPECTED_TOTAL");
        assertEq(usdc.balanceOf(address(cr)), 0,       "contract empty after all claims (restored + claimed exactly)");
    }

    // =========================================================================
    // TEST 3: N=7 failure — below minimum, full refunds
    // =========================================================================
    // Sponsor funds 180 USDC. Sole buyer reserves 7 units at 60 each.
    // N=7 < m=8 → failure branch.
    //
    // Independent expected values:
    //   seller  credit = 0
    //   buyer   credit = 7 × 60_000_000 = 420_000_000
    //   sponsor credit = actualReserve   = 180_000_000 (full reserve returned)
    //   totalOutstanding = 420 + 180     = 600_000_000 = 7*A + S
    //
    //   All 7 seat allocations: gross=0, charge=0, refund=A (failure sentinel).
    //   finalize() is pure storage — no token transfers.
    //   Independent claims drain contract to zero.

    function test_N7_failureFullRefund() public {
        CommonRate cr = _deploy();

        uint256 N7 = 7;

        // ── Step 1: Sponsor funds ─────────────────────────────────────────────
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();

        assertEq(cr.actualReserve(), S,              "actualReserve == S after fundSponsor");
        assertEq(usdc.balanceOf(address(cr)), S,     "contract holds S");

        // ── Step 2: Buyer reserves 7 units ────────────────────────────────────
        uint256 buyerDeposit7 = A * N7; // 420_000_000
        vm.startPrank(buyer);
        usdc.approve(address(cr), buyerDeposit7);
        cr.reserve(N7);
        vm.stopPrank();

        assertEq(cr.unitCount(), N7,                              "unitCount == 7");
        assertEq(usdc.balanceOf(address(cr)), S + buyerDeposit7, "contract holds S + 7*A");

        // ── Step 3: Warp to deadline; finalize ────────────────────────────────
        vm.warp(deadline);
        cr.finalize();

        // ── Step 4: Terminal state ─────────────────────────────────────────────
        assertTrue(cr.finalized(),    "finalized flag set");
        assertFalse(cr.succeeded(),   "failure branch - succeeded == false");

        // ── Step 5: Credits ────────────────────────────────────────────────────
        // Seller gets nothing on failure.
        assertEq(cr.credits(seller), 0,           "seller credit == 0 on failure");

        // Buyer gets full deposit back: 7 × A = 420_000_000.
        assertEq(cr.credits(buyer), 420_000_000,  "buyer credit == 7*A == 420e6");

        // Sponsor gets actualReserve back: S = 180_000_000.
        assertEq(cr.credits(sponsor), 180_000_000, "sponsor credit == actualReserve == 180e6");

        // ── Step 6: totalOutstanding == 7*A + S ───────────────────────────────
        assertEq(cr.totalOutstanding(), 600_000_000, "totalOutstanding == 7*A + S == 600e6");

        // ── Step 7: Conservation — credits == 7*A + actualReserve ─────────────
        uint256 sumCredits7 = cr.credits(seller)
                            + cr.credits(buyer)
                            + cr.credits(sponsor);
        assertEq(sumCredits7, N7 * A + S, "sum credits == 7*A + S (failure conservation)");

        // ── Step 8: No token transfers on finalize ─────────────────────────────
        assertEq(usdc.balanceOf(address(cr)), S + buyerDeposit7,
                 "contract balance unchanged after finalize");
        assertEq(usdc.balanceOf(seller), 0,
                 "seller balance unchanged - finalize transfers nothing");

        // ── Step 9: Per-seat allocation read-model ─────────────────────────────
        // Failure sentinel: gross=0, charge=0, refund=A for every seat.
        for (uint256 i = 0; i < N7; i++) {
            (uint256 gross, uint256 charge, uint256 refund) = cr.seatAllocation(i);
            assertEq(gross,  0,           string(abi.encodePacked("seat ", vm.toString(i), " gross==0 (failure)")));
            assertEq(charge, 0,           string(abi.encodePacked("seat ", vm.toString(i), " charge==0 (failure)")));
            assertEq(refund, 60_000_000,  string(abi.encodePacked("seat ", vm.toString(i), " refund==A (failure)")));
        }

        // ── Step 10: Independent claims — seller has no credit ────────────────
        // Seller has zero credit → NothingToClaim.
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(seller);
        cr.claim();

        // ── Step 11: Buyer claims 420_000_000 ────────────────────────────────
        uint256 buyerBefore7 = usdc.balanceOf(buyer);
        vm.prank(buyer);
        cr.claim();
        assertEq(usdc.balanceOf(buyer), buyerBefore7 + 420_000_000,
                 "buyer received 420e6 after claim");
        assertEq(cr.credits(buyer), 0, "buyer credit zeroed after claim");

        // ── Step 12: Sponsor claims 180_000_000 ──────────────────────────────
        uint256 sponsorBefore7 = usdc.balanceOf(sponsor);
        vm.prank(sponsor);
        cr.claim();
        assertEq(usdc.balanceOf(sponsor), sponsorBefore7 + 180_000_000,
                 "sponsor received 180e6 after claim");
        assertEq(cr.credits(sponsor), 0, "sponsor credit zeroed after claim");

        // ── Step 13: Contract fully drained ──────────────────────────────────
        assertEq(usdc.balanceOf(address(cr)), 0,     "contract empty after all claims");
        assertEq(cr.totalOutstanding(), 0,           "totalOutstanding == 0");
        assertEq(cr.totalClaimed(), 600_000_000,     "totalClaimed == 600e6 (buyer + sponsor)");
    }

    // =========================================================================
    // TEST 4: N=0, sponsor never funded — failure with no invented credits
    // =========================================================================
    // B > 0 but fundSponsor() never called → actualReserve = 0.
    // Before deadline: buyers are blocked by SponsorNotFunded.
    // At deadline: finalize succeeds (permissionless) as FAILURE.
    //   N=0 → failure branch; no q=C/N division.
    //   Failure loop runs 0 times → no seat credits.
    //   actualReserve = 0 → no sponsor credit (the if(actualReserve>0) guard).
    //   totalOutstanding = 0; seller/buyer/sponsor credits = 0.
    //
    // Independent expected values:
    //   actualReserve = 0
    //   seller  credit = 0
    //   sponsor credit = 0   (NOT 180_000_000 — never funded)
    //   totalOutstanding = 0
    //   Second finalize: AlreadyFinalized
    //   Claim by any address: NothingToClaim

    function test_N0_sponsorNeverFunded() public {
        CommonRate cr = _deploy();

        // ── Step 1: Confirm sponsor never funded ──────────────────────────────
        assertFalse(cr.sponsorFunded(), "sponsor not funded at construction");
        assertEq(cr.actualReserve(), 0, "actualReserve == 0");

        // ── Step 2: Before deadline, buyers are blocked ───────────────────────
        vm.startPrank(buyer);
        usdc.approve(address(cr), A);
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.reserve(1);
        vm.stopPrank();

        // Contract holds nothing; no seats.
        assertEq(cr.unitCount(), 0,                      "unitCount == 0");
        assertEq(usdc.balanceOf(address(cr)), 0,         "contract holds 0");

        // ── Step 3: Warp to deadline; finalize ────────────────────────────────
        vm.warp(deadline);
        cr.finalize();

        // ── Step 4: Terminal state ─────────────────────────────────────────────
        assertTrue(cr.finalized(),    "finalized flag set");
        assertFalse(cr.succeeded(),   "failure branch - N=0, sponsor unfunded");

        // ── Step 5: No credits invented for anyone ────────────────────────────
        assertEq(cr.credits(seller),  0, "seller credit == 0");
        assertEq(cr.credits(sponsor), 0, "sponsor credit == 0 - never funded, no invented 180e6");
        assertEq(cr.credits(buyer),   0, "buyer credit == 0 - no reservations");

        // ── Step 6: totalOutstanding == 0 ─────────────────────────────────────
        assertEq(cr.totalOutstanding(), 0, "totalOutstanding == 0");
        assertEq(cr.totalClaimed(),     0, "totalClaimed == 0");

        // ── Step 7: Conservation — 0*A + 0 = 0 ────────────────────────────────
        // N=0, actualReserve=0: liabilities = 0*A + 0 = 0; totalCredit = 0. ✓
        assertEq(cr.credits(seller) + cr.credits(sponsor) + cr.credits(buyer),
                 0, "sum credits == 0");

        // Contract balance: 0 (nothing was ever deposited).
        assertEq(usdc.balanceOf(address(cr)), 0, "contract holds 0 after finalize");

        // ── Step 8: Second finalize rejected ──────────────────────────────────
        vm.expectRevert(CommonRate.AlreadyFinalized.selector);
        cr.finalize();

        // ── Step 9: Claims on zero credit revert ──────────────────────────────
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(seller);
        cr.claim();

        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(sponsor);
        cr.claim();

        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(buyer);
        cr.claim();
    }

    // =========================================================================
    // TEST 5: N=9 canonical rounding — per-seat gross/charge/refund exact
    // =========================================================================
    // q = 600_000_000 / 9 = 66_666_666   (integer division)
    // r = 600_000_000 % 9 = 6            (verified: 9*66_666_666 = 599_999_994; 600_000_000 - 599_999_994 = 6)
    //
    // Seats 0..5  (i < r=6) — remainder seats:
    //   gross  = 66_666_667
    //   charge = 66_666_667 - 15_000_000 = 51_666_667
    //   refund = 60_000_000 - 51_666_667 =  8_333_333
    //
    // Seats 6..8  (i >= r=6) — quotient seats:
    //   gross  = 66_666_666
    //   charge = 66_666_666 - 15_000_000 = 51_666_666
    //   refund = 60_000_000 - 51_666_666 =  8_333_334
    //
    // Sum gross   = 6*66_666_667 + 3*66_666_666 = 400_000_002 + 199_999_998 = 600_000_000  (== C)
    // Buyer refund= 6*8_333_333  + 3*8_333_334  =  49_999_998 +  25_000_002 =  75_000_000
    // Seller      = 600_000_000
    // Sponsor     = S - 9*B      = 180_000_000 - 135_000_000 = 45_000_000
    // Total       = 600 + 75 + 45 = 720_000_000  == 9*A + S == 540_000_000 + 180_000_000  ✓
    //
    // One wallet holds ALL 9 seats; its credit must equal the exact per-seat sum,
    // not 9 * average (which would hide dust errors).
    // =========================================================================

    function test_N9_exactRounding() public {
        CommonRate cr = _deploy();

        // ── Fund sponsor ──────────────────────────────────────────────────────
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();

        // ── One buyer reserves all 9 units in a single batch call ─────────────
        uint256 N9 = 9;
        uint256 buyerDeposit = A * N9; // 540_000_000
        vm.startPrank(buyer);
        usdc.approve(address(cr), buyerDeposit);
        cr.reserve(N9);
        vm.stopPrank();

        assertEq(cr.unitCount(), N9, "unitCount == 9");
        assertEq(usdc.balanceOf(address(cr)), S + buyerDeposit,
                 "contract holds S + 9*A");

        // ── Warp and finalize ─────────────────────────────────────────────────
        vm.warp(deadline);
        cr.finalize();

        assertTrue(cr.finalized(), "finalized");
        assertTrue(cr.succeeded(), "success branch");

        // ── Per-seat read-model assertions ────────────────────────────────────
        // Remainder seats: indices 0..5 (i < r=6)
        for (uint256 i = 0; i < 6; i++) {
            (uint256 gross, uint256 charge, uint256 refund) = cr.seatAllocation(i);
            assertEq(gross,  66_666_667, string(abi.encodePacked("seat ", vm.toString(i), " gross (remainder)")));
            assertEq(charge, 51_666_667, string(abi.encodePacked("seat ", vm.toString(i), " charge (remainder)")));
            assertEq(refund,  8_333_333, string(abi.encodePacked("seat ", vm.toString(i), " refund (remainder)")));
        }
        // Quotient seats: indices 6..8 (i >= r=6)
        for (uint256 i = 6; i < 9; i++) {
            (uint256 gross, uint256 charge, uint256 refund) = cr.seatAllocation(i);
            assertEq(gross,  66_666_666, string(abi.encodePacked("seat ", vm.toString(i), " gross (quotient)")));
            assertEq(charge, 51_666_666, string(abi.encodePacked("seat ", vm.toString(i), " charge (quotient)")));
            assertEq(refund,  8_333_334, string(abi.encodePacked("seat ", vm.toString(i), " refund (quotient)")));
        }

        // ── Sum gross across all 9 seats == C ────────────────────────────────
        uint256 sumGross;
        for (uint256 i = 0; i < 9; i++) {
            (uint256 g,,) = cr.seatAllocation(i);
            sumGross += g;
        }
        assertEq(sumGross, C, "sum of all gross == C");

        // ── Buyer credit: exact per-seat sum, NOT 9 * any single average ──────
        // One wallet holds all 9 seats; credits[buyer] was accumulated with +=
        // once per seat during the finalize loop.
        // Correct: 6*8_333_333 + 3*8_333_334 = 49_999_998 + 25_000_002 = 75_000_000
        // Wrong (average*count): 9 * 8_333_333 = 74_999_997  (off by 3 micro)
        // Wrong (avg*count alt): 9 * 8_333_334 = 75_000_006  (off by 6 micro)
        assertEq(cr.credits(buyer), 75_000_000,
                 "buyer credit == exact sum of per-seat refunds (not average*count)");

        // ── Sponsor credit ────────────────────────────────────────────────────
        assertEq(cr.credits(sponsor), 45_000_000,
                 "sponsor credit == S - N*B == 45_000_000");

        // ── Seller credit ─────────────────────────────────────────────────────
        assertEq(cr.credits(seller), 600_000_000, "seller credit == C");

        // ── totalOutstanding == total credits ─────────────────────────────────
        assertEq(cr.totalOutstanding(), 720_000_000,
                 "totalOutstanding == 9*A + S == 720_000_000");

        // ── Conservation: sum credits == 9*A + S ─────────────────────────────
        uint256 sumCredits = cr.credits(seller) + cr.credits(buyer) + cr.credits(sponsor);
        assertEq(sumCredits, N9 * A + S, "sum credits == 9*A + S");
        assertEq(sumCredits, 720_000_000, "sum credits == 720_000_000");

        // ── No token transfers on finalize ────────────────────────────────────
        assertEq(usdc.balanceOf(address(cr)), N9 * A + S,
                 "contract balance unchanged after finalize");

        // ── Claims ────────────────────────────────────────────────────────────
        uint256 buyerBalBefore   = usdc.balanceOf(buyer);
        uint256 sellerBalBefore  = usdc.balanceOf(seller);
        uint256 sponsorBalBefore = usdc.balanceOf(sponsor);

        vm.prank(seller);  cr.claim();
        vm.prank(buyer);   cr.claim();
        vm.prank(sponsor); cr.claim();

        assertEq(usdc.balanceOf(buyer),   buyerBalBefore   + 75_000_000, "buyer received 75_000_000");
        assertEq(usdc.balanceOf(seller),  sellerBalBefore  + 600_000_000, "seller received C");
        assertEq(usdc.balanceOf(sponsor), sponsorBalBefore + 45_000_000, "sponsor received 45_000_000");

        assertEq(usdc.balanceOf(address(cr)), 0, "contract empty after all claims");
        assertEq(cr.totalOutstanding(), 0, "outstanding drained to 0");
        assertEq(cr.totalClaimed(), 720_000_000, "totalClaimed == 720_000_000");
    }

    // =========================================================================
    // TEST 6: seller == sponsor == buyer (same wallet, all roles)
    // =========================================================================
    // One address `combo` is simultaneously seller, sponsor, and sole buyer.
    // N=10 success scenario (same parameters as test_N10_canonicalSuccess).
    //
    // Credits accumulate additively (+=, never overwrite):
    //   Seat loop (10 seats, all owned by combo): credits[combo] += 15_000_000 x 10 = 150_000_000
    //   Seller:   credits[combo] += C            = 600_000_000
    //   Sponsor:  credits[combo] += S - 10*B     =  30_000_000
    //   Total:    credits[combo]                 = 780_000_000  (== N*A + S)
    //
    // One claim() transfers 780_000_000 to combo; contract empties.
    // Second claim() reverts NothingToClaim.
    // totalOutstanding and totalClaimed both reach 780_000_000, then outstanding -> 0.
    // =========================================================================

    function test_sameWallet_allRoles() public {
        // Deploy a campaign where combo is seller AND sponsor.
        address combo = address(0xC0FFEE);
        usdc.mint(combo, S + A * K * 2); // fund generously

        // Deploy with combo as both seller and sponsorAddress.
        CommonRate cr = new CommonRate(
            address(usdc),
            combo,          // seller == combo
            combo,          // sponsorAddress == combo (B > 0 so must be nonzero)
            C,
            A,
            B,
            K,
            M,
            deadline,
            "Same-wallet test",
            "seller == sponsor == buyer",
            bytes32(0)
        );

        // ── Step 1: combo funds sponsor (pays S = 180_000_000) ────────────────
        vm.startPrank(combo);
        usdc.approve(address(cr), S + A * 10);  // approve enough for both funding and reserve
        cr.fundSponsor();
        vm.stopPrank();

        assertEq(cr.sponsorFunded(), true, "sponsor funded");
        assertEq(cr.actualReserve(), S, "actualReserve == S");
        assertEq(usdc.balanceOf(address(cr)), S, "contract holds S after fundSponsor");

        // ── Step 2: combo reserves 10 units (pays 10*A = 600_000_000) ─────────
        // Note: approval was set to S + 10*A above; transferFrom for reserve
        // uses the allowance minus what fundSponsor already consumed (S).
        // Remaining allowance: 10*A exactly. reserve(10) transfers exactly 10*A.
        vm.startPrank(combo);
        cr.reserve(10);
        vm.stopPrank();

        assertEq(cr.unitCount(), 10, "unitCount == 10");
        assertEq(usdc.balanceOf(address(cr)), S + A * 10,
                 "contract holds S + 10*A");

        // All 10 seats owned by combo.
        for (uint256 i = 0; i < 10; i++) {
            assertEq(cr.seatOwner(i), combo,
                     string(abi.encodePacked("seat ", vm.toString(i), " owner == combo")));
        }

        // ── Step 3: Finalize at deadline ──────────────────────────────────────
        vm.warp(deadline);
        cr.finalize();

        assertTrue(cr.finalized(), "finalized");
        assertTrue(cr.succeeded(), "success branch");

        // ── Step 4: Credits must be additive, not overwritten ─────────────────
        // Each of the three credit writes hits the same address (combo).
        // The contract uses credits[addr] += ..., so all three roles accumulate.
        //
        // Expected breakdown (same algebra as N=10 test):
        //   buyer  portion: 10 * 15_000_000 = 150_000_000
        //   seller portion:                   600_000_000
        //   sponsor portion:                   30_000_000
        //   total:                            780_000_000
        assertEq(cr.credits(combo), 780_000_000,
                 "credits[combo] == 780_000_000 (all three roles additive)");

        // No other address has any credit.
        assertEq(cr.credits(seller),  0, "credits[seller placeholder] == 0 (seller IS combo)");
        // (seller is combo; this checks a different address has no credit)
        address unrelated = address(0xDEAD);
        assertEq(cr.credits(unrelated), 0, "unrelated address has no credit");

        // ── Step 5: totalOutstanding == 780_000_000 ───────────────────────────
        assertEq(cr.totalOutstanding(), 780_000_000,
                 "totalOutstanding == N*A + S == 780_000_000");

        // ── Step 6: Conservation ──────────────────────────────────────────────
        assertEq(cr.credits(combo), N10 * A + S,
                 "credits[combo] == N*A + S (conservation)");

        // No token transfers on finalize.
        assertEq(usdc.balanceOf(address(cr)), S + A * 10,
                 "contract balance unchanged after finalize");

        // ── Step 7: One claim transfers exactly 780_000_000 to combo ──────────
        uint256 comboBefore = usdc.balanceOf(combo);

        vm.prank(combo);
        cr.claim();

        assertEq(usdc.balanceOf(combo), comboBefore + 780_000_000,
                 "combo received all 780_000_000 in one claim");
        assertEq(cr.credits(combo), 0, "credits[combo] zeroed after claim");
        assertEq(usdc.balanceOf(address(cr)), 0, "contract empty after claim");
        assertEq(cr.totalOutstanding(), 0, "totalOutstanding == 0");
        assertEq(cr.totalClaimed(), 780_000_000, "totalClaimed == 780_000_000");

        // ── Step 8: Second claim reverts NothingToClaim ───────────────────────
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(combo);
        cr.claim();

        // Counters unchanged after failed second claim.
        assertEq(cr.totalOutstanding(), 0, "outstanding still 0 after rejected claim");
        assertEq(cr.totalClaimed(), 780_000_000, "totalClaimed unchanged after rejected claim");
    }

    // =========================================================================
    // TEST 7: Sponsor access controls
    // =========================================================================
    // Only the named sponsor may call fundSponsor().
    // reserve() is blocked until sponsor is funded (when B > 0).
    // Duplicate funding rejected; state/balance unchanged after each rejection.

    function test_sponsorAccessAndOrdering() public {
        CommonRate cr = _deploy();
        address rando = address(0xBAD);
        usdc.mint(rando, S * 2);

        // Reserve before sponsor funded -> SponsorNotFunded.
        vm.startPrank(buyer);
        usdc.approve(address(cr), A);
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.reserve(1);
        vm.stopPrank();
        assertEq(cr.unitCount(), 0, "unitCount unchanged after blocked reserve");
        assertEq(usdc.balanceOf(address(cr)), 0, "contract holds 0 after blocked reserve");

        // Wrong address tries to fund -> NotSponsor.
        vm.startPrank(rando);
        usdc.approve(address(cr), S);
        vm.expectRevert(CommonRate.NotSponsor.selector);
        cr.fundSponsor();
        vm.stopPrank();
        assertFalse(cr.sponsorFunded(), "sponsorFunded still false after wrong-caller attempt");
        assertEq(cr.actualReserve(), 0, "actualReserve still 0");
        assertEq(usdc.balanceOf(address(cr)), 0, "contract holds 0 after wrong-caller attempt");

        // Correct sponsor funds successfully.
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();
        assertTrue(cr.sponsorFunded(), "sponsorFunded true after correct funding");
        assertEq(cr.actualReserve(), S, "actualReserve == S");
        assertEq(usdc.balanceOf(address(cr)), S, "contract holds S");

        // Duplicate funding -> SponsorAlreadyFunded; balance unchanged.
        uint256 heldBefore = usdc.balanceOf(address(cr));
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        vm.expectRevert(CommonRate.SponsorAlreadyFunded.selector);
        cr.fundSponsor();
        vm.stopPrank();
        assertEq(usdc.balanceOf(address(cr)), heldBefore, "contract balance unchanged after duplicate fund");
        assertEq(cr.actualReserve(), S, "actualReserve unchanged after duplicate fund");
    }

    // =========================================================================
    // TEST 8: Batch-size bounds and capacity enforcement
    // =========================================================================
    // reserve(0) -> ZeroBatchSize.
    // reserve(13) -> BatchExceedsCapacity (K=12).
    // reserve(5) then reserve(7) succeeds; seat IDs stable, same buyer.
    // reserve(1) after full -> BatchExceedsCapacity.
    // Full-capacity (N=12) before deadline -> NotYetDeadline on finalize.

    function test_batchBoundsAndCapacity() public {
        CommonRate cr = _deploy();

        // Fund sponsor first (required before any reserve).
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();

        // reserve(0) -> ZeroBatchSize.
        vm.expectRevert(CommonRate.ZeroBatchSize.selector);
        vm.prank(buyer);
        cr.reserve(0);
        assertEq(cr.unitCount(), 0, "unitCount unchanged after reserve(0)");

        // reserve(13) -> BatchExceedsCapacity (13 > K=12 remaining).
        vm.startPrank(buyer);
        usdc.approve(address(cr), A * 13);
        vm.expectRevert(CommonRate.BatchExceedsCapacity.selector);
        cr.reserve(13);
        vm.stopPrank();
        assertEq(cr.unitCount(), 0, "unitCount unchanged after reserve(13)");
        assertEq(usdc.balanceOf(address(cr)), S, "contract holds only S after rejected reserves");

        // reserve(5): first batch, seats 0..4 assigned to buyer.
        vm.startPrank(buyer);
        usdc.approve(address(cr), A * 5);
        uint256 first = cr.reserve(5);
        vm.stopPrank();
        assertEq(first, 0, "firstSeat == 0 for first batch");
        assertEq(cr.unitCount(), 5, "unitCount == 5 after reserve(5)");
        for (uint256 i = 0; i < 5; i++) {
            assertEq(cr.seatOwner(i), buyer, "seat 0..4 owned by buyer");
        }

        // reserve(7): second batch, seats 5..11 assigned to buyer (same wallet).
        vm.startPrank(buyer);
        usdc.approve(address(cr), A * 7);
        uint256 second = cr.reserve(7);
        vm.stopPrank();
        assertEq(second, 5, "firstSeat == 5 for second batch");
        assertEq(cr.unitCount(), 12, "unitCount == 12 after reserve(7)");
        for (uint256 i = 5; i < 12; i++) {
            assertEq(cr.seatOwner(i), buyer, "seat 5..11 owned by buyer");
        }
        // Seat IDs from first batch still stable.
        for (uint256 i = 0; i < 5; i++) {
            assertEq(cr.seatOwner(i), buyer, "seat 0..4 stable after second batch");
        }

        // reserve(1) with capacity full -> BatchExceedsCapacity.
        address extra = address(0xEEEE);
        usdc.mint(extra, A * 2);
        vm.startPrank(extra);
        usdc.approve(address(cr), A);
        vm.expectRevert(CommonRate.BatchExceedsCapacity.selector);
        cr.reserve(1);
        vm.stopPrank();
        assertEq(cr.unitCount(), 12, "unitCount unchanged after over-capacity attempt");

        // Full capacity before deadline: finalize must be rejected.
        vm.expectRevert(CommonRate.NotYetDeadline.selector);
        cr.finalize();
        assertFalse(cr.finalized(), "not finalized before deadline even at full capacity");
    }

    // =========================================================================
    // TEST 9: Exact deadline boundary
    // =========================================================================
    // At deadline-1: finalize rejected.
    // At deadline:   fundSponsor rejected (DeadlinePassed).
    //                reserve rejected (CampaignNotOpen).
    //                finalize allowed (permissionless, once only).
    //                second finalize rejected (AlreadyFinalized).
    // claim before finalize (credits==0) -> NothingToClaim.

    function test_deadlineBoundary() public {
        CommonRate cr = _deploy();

        // Fund sponsor and place some units while open.
        vm.startPrank(sponsor);
        usdc.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();

        vm.startPrank(buyer);
        usdc.approve(address(cr), A * 10);
        cr.reserve(10);
        vm.stopPrank();

        // claim before finalize: credits[buyer]==0 -> NothingToClaim.
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(buyer);
        cr.claim();
        assertEq(cr.unitCount(), 10, "unitCount unchanged after pre-finalize claim attempt");

        // At deadline-1: finalize still rejected.
        vm.warp(deadline - 1);
        vm.expectRevert(CommonRate.NotYetDeadline.selector);
        cr.finalize();
        assertFalse(cr.finalized(), "not finalized at deadline-1");

        // At deadline exactly (T): reserve on main campaign -> CampaignNotOpen.
        // Assert this BEFORE any further warping.
        vm.warp(deadline);
        vm.startPrank(buyer);
        usdc.approve(address(cr), A);
        vm.expectRevert(CommonRate.CampaignNotOpen.selector);
        cr.reserve(1);
        vm.stopPrank();
        assertEq(cr.unitCount(), 10, "unitCount unchanged after late reserve attempt at T=deadline");

        // DeadlinePassed on fundSponsor: deploy a fresh unfunded campaign at deadline+1d,
        // then warp to that deadline so fundSponsor fires DeadlinePassed (not SponsorAlreadyFunded).
        CommonRate crFresh = new CommonRate(
            address(usdc), seller, sponsor,
            C, A, B, K, M,
            deadline + 1 days,
            "Fresh", "Fresh campaign for deadline test", bytes32(0)
        );
        vm.warp(deadline + 1 days);
        vm.startPrank(sponsor);
        usdc.approve(address(crFresh), S);
        vm.expectRevert(CommonRate.DeadlinePassed.selector);
        crFresh.fundSponsor();
        vm.stopPrank();
        assertEq(crFresh.actualReserve(), 0, "fresh campaign: actualReserve 0 after late fund attempt");

        // Main campaign finalize at deadline+1d (block.timestamp >= deadline -> allowed).
        cr.finalize();
        assertTrue(cr.finalized(), "finalized after deadline");
        assertTrue(cr.succeeded(), "success branch taken");
        assertEq(cr.finalizedAt(), deadline + 1 days, "finalizedAt == block.timestamp at finalize call");

        // Second finalize rejected.
        vm.expectRevert(CommonRate.AlreadyFinalized.selector);
        cr.finalize();

        // Deposits and credits unchanged after second-finalize rejection.
        assertEq(cr.unitCount(), 10, "unitCount unchanged after second finalize attempt");
        assertEq(cr.credits(seller), 600_000_000, "seller credit intact after second finalize attempt");
        assertEq(cr.credits(buyer),  150_000_000, "buyer credit intact after second finalize attempt");
    }

    // =========================================================================
    // TEST 10: Incoming transfer failures roll back fundSponsor and reserve
    // =========================================================================
    // Tests both false-return and reverting transferFrom modes.
    // After each injection failure the contract state must be identical to before:
    // sponsorFunded=false, actualReserve=0, unitCount=0, no seat owners, no deposits.
    // Allowances survive (injection does not consume them) so retries need no re-approve.

    function test_incomingTransferFailure_rollback() public {
        CommonRate cr = _deploy();

        // ── Snapshot pre-injection state ──────────────────────────────────────
        assertFalse(cr.sponsorFunded(),      "pre: sponsorFunded false");
        assertEq(cr.actualReserve(), 0,      "pre: actualReserve 0");
        assertEq(cr.unitCount(), 0,          "pre: unitCount 0");
        assertEq(usdc.balanceOf(address(cr)), 0, "pre: contract holds 0");
        uint256 sponsorBal0 = usdc.balanceOf(sponsor);
        uint256 buyerBal0   = usdc.balanceOf(buyer);

        // Approve once; allowances survive failed calls (injection returns before deducting).
        vm.prank(sponsor); usdc.approve(address(cr), S);
        vm.prank(buyer);   usdc.approve(address(cr), A * N10);

        // ── (a) false-return on fundSponsor ───────────────────────────────────
        usdc.setReturnFalse(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(sponsor);
        cr.fundSponsor();
        usdc.setReturnFalse(false);

        // Full rollback: state, balances, allowances unchanged.
        assertFalse(cr.sponsorFunded(),      "after false-return fund: sponsorFunded still false");
        assertEq(cr.actualReserve(), 0,      "after false-return fund: actualReserve still 0");
        assertEq(usdc.balanceOf(sponsor), sponsorBal0, "sponsor balance unchanged");
        assertEq(usdc.balanceOf(address(cr)), 0,       "contract balance unchanged");
        // Allowance not consumed (injection fires before require/deduction path).
        assertEq(usdc.allowance(sponsor, address(cr)), S, "sponsor allowance intact");

        // ── (b) reverting transferFrom on fundSponsor ─────────────────────────
        usdc.setRevertOnCall(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(sponsor);
        cr.fundSponsor();
        usdc.setRevertOnCall(false);

        assertFalse(cr.sponsorFunded(),      "after revert fund: sponsorFunded still false");
        assertEq(cr.actualReserve(), 0,      "after revert fund: actualReserve still 0");
        assertEq(usdc.balanceOf(sponsor), sponsorBal0, "sponsor balance unchanged after revert");
        assertEq(usdc.balanceOf(address(cr)), 0,       "contract balance unchanged after revert");

        // ── (c) successful retry: fundSponsor works now ───────────────────────
        vm.prank(sponsor);
        cr.fundSponsor();
        assertTrue(cr.sponsorFunded(),   "retry fund: sponsorFunded true");
        assertEq(cr.actualReserve(), S,  "retry fund: actualReserve == S");
        assertEq(usdc.balanceOf(address(cr)), S, "contract holds S after retry");

        // ── (d) false-return on reserve ───────────────────────────────────────
        usdc.setReturnFalse(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(buyer);
        cr.reserve(N10);
        usdc.setReturnFalse(false);

        assertEq(cr.unitCount(), 0,          "after false-return reserve: unitCount still 0");
        assertEq(cr.totalDepositsReceived(), 0, "no deposits recorded");
        assertEq(usdc.balanceOf(buyer), buyerBal0, "buyer balance unchanged");
        assertEq(usdc.balanceOf(address(cr)), S,   "contract still holds only S");
        // No seat owners written.
        for (uint256 i = 0; i < N10; i++) {
            assertEq(cr.seatOwner(i), address(0), string(abi.encodePacked(
                "seat ", vm.toString(i), " unowned after failed reserve")));
        }

        // ── (e) reverting transferFrom on reserve ─────────────────────────────
        usdc.setRevertOnCall(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(buyer);
        cr.reserve(N10);
        usdc.setRevertOnCall(false);

        assertEq(cr.unitCount(), 0,          "after revert reserve: unitCount still 0");
        assertEq(usdc.balanceOf(buyer), buyerBal0, "buyer balance unchanged after revert reserve");
        assertEq(usdc.balanceOf(address(cr)), S,   "contract still holds only S after revert reserve");

        // ── (f) successful retry: reserve works now ───────────────────────────
        vm.prank(buyer);
        cr.reserve(N10);
        assertEq(cr.unitCount(), N10, "retry reserve: unitCount == 10");
        assertEq(usdc.balanceOf(address(cr)), S + A * N10, "contract holds S + 10A after retry");
        assertEq(cr.totalDepositsReceived(), A * N10, "totalDepositsReceived == 10*A");
    }

    // =========================================================================
    // TEST 11: Outgoing transfer failures in claim() roll back fully
    // =========================================================================
    // false-return and reverting transfer leave credit/outstanding/claimed/balances
    // exactly as before. Then retry succeeds.

    function test_outgoingTransferFailure_claimRollback() public {
        CommonRate cr = _deploy();

        // Setup N=10 finalized state.
        vm.prank(sponsor); usdc.approve(address(cr), S);   vm.prank(sponsor); cr.fundSponsor();
        vm.prank(buyer);   usdc.approve(address(cr), A * N10); vm.prank(buyer); cr.reserve(N10);
        vm.warp(deadline);
        cr.finalize();

        uint256 buyerCredit  = EXPECTED_BUYER * N10; // 150_000_000
        uint256 buyerBal0    = usdc.balanceOf(buyer);
        uint256 contractBal0 = usdc.balanceOf(address(cr)); // 780_000_000

        // ── (a) false-return on buyer claim ───────────────────────────────────
        usdc.setReturnFalse(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(buyer);
        cr.claim();
        usdc.setReturnFalse(false);

        assertEq(cr.credits(buyer),      buyerCredit,      "credit intact after false-return claim");
        assertEq(cr.totalOutstanding(),  EXPECTED_TOTAL,   "outstanding intact after false-return claim");
        assertEq(cr.totalClaimed(),      0,                "claimed still 0 after false-return claim");
        assertEq(usdc.balanceOf(buyer),  buyerBal0,        "buyer balance unchanged");
        assertEq(usdc.balanceOf(address(cr)), contractBal0,"contract balance unchanged");

        // ── (b) reverting transfer on buyer claim ─────────────────────────────
        usdc.setRevertOnCall(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(buyer);
        cr.claim();
        usdc.setRevertOnCall(false);

        assertEq(cr.credits(buyer),      buyerCredit,    "credit intact after revert claim");
        assertEq(cr.totalOutstanding(),  EXPECTED_TOTAL, "outstanding intact after revert claim");
        assertEq(cr.totalClaimed(),      0,              "claimed still 0 after revert claim");
        assertEq(usdc.balanceOf(buyer),  buyerBal0,      "buyer balance unchanged after revert");

        // ── (c) successful retry ──────────────────────────────────────────────
        vm.prank(buyer); cr.claim();
        assertEq(cr.credits(buyer),      0,           "credit zeroed after successful claim");
        assertEq(usdc.balanceOf(buyer),  buyerBal0 + buyerCredit, "buyer received credit");
        assertEq(cr.totalClaimed(),      buyerCredit, "totalClaimed incremented");

        // ── (d) false-return on seller claim ──────────────────────────────────
        usdc.setReturnFalse(true);
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(seller);
        cr.claim();
        usdc.setReturnFalse(false);

        assertEq(cr.credits(seller),    EXPECTED_SELLER, "seller credit intact after false-return");
        assertEq(cr.totalClaimed(),     buyerCredit,     "totalClaimed unchanged after seller failure");

        // ── (e) successful seller claim after retry ───────────────────────────
        vm.prank(seller); cr.claim();
        assertEq(cr.credits(seller), 0,                        "seller credit zeroed");
        assertEq(cr.totalClaimed(),  buyerCredit + EXPECTED_SELLER, "totalClaimed accumulated");
    }

    // =========================================================================
    // TEST 12: Blocked seller does not prevent finalize or other claims
    // =========================================================================
    // Block transfer() to seller only. Finalize writes credits normally.
    // Seller claim reverts and leaves state intact.
    // Buyer and sponsor claim independently; their state/balances update correctly.
    // Unblock seller; its original credit is still there and claimable exactly once.

    function test_blockedSeller_isolatedClaim() public {
        CommonRate cr = _deploy();

        // Setup N=10 state. Block seller BEFORE finalize to prove finalize has no
        // token transfer callback (pure storage writes only — seller block irrelevant).
        vm.prank(sponsor); usdc.approve(address(cr), S);      vm.prank(sponsor); cr.fundSponsor();
        vm.prank(buyer);   usdc.approve(address(cr), A * N10); vm.prank(buyer);   cr.reserve(N10);
        vm.warp(deadline);

        // ── Block seller BEFORE finalize ──────────────────────────────────────
        usdc.setBlockedRecipient(seller);

        // finalize() must succeed even with seller blocked: it makes no token transfers.
        cr.finalize();
        assertTrue(cr.finalized(),  "finalized despite seller block (no transfer in finalize)");
        assertTrue(cr.succeeded(),  "success branch");

        // Verify credits written correctly.
        assertEq(cr.credits(seller),  EXPECTED_SELLER,      "seller credit written");
        assertEq(cr.credits(buyer),   EXPECTED_BUYER * N10, "buyer credit written");
        assertEq(cr.credits(sponsor), EXPECTED_SPONSOR,     "sponsor credit written");

        uint256 sellerBal0  = usdc.balanceOf(seller);
        uint256 buyerBal0   = usdc.balanceOf(buyer);
        uint256 sponsorBal0 = usdc.balanceOf(sponsor);

        // ── Seller claim reverts; state unchanged ──────────────────────────────
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        vm.prank(seller);
        cr.claim();

        assertEq(cr.credits(seller),    EXPECTED_SELLER, "seller credit intact after blocked claim");
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL,  "outstanding intact after blocked seller");
        assertEq(cr.totalClaimed(),     0,               "nothing claimed yet");
        assertEq(usdc.balanceOf(seller), sellerBal0,     "seller balance unchanged");

        // ── Buyer claim succeeds independently ───────────────────────────────
        vm.prank(buyer);
        cr.claim();
        assertEq(cr.credits(buyer),  0,                              "buyer credit zeroed");
        assertEq(usdc.balanceOf(buyer), buyerBal0 + EXPECTED_BUYER * N10, "buyer received refund");
        assertEq(cr.totalClaimed(),  EXPECTED_BUYER * N10,           "totalClaimed updated");
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL - EXPECTED_BUYER * N10, "outstanding reduced");

        // ── Sponsor claim succeeds independently ──────────────────────────────
        vm.prank(sponsor);
        cr.claim();
        assertEq(cr.credits(sponsor), 0,                              "sponsor credit zeroed");
        assertEq(usdc.balanceOf(sponsor), sponsorBal0 + EXPECTED_SPONSOR, "sponsor received residual");
        assertEq(cr.totalClaimed(), EXPECTED_BUYER * N10 + EXPECTED_SPONSOR, "totalClaimed accumulated");

        // Seller credit still intact; seller balance still sellerBal0.
        assertEq(cr.credits(seller), EXPECTED_SELLER,   "seller credit still intact");
        assertEq(usdc.balanceOf(seller), sellerBal0,    "seller balance still unchanged");

        // ── Unblock seller; original credit claimable exactly once ───────────
        usdc.setBlockedRecipient(address(0));

        vm.prank(seller);
        cr.claim();
        assertEq(cr.credits(seller),  0,                        "seller credit zeroed after unblock");
        assertEq(usdc.balanceOf(seller), sellerBal0 + EXPECTED_SELLER, "seller received full credit");
        assertEq(cr.totalClaimed(), EXPECTED_TOTAL,             "totalClaimed == full total");
        assertEq(cr.totalOutstanding(), 0,                      "outstanding == 0");
        assertEq(usdc.balanceOf(address(cr)), 0,                "contract empty");

        // Second seller claim rejected (credit zeroed).
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(seller);
        cr.claim();
    }

    // =========================================================================
    // TEST 13: No-return token — SafeTransfer treats empty return data as success
    // =========================================================================
    // NoReturnMockUSDC returns assembly return(0,0) after real state updates.
    // All phases (fundSponsor, reserve, finalize, claim) must work correctly.

    function test_noReturnToken_fullFlow() public {
        NoReturnMockUSDC nrt = new NoReturnMockUSDC();
        uint256 dl = block.timestamp + 7 days;

        CommonRate cr = new CommonRate(
            address(nrt), seller, sponsor,
            C, A, B, K, M, dl,
            "NoReturn", "No-return token test", bytes32(0)
        );

        nrt.mint(sponsor, S);
        nrt.mint(buyer,   A * 10);

        // fundSponsor with no-return token.
        vm.startPrank(sponsor);
        nrt.approve(address(cr), S);
        cr.fundSponsor();
        vm.stopPrank();
        assertTrue(cr.sponsorFunded(), "sponsor funded via no-return token");
        assertEq(cr.actualReserve(), S, "actualReserve correct");

        // reserve with no-return token.
        vm.startPrank(buyer);
        nrt.approve(address(cr), A * 10);
        cr.reserve(10);
        vm.stopPrank();
        assertEq(cr.unitCount(), 10, "10 units reserved");
        assertEq(nrt.balanceOf(address(cr)), S + A * 10, "contract holds deposits");

        // finalize — no token transfers, pure storage.
        vm.warp(dl);
        cr.finalize();
        assertTrue(cr.succeeded(), "success branch");
        assertEq(cr.credits(seller),  C,              "seller credit correct");
        assertEq(cr.credits(buyer),   15_000_000 * 10, "buyer credit correct");
        assertEq(cr.credits(sponsor), 30_000_000,      "sponsor credit correct");

        // claim via no-return token.
        uint256 sellerBefore = nrt.balanceOf(seller);
        vm.prank(seller);
        cr.claim();
        assertEq(nrt.balanceOf(seller), sellerBefore + C, "seller received C via no-return token");

        uint256 buyerBefore = nrt.balanceOf(buyer);
        vm.prank(buyer);
        cr.claim();
        assertEq(nrt.balanceOf(buyer), buyerBefore + 150_000_000, "buyer received refunds via no-return token");

        uint256 sponsorBefore = nrt.balanceOf(sponsor);
        vm.prank(sponsor);
        cr.claim();
        assertEq(nrt.balanceOf(sponsor), sponsorBefore + 30_000_000, "sponsor received residual via no-return token");

        assertEq(nrt.balanceOf(address(cr)), 0, "contract empty");
        assertEq(cr.totalClaimed(), S + A * 10,  "totalClaimed == N*A+S");
    }

    // =========================================================================
    // TEST 14: Fee-on-transfer token — exact delta check rejects funding/reserve
    // =========================================================================
    // FeeMockUSDC deducts 1 micro from recipient on every transferFrom.
    // Contract's exact-delta check (balance after - balance before != required)
    // must reject both fundSponsor and reserve atomically.
    // All state/balance/allowance must be fully rolled back after each rejection.

    function test_feeToken_exactDeltaRejects() public {
        FeeMockUSDC fee = new FeeMockUSDC();
        uint256 dl = block.timestamp + 7 days;

        CommonRate cr = new CommonRate(
            address(fee), seller, sponsor,
            C, A, B, K, M, dl,
            "FeeToken", "Fee-on-transfer test", bytes32(0)
        );

        fee.mint(sponsor, S + 10);
        fee.mint(buyer,   A * 10 + 10);

        // ── fundSponsor: fee makes delta = S-1 != S -> SafeTransferFailed ────────
        // The FeeMockUSDC deducts 1 micro from the CONTRACT (recipient) balance on
        // transferFrom: sponsor sends S but contract only receives S-1.  The delta
        // check fires AFTER the transfer; because the delta check itself reverts
        // (revert SafeTransferFailed), the EVM unwinds this call and all nested calls,
        // including token balances and allowances.  Both contract state AND token
        // balances must be unchanged.
        uint256 sponsorBalBefore  = fee.balanceOf(sponsor);
        uint256 contractBalBefore = fee.balanceOf(address(cr));
        vm.startPrank(sponsor);
        fee.approve(address(cr), S);
        uint256 sponsorAllowBefore = fee.allowance(sponsor, address(cr));
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        cr.fundSponsor();
        vm.stopPrank();

        // Contract state fully rolled back.
        assertFalse(cr.sponsorFunded(),    "sponsorFunded false after fee rejection");
        assertEq(cr.actualReserve(), 0,    "actualReserve 0 after fee rejection");
        assertEq(cr.unitCount(),     0,    "unitCount 0 after fee rejection");
        // Token balances rolled back (FeeMockUSDC is in-EVM; its storage reverts too).
        assertEq(fee.balanceOf(sponsor),       sponsorBalBefore,  "sponsor balance unchanged");
        assertEq(fee.balanceOf(address(cr)),   contractBalBefore, "contract balance unchanged");
        // Allowance: transferFrom was called and deducted allowance inside FeeMockUSDC,
        // but that storage write also reverts.
        assertEq(fee.allowance(sponsor, address(cr)), sponsorAllowBefore, "sponsor allowance unchanged");

        // ── reserve: B=0 campaign, fee token, delta check rejects ─────────────
        // (A+0)*10 = 600e6 = C -> valid B=0 campaign with m=10.)
        CommonRate crB0 = new CommonRate(
            address(fee), seller, address(0),
            C, A, 0, K, 10, dl,
            "FeeB0", "B=0 fee test", bytes32(0)
        );
        uint256 buyerBalBefore   = fee.balanceOf(buyer);
        uint256 contractB0Before = fee.balanceOf(address(crB0));
        vm.startPrank(buyer);
        fee.approve(address(crB0), A);
        uint256 buyerAllowBefore = fee.allowance(buyer, address(crB0));
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        crB0.reserve(1);
        vm.stopPrank();

        // Contract state fully rolled back.
        assertEq(crB0.unitCount(),             0,          "unitCount 0 after fee reserve rejection");
        assertEq(crB0.seatOwner(0),            address(0), "seat 0 unassigned after fee rejection");
        assertEq(crB0.totalDepositsReceived(), 0,          "totalDepositsReceived 0 after fee rejection");
        // Token balances and allowance rolled back.
        assertEq(fee.balanceOf(buyer),          buyerBalBefore,   "buyer balance unchanged");
        assertEq(fee.balanceOf(address(crB0)),  contractB0Before, "contract B0 balance unchanged");
        assertEq(fee.allowance(buyer, address(crB0)), buyerAllowBefore, "buyer allowance unchanged");
    }

    // =========================================================================
    // TEST 15: Reentrant claim — token re-enters claim(); must be rejected
    // =========================================================================
    // ReentrantClaimToken is itself a credited participant (the "buyer" role).
    // Its transfer() callback re-enters campaign.claim().
    // The outer claim must complete exactly once; the inner attempt must revert
    // ReentrancyDetected; no extra credit, balance, or counter change.

    function test_reentrantClaim_rejected() public {
        ReentrantClaimToken rct = new ReentrantClaimToken();
        uint256 dl = block.timestamp + 7 days;

        // Seller and sponsor are distinct normal addresses; rct is the sole buyer.
        address rctSeller  = address(0xBB01);
        address rctSponsor = address(0xBB02);

        // Use B=0 so no sponsor funding step is needed; simplify to the claim path.
        // (A+0)*m >= C: A=60e6, C=600e6, m=10, K=10 => 600e6 >= 600e6 ✓, C>=0*10 ✓)
        CommonRate cr = new CommonRate(
            address(rct), rctSeller, address(0),
            C, A, 0, 10, 10, dl,
            "ReentrantTest", "Reentrancy test", bytes32(0)
        );

        // Wire the token back to the campaign so its transfer callback can call claim().
        rct.setCampaign(cr);

        // Mint and fund rct as buyer; it will reserve all 10 units.
        rct.mint(address(rct), A * 10);
        vm.startPrank(address(rct));
        rct.approve(address(cr), A * 10);
        cr.reserve(10);
        vm.stopPrank();

        assertEq(cr.unitCount(), 10, "10 units reserved by rct");

        // Finalize (B=0, N=10=m=10, success).
        vm.warp(dl);
        cr.finalize();
        assertTrue(cr.succeeded(), "success");

        // rct as buyer: 10 * refund. q=C/N=60e6, r=0, charge=60e6-0=60e6, refund=0.
        // All 10 deposits are exact cost coverage; refund = 0.
        // Seller gets C=600e6. rct-buyer gets 0 refund. No sponsor.
        assertEq(cr.credits(address(rct)), 0,   "rct buyer refund == 0 (charge==A)");
        assertEq(cr.credits(rctSeller),    C,   "seller credit == C");

        // rct has no credit -> NothingToClaim; reentrant path not triggered.
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(address(rct));
        cr.claim();

        // Use a scenario where rct DOES get a refund: B=0, N<K so refund>0.
        // C=600e6, A=60e6, B=0, K=12, m=8, N=10 -> refund=0 again (q=60e6=A).
        // Use C=500e6 so refund is nonzero: q=50e6, charge=50e6, refund=10e6 per seat.
        // (A+0)*8 = 480e6 < 500e6 — fails coverage. Use m=9: (60e6)*9=540e6>=500e6 ✓
        // C>=0*K trivially. OK.
        uint256 C2 = 500_000_000;
        CommonRate cr2 = new CommonRate(
            address(rct), rctSeller, address(0),
            C2, A, 0, 10, 9, dl + 1,
            "ReentrantTest2", "Reentrancy test 2", bytes32(0)
        );
        rct.setCampaign(cr2);

        // rct reserves 10 units; total deposit = 10*A = 600e6.
        rct.mint(address(rct), A * 10);
        vm.startPrank(address(rct));
        rct.approve(address(cr2), A * 10);
        cr2.reserve(10);
        vm.stopPrank();

        vm.warp(dl + 1);
        cr2.finalize();
        assertTrue(cr2.succeeded(), "cr2 success");

        // q = 500e6/10 = 50e6, r=0, charge=50e6, refund=10e6 per seat.
        // rct holds all 10 seats: credits[rct] = 10*10e6 = 100e6.
        assertEq(cr2.credits(address(rct)), 100_000_000, "rct credits == 100e6");

        uint256 rctBalBefore      = rct.balanceOf(address(rct));
        uint256 outstandingBefore = cr2.totalOutstanding();
        uint256 claimedBefore     = cr2.totalClaimed();

        // claim() by rct: transfer() fires, callback re-enters claim().
        // Outer claim sets _lock=2 before transfer; inner claim sees _lock=2, reverts ReentrancyDetected.
        // Outer claim: credit=0, outstanding-=100e6, claimed+=100e6, then transfer succeeds.
        vm.prank(address(rct));
        cr2.claim();

        // Reentrant attempt was made and rejected.
        assertTrue(rct.reentrantAttempted(), "reentrant claim was attempted");
        // Decode revert data: must be ReentrancyDetected() selector = bytes4(keccak256("ReentrancyDetected()"))
        bytes4 expectedSelector = CommonRate.ReentrancyDetected.selector;
        bytes4 actualSelector;
        bytes memory rd = rct.reentrantRevertData();
        assembly { actualSelector := mload(add(rd, 32)) }
        assertEq(actualSelector, expectedSelector, "reentrant revert is ReentrancyDetected");

        // Outer claim paid exactly once: rct balance increased by exactly 100e6.
        assertEq(rct.balanceOf(address(rct)), rctBalBefore + 100_000_000,
            "rct received exactly 100e6 (outer claim only)");

        // Counters updated exactly once.
        assertEq(cr2.totalOutstanding(), outstandingBefore - 100_000_000, "outstanding decremented once");
        assertEq(cr2.totalClaimed(),     claimedBefore    + 100_000_000, "claimed incremented once");

        // Credit zeroed; second claim rejected.
        assertEq(cr2.credits(address(rct)), 0, "rct credit zeroed");
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(address(rct));
        cr2.claim();
    }

    // =========================================================================
    // TEST 16: All N=0..12 loop — every outcome with donation ignored
    // =========================================================================
    function test_allN_loopWithDonation() public {
        uint256 DONATION = 7;
        address loopSeller  = address(0xAA01);
        address loopSponsor = address(0xAA02);
        address loopBuyer   = address(0xAA03);

        usdc.mint(loopSponsor, S * 20);
        usdc.mint(loopBuyer,   A * K * 20);

        for (uint256 n = 0; n <= K; n++) {
            // Fresh campaign with deadline 100s from now (never reuses shared deadline).
            CommonRate cr = new CommonRate(
                address(usdc), loopSeller, loopSponsor,
                C, A, B, K, M,
                block.timestamp + 100,
                "Loop", "loop test", bytes32(0)
            );

            // Fund sponsor.
            vm.startPrank(loopSponsor);
            usdc.approve(address(cr), S);
            cr.fundSponsor();
            vm.stopPrank();

            // Reserve n units.
            if (n > 0) {
                vm.startPrank(loopBuyer);
                usdc.approve(address(cr), A * n);
                cr.reserve(n);
                vm.stopPrank();
            }

            // Donate 7 micro directly — must NOT affect allocations.
            usdc.mint(address(cr), DONATION);

            // Warp to deadline and finalize.
            vm.warp(block.timestamp + 100);
            cr.finalize();

            bool expectSuccess = (n >= M);
            assertEq(cr.succeeded(), expectSuccess,
                string(abi.encodePacked("succeeded N=", vm.toString(n))));

            if (expectSuccess) {
                // ── Independent expected values ──────────────────────────────
                // q = C/n, r = C%n
                // sumGross = q*n + r = C (algebra, not from impl)
                // buyerRefund per seat i: A - (q+(i<r?1:0) - B)
                // sumBuyerRefund = n*A - (C - n*B) = n*(A+B) - C
                // sponsorBack = S - n*B
                // total = C + n*(A+B) - C + S - n*B = n*A + S
                uint256 q = C / n;
                uint256 r = C % n;

                // Independent gross sum.
                uint256 indepSumGross = q * n + r;
                assertEq(indepSumGross, C,
                    string(abi.encodePacked("sumGross==C N=", vm.toString(n))));

                // Independent buyer refund sum.
                uint256 indepBuyerRefund = n * A - (C - n * B); // = n*(A+B) - C
                uint256 indepSponsorBack = S - n * B;
                uint256 indepTotal       = C + indepBuyerRefund + indepSponsorBack;
                assertEq(indepTotal, n * A + S,
                    string(abi.encodePacked("indepTotal==nA+S N=", vm.toString(n))));

                // Contract credits.
                assertEq(cr.credits(loopSeller),  C, "seller credit C");
                assertEq(cr.credits(loopBuyer),   indepBuyerRefund, "buyer refund");
                assertEq(cr.credits(loopSponsor), indepSponsorBack, "sponsor back");
                assertEq(cr.totalOutstanding(),   n * A + S, "outstanding==nA+S");

                // Per-seat read model: spot-check first and last seat.
                (uint256 g0, uint256 ch0, uint256 rf0) = cr.seatAllocation(0);
                uint256 expG0 = q + (0 < r ? 1 : 0);
                assertEq(g0,  expG0,         "gross[0]");
                assertEq(ch0, expG0 - B,     "charge[0]");
                assertEq(rf0, A - (expG0-B), "refund[0]");

                if (n > 1) {
                    (uint256 gL, uint256 chL, uint256 rfL) = cr.seatAllocation(n-1);
                    uint256 expGL = q; // last seat index n-1 >= r always (since r < n)
                    assertEq(gL,  expGL,         "gross[last]");
                    assertEq(chL, expGL - B,     "charge[last]");
                    assertEq(rfL, A - (expGL-B), "refund[last]");
                }

                // Claims drain contract to exactly DONATION surplus.
                uint256 crBalBefore = usdc.balanceOf(address(cr));
                assertEq(crBalBefore, n * A + S + DONATION, "held==nA+S+donation");

                vm.prank(loopSeller);  cr.claim();
                if (indepBuyerRefund > 0) { vm.prank(loopBuyer); cr.claim(); }
                if (indepSponsorBack > 0) { vm.prank(loopSponsor); cr.claim(); }

                // Only the unsolicited donation remains.
                assertEq(usdc.balanceOf(address(cr)), DONATION,
                    string(abi.encodePacked("only donation remains N=", vm.toString(n))));
                assertEq(cr.totalOutstanding(), 0,   "outstanding 0 after claims");
                assertEq(cr.totalClaimed(), n*A+S,   "totalClaimed==nA+S");

            } else {
                // Failure: seller 0, buyer A each, sponsor full reserve.
                assertEq(cr.credits(loopSeller),  0, "seller 0 on failure");
                assertEq(cr.credits(loopBuyer),   n * A, "buyer full refund");
                assertEq(cr.credits(loopSponsor), S, "sponsor full reserve");
                assertEq(cr.totalOutstanding(),   n * A + S, "outstanding==nA+S failure");

                // Per-seat read model: gross=0, charge=0, refund=A.
                for (uint256 i = 0; i < n; i++) {
                    (uint256 g, uint256 ch, uint256 rf) = cr.seatAllocation(i);
                    assertEq(g,  0, "gross 0 failure");
                    assertEq(ch, 0, "charge 0 failure");
                    assertEq(rf, A, "refund A failure");
                }

                // Claims restore deposits; only donation surplus remains.
                if (n * A > 0) { vm.prank(loopBuyer);   cr.claim(); }
                vm.prank(loopSponsor); cr.claim();

                assertEq(usdc.balanceOf(address(cr)), DONATION,
                    string(abi.encodePacked("only donation remains fail N=", vm.toString(n))));
                assertEq(cr.totalOutstanding(), 0, "outstanding 0 failure");
            }

            // Reset warp: next iteration needs block.timestamp + 100 to still be future.
            // Warp back 90s so each loop iteration starts from the same base.
            vm.warp(block.timestamp - 90);
        }
    }

    // =========================================================================
    // TEST 17: Bounded fuzz — valid C/A/B/m/K/N conservation property
    // =========================================================================
    // Construct all parameters to satisfy guards — no vm.assume rejections.
    // B=0 chosen ~1/3 of the time (rawBzero % 3 == 0).
    function testFuzz_validParams_conservation(
        uint32 rawC,
        uint32 rawA,
        uint32 rawB,
        uint8  rawK,
        uint8  rawM,
        uint8  rawN,
        uint8  rawBzero
    ) public {
        // ── Construct valid parameters ────────────────────────────────────────
        uint256 K2 = 1 + (uint256(rawK) % 12);               // 1..12
        uint256 m2 = 1 + (uint256(rawM) % K2);               // 1..K
        // C: 1..100_000_000 (up to 100 USDC, keeps arithmetic fast)
        uint256 C2 = 1 + (uint256(rawC) % 100_000_000);
        // B: 0 one-third of the time; else 0..floor(C/K) to satisfy B*K<=C.
        uint256 B2 = (rawBzero % 3 == 0) ? 0 : (uint256(rawB) % (C2 / K2 + 1));
        // A: must satisfy (A+B)*m >= C  =>  A >= ceil((C - B*m) / m)
        // Since B*K<=C and m<=K: B*m <= B*K <= C, so C - B*m >= 0.
        uint256 need = (C2 - B2 * m2 + m2 - 1) / m2; // ceil((C-B*m)/m), >=1
        if (need == 0) need = 1;
        // Add rawA headroom (0..999) and cap at MAX_AMOUNT.
        uint256 A2 = need + (uint256(rawA) % 1000);
        if (A2 > 1_000_000_000_000) A2 = 1_000_000_000_000;
        // N: 0..K
        uint256 N2 = uint256(rawN) % (K2 + 1);

        // ── Actors ────────────────────────────────────────────────────────────
        address fSeller  = address(0xF001);
        address fSponsor = B2 > 0 ? address(0xF002) : address(0);
        address fBuyer   = address(0xF003);

        uint256 S2 = B2 * K2;

        // Mint generously.
        usdc.mint(fSponsor != address(0) ? fSponsor : address(0xDEAD), S2 + 1);
        usdc.mint(fBuyer, A2 * K2 + 1);

        // ── Deploy ────────────────────────────────────────────────────────────
        CommonRate cr = new CommonRate(
            address(usdc), fSeller, fSponsor,
            C2, A2, B2, K2, m2,
            block.timestamp + 200,
            "fuzz", "fuzz", bytes32(0)
        );

        // ── Fund sponsor if required ──────────────────────────────────────────
        if (B2 > 0) {
            vm.startPrank(fSponsor);
            usdc.approve(address(cr), S2);
            cr.fundSponsor();
            vm.stopPrank();
        }

        // ── Reserve N2 units ─────────────────────────────────────────────────
        if (N2 > 0) {
            vm.startPrank(fBuyer);
            usdc.approve(address(cr), A2 * N2);
            cr.reserve(N2);
            vm.stopPrank();
        }

        // ── Finalize ─────────────────────────────────────────────────────────
        vm.warp(block.timestamp + 200);
        cr.finalize();

        bool success2 = cr.succeeded();

        // ── Assert outcome independently of implementation result ──────────────
        // Success iff N >= m AND N > 0 (no division-by-zero risk at N=0 since
        // success path requires N>0 per spec; also requires sponsor funded, which
        // the fuzz always satisfies when B>0).
        bool expectedSuccess = (N2 >= m2) && (N2 > 0);
        assertEq(success2, expectedSuccess, "succeeded matches independent predicate");

        // ── Independent verification ──────────────────────────────────────────
        if (success2) {
            // Independent sum of gross (not from impl): q*N + r = C.
            uint256 q2 = C2 / N2;
            uint256 r2 = C2 % N2;
            assertEq(q2 * N2 + r2, C2, "sumGross==C2");

            // Independent per-seat checks.
            uint256 sumCharge = 0;
            uint256 sumRefund = 0;
            for (uint256 i = 0; i < N2; i++) {
                uint256 gross2  = q2 + (i < r2 ? 1 : 0);
                uint256 charge2 = gross2 - B2;
                uint256 refund2 = A2 - charge2;
                // charge in [0, A2].
                assertLe(charge2, A2, "charge<=A");
                assertGe(charge2, 0,  "charge>=0");
                sumCharge += charge2;
                sumRefund += refund2;

                // Must match stored seatAllocation.
                (uint256 sg, uint256 sc, uint256 sr) = cr.seatAllocation(i);
                assertEq(sg, gross2,  "seat gross");
                assertEq(sc, charge2, "seat charge");
                assertEq(sr, refund2, "seat refund");
            }
            // sumCharge = C2 - N2*B2 (independent algebra).
            assertEq(sumCharge, C2 - N2 * B2, "sumCharge==C-N*B");
            // sumRefund = N2*A2 - sumCharge = N2*A2 - C2 + N2*B2.
            uint256 indepBuyer2  = N2 * A2 - sumCharge;
            uint256 indepSponsor2 = S2 - N2 * B2;
            assertEq(sumRefund, indepBuyer2, "sumRefund==buyerTotal");

            // Seller credit must equal C exactly (independent of buyer/sponsor math).
            assertEq(cr.credits(fSeller), C2, "sellerCredit==C");
            // Buyer credit must equal independently-summed refunds.
            assertEq(cr.credits(fBuyer),  indepBuyer2, "buyerCredit==sumRefund");

            // Aggregate credits equal N2*A2 + S2.
            uint256 sumCredits2 = cr.credits(fSeller)
                                + cr.credits(fBuyer)
                                + cr.credits(fSponsor);
            assertEq(sumCredits2, N2 * A2 + S2, "sumCredits==N*A+S");
            assertEq(cr.totalOutstanding(), N2 * A2 + S2, "outstanding==N*A+S");

            // B2==0: sponsor address is zero, no sponsor credit variable.
            if (B2 == 0) {
                assertEq(cr.credits(address(0)), 0, "no credit at zero addr");
            } else {
                // Sponsor credit == S - N*B independently.
                assertEq(cr.credits(fSponsor), indepSponsor2, "sponsorCredit==S-N*B");
            }

        } else {
            // Failure: each buyer refund A2, sponsor full reserve.
            assertEq(cr.credits(fSeller), 0, "seller 0 on failure");
            assertEq(cr.credits(fBuyer),  N2 * A2, "buyer N*A on failure");
            if (B2 > 0) {
                assertEq(cr.credits(fSponsor), S2, "sponsor S on failure");
            }
            uint256 sumCredits2 = cr.credits(fSeller)
                                + cr.credits(fBuyer)
                                + (B2 > 0 ? cr.credits(fSponsor) : 0);
            assertEq(sumCredits2, N2 * A2 + (B2 > 0 ? S2 : 0),
                "sumCredits==N*A+actualReserve failure");
        }

        // ── Claim all and verify no dust ──────────────────────────────────────
        if (cr.credits(fSeller) > 0)  { vm.prank(fSeller);  cr.claim(); }
        if (cr.credits(fBuyer)  > 0)  { vm.prank(fBuyer);   cr.claim(); }
        if (B2 > 0 && cr.credits(fSponsor) > 0) { vm.prank(fSponsor); cr.claim(); }

        assertEq(cr.totalOutstanding(), 0, "outstanding 0 after all claims");
        assertEq(usdc.balanceOf(address(cr)), 0, "no dust after claims");
    }

    // =========================================================================
    // TEST 18: Constructor boundary guards — invalid and valid extremes
    // =========================================================================
    function test_constructorBoundaries() public {
        uint256 dl = block.timestamp + 100;

        // ── Invalid: capacity 0 ───────────────────────────────────────────────
        vm.expectRevert(CommonRate.InvalidCapacity.selector);
        new CommonRate(address(usdc), seller, address(0), C, A, 0, 0, 1, dl, "t","t", bytes32(0));

        // ── Invalid: capacity 13 ─────────────────────────────────────────────
        vm.expectRevert(CommonRate.InvalidCapacity.selector);
        new CommonRate(address(usdc), seller, address(0), C, A, 0, 13, 1, dl, "t","t", bytes32(0));

        // ── Invalid: minUnits 0 ───────────────────────────────────────────────
        // Use C=1,A=1,B=0,K=1 so other guards pass; m=0 triggers InvalidMinUnits.
        vm.expectRevert(CommonRate.InvalidMinUnits.selector);
        new CommonRate(address(usdc), seller, address(0), 1, 1, 0, 1, 0, dl, "t","t", bytes32(0));

        // ── Invalid: minUnits > capacity ─────────────────────────────────────
        vm.expectRevert(CommonRate.InvalidMinUnits.selector);
        new CommonRate(address(usdc), seller, address(0), C, A, 0, 3, 4, dl, "t","t", bytes32(0));

        // ── Invalid: cost 0 ───────────────────────────────────────────────────
        vm.expectRevert(CommonRate.ZeroCost.selector);
        new CommonRate(address(usdc), seller, address(0), 0, A, 0, K, M, dl, "t","t", bytes32(0));

        // ── Invalid: depositPerUnit 0 ─────────────────────────────────────────
        // Need (0+0)*M >= C to NOT hit coverage first; use C=1,B=0,K=1,m=1 so coverage
        // check (0+0)*1 >= 1 fires MinUnitsCoverageFailure first. Use ZeroDepositPerUnit
        // path: C=1, A=0, B=1, K=1, m=1 -> B*K=1=C ok; (0+1)*1=1>=1 ok -> ZeroDeposit.
        vm.expectRevert(CommonRate.ZeroDepositPerUnit.selector);
        new CommonRate(address(usdc), seller, address(0xF9), 1, 0, 1, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: cost > MAX_AMOUNT ────────────────────────────────────────
        vm.expectRevert(CommonRate.AmountExceedsMax.selector);
        new CommonRate(address(usdc), seller, address(0),
            1_000_000_000_001, A, 0, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: depositPerUnit > MAX_AMOUNT ──────────────────────────────
        // C=1, A=MAX+1, B=0, K=1, m=1: cost check passes, then A check fires.
        vm.expectRevert(CommonRate.AmountExceedsMax.selector);
        new CommonRate(address(usdc), seller, address(0),
            1, 1_000_000_000_001, 0, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: subsidyPerUnit > MAX_AMOUNT ─────────────────────────────
        vm.expectRevert(CommonRate.AmountExceedsMax.selector);
        new CommonRate(address(usdc), seller, address(0xF9),
            1_000_000_000_000, A, 1_000_000_000_001, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: B*K > C ─────────────────────────────────────────────────
        // C=10, B=5, K=3 -> B*K=15 > C=10. Coverage: (A+B)*m=(10+5)*1=15>=10 passes first.
        vm.expectRevert(CommonRate.CostSubsidyRatioFailure.selector);
        new CommonRate(address(usdc), seller, address(0xF9),
            10, 10, 5, 3, 1, dl, "t","t", bytes32(0));

        // ── Invalid: (A+B)*m < C ─────────────────────────────────────────────
        // C=100, A=10, B=0, K=1, m=1 -> (10+0)*1=10 < 100.
        vm.expectRevert(CommonRate.MinUnitsCoverageFailure.selector);
        new CommonRate(address(usdc), seller, address(0),
            100, 10, 0, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: deadline in the past ─────────────────────────────────────
        vm.expectRevert(CommonRate.InvalidDeadline.selector);
        new CommonRate(address(usdc), seller, address(0),
            C, A, 0, K, 1, block.timestamp - 1, "t","t", bytes32(0));

        // ── Invalid: deadline == now ──────────────────────────────────────────
        vm.expectRevert(CommonRate.InvalidDeadline.selector);
        new CommonRate(address(usdc), seller, address(0),
            C, A, 0, K, 1, block.timestamp, "t","t", bytes32(0));

        // ── Invalid: zero seller ──────────────────────────────────────────────
        vm.expectRevert(CommonRate.ZeroSeller.selector);
        new CommonRate(address(usdc), address(0), address(0),
            1, 1, 0, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: zero token ───────────────────────────────────────────────
        vm.expectRevert(CommonRate.ZeroAddress.selector);
        new CommonRate(address(0), seller, address(0),
            1, 1, 0, 1, 1, dl, "t","t", bytes32(0));

        // ── Invalid: B>0 but sponsor==address(0) ─────────────────────────────
        vm.expectRevert(CommonRate.ZeroSponsorRequired.selector);
        new CommonRate(address(usdc), seller, address(0),
            C, A, B, K, M, dl, "t","t", bytes32(0));

        // ── Invalid: B==0 but sponsor!=address(0) ────────────────────────────
        vm.expectRevert(CommonRate.SponsorMustBeZeroWhenNoSubsidy.selector);
        new CommonRate(address(usdc), seller, address(0xAB),
            C, A, 0, K, M, dl, "t","t", bytes32(0));

        // ── Invalid: partial allowance S-1 cannot fund ───────────────────────
        CommonRate crPartial = new CommonRate(
            address(usdc), seller, sponsor,
            C, A, B, K, M, dl, "t","t", bytes32(0)
        );
        vm.startPrank(sponsor);
        usdc.approve(address(crPartial), S - 1); // one micro short
        vm.expectRevert(SafeTransfer.SafeTransferFailed.selector);
        crPartial.fundSponsor();
        vm.stopPrank();
        assertFalse(crPartial.sponsorFunded(), "sponsorFunded false after partial allowance");
        assertEq(crPartial.actualReserve(), 0,  "actualReserve 0 after partial allowance");

        // ── Valid extremes ────────────────────────────────────────────────────
        // capacity=1, minUnits=1, C=1, A=1, B=0.
        CommonRate v1 = new CommonRate(
            address(usdc), seller, address(0),
            1, 1, 0, 1, 1, dl, "t","t", bytes32(0)
        );
        assertEq(v1.capacity(), 1);
        assertEq(v1.minUnits(), 1);

        // capacity=12, minUnits=12 (m==K).
        // Need (A+0)*12 >= C: use C=12, A=1.
        CommonRate v2 = new CommonRate(
            address(usdc), seller, address(0),
            12, 1, 0, 12, 12, dl, "t","t", bytes32(0)
        );
        assertEq(v2.capacity(), 12);
        assertEq(v2.minUnits(), 12);

        // capacity=12, minUnits=1, amounts at MAX_AMOUNT boundary.
        // B=0; C=MAX, A=MAX; (MAX+0)*1 >= MAX ok; C>=0 ok.
        CommonRate v3 = new CommonRate(
            address(usdc), seller, address(0),
            1_000_000_000_000, 1_000_000_000_000, 0, 12, 1, dl, "t","t", bytes32(0)
        );
        assertEq(v3.cost(),           1_000_000_000_000, "v3 cost");
        assertEq(v3.depositPerUnit(), 1_000_000_000_000, "v3 depositPerUnit");
    }

    // =========================================================================
    // TEST 19: Pre-finalize one-micro shortfall — finalize reverts, restore, succeed
    // =========================================================================
    // After depositing, burn 1 micro from the contract so held < N*A+S.
    // finalize() must revert InsufficientDepositsHeld.
    // All allocation state must be unchanged (finalized still false).
    // Restore 1 micro -> finalize succeeds.

    function test_preFinalizeShortfall() public {
        CommonRate cr = _deploy();

        vm.prank(sponsor); usdc.approve(address(cr), S);       vm.prank(sponsor); cr.fundSponsor();
        vm.prank(buyer);   usdc.approve(address(cr), A * N10); vm.prank(buyer);   cr.reserve(N10);

        // Contract holds exactly N*A + S = 780_000_000.
        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL, "setup: held == 780e6");

        vm.warp(deadline);

        // Burn 1 micro: held = 779_999_999 < totalCredit = 780_000_000.
        usdc.burn(address(cr), 1);
        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL - 1, "held 1 micro short");

        // finalize must revert InsufficientDepositsHeld.
        vm.expectRevert(CommonRate.InsufficientDepositsHeld.selector);
        cr.finalize();

        // All allocation state unchanged.
        assertFalse(cr.finalized(),             "finalized still false after shortfall revert");
        assertEq(cr.totalOutstanding(), 0,      "totalOutstanding 0 (never set)");
        assertEq(cr.credits(seller),    0,      "seller credit 0");
        assertEq(cr.credits(buyer),     0,      "buyer credit 0");
        assertEq(cr.credits(sponsor),   0,      "sponsor credit 0");

        // Restore 1 micro -> finalize succeeds.
        usdc.mint(address(cr), 1);
        assertEq(usdc.balanceOf(address(cr)), EXPECTED_TOTAL, "held restored");

        cr.finalize();
        assertTrue(cr.finalized(),   "finalized after restoration");
        assertTrue(cr.succeeded(),   "success branch");
        assertEq(cr.credits(seller), EXPECTED_SELLER,      "seller credit correct after restoration");
        assertEq(cr.totalOutstanding(), EXPECTED_TOTAL,    "totalOutstanding == 780e6");
    }

    // =========================================================================
    // TEST 20: Read-model — walletAllocation, claimedByWallet, seatAllocation guards
    // =========================================================================

    function test_readModel_walletAllocationAndGuards() public {
        CommonRate cr = _deploy();

        // Pre-finalize: seatAllocation reverts SeatNotFinalized.
        vm.expectRevert(CommonRate.SeatNotFinalized.selector);
        cr.seatAllocation(0);

        // walletAllocation returns zeros pre-finalize.
        (uint256 ba, uint256 sa, uint256 spa, uint256 ta, uint256 tc, uint256 oa) =
            cr.walletAllocation(buyer);
        assertEq(ba + sa + spa + ta + tc + oa, 0, "all zeros pre-finalize");

        // accountedLiabilities pre-finalize = totalDepositsReceived + actualReserve.
        assertEq(cr.accountedLiabilities(), 0, "liabilities 0 before any deposits");

        // Fund and reserve N=10.
        vm.prank(sponsor); usdc.approve(address(cr), S);       vm.prank(sponsor); cr.fundSponsor();
        vm.prank(buyer);   usdc.approve(address(cr), A * N10); vm.prank(buyer);   cr.reserve(N10);

        assertEq(cr.accountedLiabilities(), A * N10 + S, "pre-finalize liabilities == deposits+reserve");

        vm.warp(deadline);
        cr.finalize();

        // Post-finalize accountedLiabilities == totalOutstanding.
        assertEq(cr.accountedLiabilities(), cr.totalOutstanding(), "post-finalize liabilities == outstanding");

        // seatAllocation guards.
        vm.expectRevert(CommonRate.SeatIndexOutOfBounds.selector);
        cr.seatAllocation(N10); // index == unitCount is out of bounds

        // Valid seat 0: non-remainder (r=0 for N=10), gross=60e6, charge=45e6, refund=15e6.
        (uint256 g0, uint256 ch0, uint256 rf0) = cr.seatAllocation(0);
        assertEq(g0,  60_000_000, "seat0 gross");
        assertEq(ch0, 45_000_000, "seat0 charge");
        assertEq(rf0, 15_000_000, "seat0 refund");

        // walletAllocation for buyer (holds all 10 seats, buyer only).
        (uint256 buyerBa, uint256 buyerSa, uint256 buyerSpa,
         uint256 buyerTa, uint256 buyerTc, uint256 buyerOa) = cr.walletAllocation(buyer);
        assertEq(buyerBa,  EXPECTED_BUYER * N10, "buyer buyerAlloc == 150e6");
        assertEq(buyerSa,  0,                    "buyer sellerAlloc == 0");
        assertEq(buyerSpa, 0,                    "buyer sponsorAlloc == 0");
        assertEq(buyerTa,  EXPECTED_BUYER * N10, "buyer totalAllocated == 150e6");
        assertEq(buyerTc,  0,                    "buyer totalClaimed == 0 before claim");
        assertEq(buyerOa,  EXPECTED_BUYER * N10, "buyer outstanding == 150e6");

        // walletAllocation for seller (no buyer seats).
        (, uint256 selSa, , uint256 selTa, uint256 selTc, uint256 selOa) = cr.walletAllocation(seller);
        assertEq(selSa, EXPECTED_SELLER, "seller sellerAlloc == 600e6");
        assertEq(selTa, EXPECTED_SELLER, "seller totalAllocated == 600e6");
        assertEq(selTc, 0,               "seller totalClaimed == 0 before claim");
        assertEq(selOa, EXPECTED_SELLER, "seller outstanding == 600e6");

        // claimedByWallet before any claim.
        assertEq(cr.claimedByWallet(buyer),  0, "buyer claimedByWallet 0 before claim");
        assertEq(cr.claimedByWallet(seller), 0, "seller claimedByWallet 0 before claim");

        // Buyer claims; claimedByWallet increments atomically.
        vm.prank(buyer); cr.claim();
        assertEq(cr.claimedByWallet(buyer),  EXPECTED_BUYER * N10, "buyer claimedByWallet after claim");
        assertEq(cr.credits(buyer),          0,                    "buyer credits zeroed");

        // walletAllocation after buyer claim: totalAllocated unchanged, claimed updated.
        (uint256 ba2,,, uint256 ta2, uint256 tc2, uint256 oa2) = cr.walletAllocation(buyer);
        assertEq(ba2, EXPECTED_BUYER * N10, "buyerAlloc unchanged after claim");
        assertEq(ta2, EXPECTED_BUYER * N10, "totalAllocated unchanged after claim");
        assertEq(tc2, EXPECTED_BUYER * N10, "totalClaimed updated after claim");
        assertEq(oa2, 0,                    "outstanding 0 after claim");

        // Failed claim: inject false-return, buyer re-claim reverts NothingToClaim.
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(buyer); cr.claim();

        // claimedByWallet still correct after failed second claim.
        assertEq(cr.claimedByWallet(buyer), EXPECTED_BUYER * N10, "claimedByWallet unchanged after failed claim");

        // accountedLiabilities decrements as claims proceed.
        uint256 outstanding1 = EXPECTED_TOTAL - EXPECTED_BUYER * N10;
        assertEq(cr.accountedLiabilities(), outstanding1, "liabilities decremented after buyer claim");

        // Seller claims.
        vm.prank(seller); cr.claim();
        assertEq(cr.claimedByWallet(seller), EXPECTED_SELLER, "seller claimedByWallet after claim");

        // sellerAllocation and sponsorAllocation immutable view.
        assertEq(cr.sellerAllocation(),  EXPECTED_SELLER,  "sellerAllocation == C");
        assertEq(cr.sponsorAllocation(), EXPECTED_SPONSOR, "sponsorAllocation == S-N*B");
    }

    // =========================================================================
    // TEST 21: previewWalletRefundExact validation and exact seat refunds
    // =========================================================================

    function test_previewWalletRefundExact_validation() public {
        CommonRate cr = _deploy();
        usdc.mint(sponsor, S);
        vm.prank(sponsor); usdc.approve(address(cr), S);
        vm.prank(sponsor); cr.fundSponsor();

        // N=0 reverts PreviewUnavailable.
        uint256[] memory empty = new uint256[](0);
        vm.expectRevert(CommonRate.PreviewUnavailable.selector);
        cr.previewWalletRefundExact(0, empty);

        // N > capacity reverts PreviewExceedsCapacity.
        vm.expectRevert(CommonRate.PreviewExceedsCapacity.selector);
        cr.previewWalletRefundExact(K + 1, empty);

        // Empty array returns 0.
        assertEq(cr.previewWalletRefundExact(N10, empty), 0, "empty indices -> 0");

        // Index >= N reverts PreviewIndexOutOfBounds.
        uint256[] memory bad = new uint256[](1);
        bad[0] = N10; // index 10 >= N=10
        vm.expectRevert(CommonRate.PreviewIndexOutOfBounds.selector);
        cr.previewWalletRefundExact(N10, bad);

        // Duplicate index reverts DuplicateSeatIndex.
        uint256[] memory dup = new uint256[](2);
        dup[0] = 0; dup[1] = 0;
        vm.expectRevert(CommonRate.DuplicateSeatIndex.selector);
        cr.previewWalletRefundExact(N10, dup);

        // N < minUnits (failure predicted): returns A * selectedCount.
        // minUnits=8; use N=7 (failure range) with seats [0,1,2].
        uint256[] memory failSeats = new uint256[](3);
        failSeats[0] = 0; failSeats[1] = 1; failSeats[2] = 2;
        uint256 failRefund = cr.previewWalletRefundExact(7, failSeats);
        assertEq(failRefund, A * 3, "failure preview: A * count");

        // N=9, seats 0 and 6 (one remainder, one non-remainder).
        // q=66_666_666, r=6: seat0 (i<r) gross=66_666_667, refund=8_333_333.
        //                    seat6 (i>=r) gross=66_666_666, refund=8_333_334.
        // Sum = 8_333_333 + 8_333_334 = 16_666_667.
        uint256[] memory twoSeats = new uint256[](2);
        twoSeats[0] = 0; twoSeats[1] = 6;
        uint256 twoRefund = cr.previewWalletRefundExact(9, twoSeats);
        assertEq(twoRefund, 16_666_667, "N=9 seats 0+6 exact refund");

        // B=0 preview: subsidyPerUnit=0, no sponsor. Use B=0 campaign.
        CommonRate crB0 = new CommonRate(
            address(usdc), seller, address(0),
            C, A, 0, K, 10, deadline + 1,
            "B0preview", "B0 preview test", bytes32(0)
        );
        uint256[] memory oneIdx = new uint256[](1);
        oneIdx[0] = 0;
        // N=10, B=0: q=60e6, charge=60e6, refund=0.
        assertEq(crB0.previewWalletRefundExact(10, oneIdx), 0, "B=0 N=10 refund=0");
        // N=12, B=0: q=50e6, charge=50e6, refund=10e6.
        assertEq(crB0.previewWalletRefundExact(12, oneIdx), 10_000_000, "B=0 N=12 refund=10e6");
    }

    // =========================================================================
    // TEST 22: previewAllocation unfunded/B=0 sponsor paths
    // =========================================================================

    function test_previewAllocation_sponsorPaths() public {
        // Unfunded sponsor (B>0, sponsorFunded=false): N>=minUnits reverts SponsorNotFunded.
        CommonRate cr = _deploy(); // B>0, sponsor not yet funded
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.previewAllocation(M); // N=8 >= minUnits

        // Any sponsored N>0 quote is unavailable until actual funding.
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.previewAllocation(7);

        // previewSponsorCredit: unfunded, N>=minUnits returns 0 (sponsor hasn't deposited).
        assertEq(cr.previewSponsorCredit(M),  0, "unfunded sponsor credit == 0 for N>=min");
        assertEq(cr.previewSponsorCredit(K),  0, "unfunded sponsor credit == 0 for N=K");
        // N < minUnits: returns actualReserve (0 since never funded).
        assertEq(cr.previewSponsorCredit(1),  0, "unfunded: actualReserve=0 for N<min");
        // N=0: failure guaranteed, returns actualReserve (0 since never funded).
        assertEq(cr.previewSponsorCredit(0),  0, "N=0 unfunded: actualReserve=0");

        // B=0 campaign: previewSponsorCredit always 0, no sponsor check needed.
        CommonRate crB0 = new CommonRate(
            address(usdc), seller, address(0),
            C, A, 0, K, 10, deadline + 1,
            "B0sp", "B0 sponsor preview", bytes32(0)
        );
        assertEq(crB0.previewSponsorCredit(10), 0, "B=0: sponsor credit always 0");
        // previewAllocation B=0, N=10: works without sponsor. charge=60e6=A, refund=0.
        (uint256 qB0,, uint256 cQB0,, uint256 rQB0,) = crB0.previewAllocation(10);
        assertEq(qB0,  60_000_000, "B=0 N=10 quotient");
        assertEq(cQB0, 60_000_000, "B=0 N=10 charge=A");
        assertEq(rQB0, 0,          "B=0 N=10 refund=0");

        // After funding sponsor, previewAllocation succeeds.
        usdc.mint(sponsor, S);
        vm.prank(sponsor); usdc.approve(address(cr), S);
        vm.prank(sponsor); cr.fundSponsor();
        (uint256 qF, uint256 rF, uint256 cQF,, uint256 rQF,) = cr.previewAllocation(M);
        // N=8: q=75e6, r=0, charge=60e6, refund=0.
        assertEq(qF,  75_000_000, "funded N=8 quotient");
        assertEq(rF,  0,          "funded N=8 remainder=0");
        assertEq(cQF, 60_000_000, "funded N=8 charge=60e6");
        assertEq(rQF, 0,          "funded N=8 refund=0");

        // Funded failure range still refunds the full per-unit deposit.
        (uint256 q7, uint256 r7, uint256 cQ7,, uint256 rQ7,) = cr.previewAllocation(7);
        assertEq(q7, 0, "funded N7 quotient");
        assertEq(r7, 0, "funded N7 remainder");
        assertEq(cQ7, 0, "funded N7 charge");
        assertEq(rQ7, A, "funded N7 full refund");

        // N=0 funded: actualReserve = S = 180e6.
        assertEq(cr.previewSponsorCredit(0), S, "N=0 funded: returns S (actualReserve)");
        // N < minUnits funded: returns actualReserve = S.
        assertEq(cr.previewSponsorCredit(1), S, "N=1<min funded: returns actualReserve");
    }

    // =========================================================================
    // TEST 22b: previewWalletRefundExact unfunded/length regressions
    // =========================================================================
    function test_previewWalletRefundExact_unfundedAndLength() public {
        // Unfunded campaign: B>0, sponsor never called fundSponsor.
        CommonRate cr = _deploy();   // sponsor not yet funded

        uint256[] memory one = new uint256[](1);
        one[0] = 0;

        // N=7 (failure range): no sponsored paid units are possible unfunded.
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.previewWalletRefundExact(7, one);

        // N=M (success range), unfunded: reverts SponsorNotFunded.
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.previewWalletRefundExact(M, one);

        // N=K (success range), unfunded: reverts SponsorNotFunded.
        vm.expectRevert(CommonRate.SponsorNotFunded.selector);
        cr.previewWalletRefundExact(K, one);

        // B=0 campaign: previewWalletRefundExact N>=minUnits works without sponsor.
        CommonRate crB0 = new CommonRate(
            address(usdc), seller, address(0),
            C, A, 0, K, 10, block.timestamp + 100,
            "B0wr", "B=0 wallet refund", bytes32(0)
        );
        // N=K=12, B=0: q=50e6, charge=50e6, refund=10e6.
        assertEq(crB0.previewWalletRefundExact(12, one), 10_000_000, "B=0 N=12 refund 10e6");

        // seatIndices.length=13 > capacity=12: PreviewExceedsCapacity before any scan.
        uint256[] memory big = new uint256[](13);
        for (uint256 i = 0; i < 13; i++) big[i] = i % 10; // values don't matter
        vm.expectRevert(CommonRate.PreviewExceedsCapacity.selector);
        cr.previewWalletRefundExact(K, big);
    }

    // =========================================================================
    // TEST 23: Reentrant fundSponsor/reserve via callback token
    // =========================================================================
    // ReentrantIncomingToken overrides transferFrom: after updating balances,
    // its callback attempts to reenter either fundSponsor() or reserve(1) on
    // the campaign. Both inner attempts must revert ReentrancyDetected.
    // Outer operation must complete normally (funding/reserve recorded once).

    function test_reentrantIncoming_fundSponsorAndReserve() public {
        uint256 dl = block.timestamp + 300;

        // Build a reentrant token for the sponsor path.
        ReentrantIncomingToken rToken = new ReentrantIncomingToken(6);

        // Deploy campaign with this token; sponsor = address(rToken) (named sponsor).
        // B=15e6, K=12, S=180e6, C=600e6, A=60e6, m=8.
        CommonRate cr = new CommonRate(
            address(rToken),
            address(0xA001),    // seller
            address(rToken),    // sponsor IS the token contract
            600_000_000,
            60_000_000,
            15_000_000,
            12, 8, dl,
            "reentrant-fund", "reentrancy test", bytes32(0)
        );

        // Configure token to reenter fundSponsor on the next transferFrom callback.
        rToken.setReenterTarget(address(cr), ReentrantIncomingToken.Mode.FundSponsor);
        rToken.mint(address(rToken), 180_000_000); // sponsor holds tokens
        // Approve: sponsor approves campaign for S.
        vm.prank(address(rToken));
        rToken.approve(address(cr), 180_000_000);

        // fundSponsor: outer call should succeed; inner reentrant fundSponsor revert captured.
        vm.prank(address(rToken));
        cr.fundSponsor();

        // Outer succeeded exactly once.
        assertTrue(cr.sponsorFunded(), "sponsor funded after outer fundSponsor");
        assertEq(cr.actualReserve(), 180_000_000, "actualReserve == S after outer");
        // Inner attempt was made and captured.
        assertTrue(rToken.reentryAttempted(), "reentrant fundSponsor was attempted");
        assertEq(rToken.reentryRevertSelector(), CommonRate.ReentrancyDetected.selector,
            "inner fundSponsor reverted ReentrancyDetected");

        // Now test reentrant reserve during fundSponsor: use a buyer token.
        ReentrantIncomingToken rToken2 = new ReentrantIncomingToken(6);
        CommonRate cr2 = new CommonRate(
            address(rToken2),
            address(0xA002),    // seller
            address(0xA003),    // sponsor (separate, non-reentrant)
            600_000_000, 60_000_000, 15_000_000,
            12, 8, dl + 1,
            "reentrant-res", "reserve reentry test", bytes32(0)
        );

        // Fund sponsor (non-reentrant path) first.
        rToken2.mint(address(0xA003), 180_000_000);
        vm.startPrank(address(0xA003));
        rToken2.approve(address(cr2), 180_000_000);
        cr2.fundSponsor();
        vm.stopPrank();

        // Configure buyer token to reenter reserve(1) during transferFrom.
        rToken2.setReenterTarget(address(cr2), ReentrantIncomingToken.Mode.Reserve);
        rToken2.mint(address(0xA004), 60_000_000 * 2); // enough for 2 units
        vm.startPrank(address(0xA004));
        rToken2.approve(address(cr2), 60_000_000 * 2);
        // Outer reserve(1): inner reentrant reserve(1) should be ReentrancyDetected.
        cr2.reserve(1);
        vm.stopPrank();

        // Outer reserved exactly 1 unit.
        assertEq(cr2.unitCount(), 1, "outer reserve recorded 1 unit");
        assertTrue(rToken2.reentryAttempted(), "reentrant reserve was attempted");
        assertEq(rToken2.reentryRevertSelector(), CommonRate.ReentrancyDetected.selector,
            "inner reserve reverted ReentrancyDetected");
    }

    // =========================================================================
    // TEST 24: Tiny fixture C=120000, A=60000, B=10000, m=2, K=3, N=2
    // =========================================================================
    // Seller=120000, each buyer seat charge=50000/refund=10000 (2 seats = 20000),
    // sponsor used=20000/credit=10000. Total=150000=N*A+S.

    function test_tiny_C120k_N2() public {
        uint256 tC = 120_000;
        uint256 tA = 60_000;
        uint256 tB = 10_000;
        uint256 tK = 3;
        uint256 tM = 2;
        uint256 tN = 2;
        uint256 tS = tB * tK; // 30_000
        uint256 dl = block.timestamp + 100;

        address tSeller  = address(0xC001);
        address tSponsor = address(0xC002);
        address tBuyer   = address(0xC003);

        // Independent math:
        // q = 120000/2 = 60000; r = 0 -> no remainder seats.
        // seat0,seat1: gross=60000, charge=60000-10000=50000, refund=60000-50000=10000.
        // seller=120000, buyer=2*10000=20000, sponsor=30000-2*10000=10000. total=150000.
        uint256 expSeller  = 120_000;
        uint256 expBuyer   = 20_000;
        uint256 expSponsor = 10_000;
        uint256 expTotal   = expSeller + expBuyer + expSponsor; // 150_000

        MockUSDC tUsdc = new MockUSDC();
        tUsdc.mint(tSponsor, tS);
        tUsdc.mint(tBuyer,   tA * tN);

        CommonRate cr = new CommonRate(
            address(tUsdc), tSeller, tSponsor,
            tC, tA, tB, tK, tM, dl,
            "tiny", "tiny fixture", bytes32(0)
        );

        vm.startPrank(tSponsor);
        tUsdc.approve(address(cr), tS);
        cr.fundSponsor();
        vm.stopPrank();

        vm.startPrank(tBuyer);
        tUsdc.approve(address(cr), tA * tN);
        cr.reserve(tN);
        vm.stopPrank();

        assertEq(tUsdc.balanceOf(address(cr)), expTotal, "held==150000");

        vm.warp(dl);
        cr.finalize();

        assertTrue(cr.succeeded(), "tiny N=2 succeeds");
        assertEq(cr.credits(tSeller),  expSeller,  "seller 120000");
        assertEq(cr.credits(tBuyer),   expBuyer,   "buyer 20000");
        assertEq(cr.credits(tSponsor), expSponsor, "sponsor 10000");
        assertEq(cr.totalOutstanding(), expTotal,  "outstanding 150000");

        // Per-seat check: q=60000, r=0, charge=50000, refund=10000.
        for (uint256 i = 0; i < tN; i++) {
            (uint256 g, uint256 c, uint256 rf) = cr.seatAllocation(i);
            assertEq(g,  60_000, "gross 60000");
            assertEq(c,  50_000, "charge 50000");
            assertEq(rf, 10_000, "refund 10000");
        }

        // Claims transfer exactly.
        vm.prank(tSeller);  cr.claim();
        vm.prank(tBuyer);   cr.claim();
        vm.prank(tSponsor); cr.claim();
        assertEq(tUsdc.balanceOf(address(cr)), 0,          "no dust");
        assertEq(cr.totalOutstanding(),        0,          "outstanding 0");
        assertEq(tUsdc.balanceOf(tSeller),     expSeller,  "seller received");
        assertEq(tUsdc.balanceOf(tBuyer),      expBuyer,   "buyer received");
        assertEq(tUsdc.balanceOf(tSponsor),    expSponsor, "sponsor received");
    }

    // =========================================================================
    // TEST 25: Fully-sponsored C=30e6, A=1e6, B=10e6, m=3, K=3, N=3
    // =========================================================================
    // Sponsor covers entire cost: charge=0 per seat, buyer refund=A=1e6 each.
    // Seller=30e6, buyer=3e6 (full A returned), sponsor=0 (S fully used).
    // Verifies full-refund path is SUCCESS not failure.

    function test_fullySponsoredRound() public {
        uint256 fC = 30_000_000;   // 30 USDC
        uint256 fA =  1_000_000;   //  1 USDC
        uint256 fB = 10_000_000;   // 10 USDC
        uint256 fK = 3;
        uint256 fM = 3;
        uint256 fN = 3;
        uint256 fS = fB * fK; // 30_000_000

        // Validate guards: B*K=30e6=C (<=C ok); (A+B)*m=11e6*3=33e6>=30e6 ok.

        // Independent math:
        // q=30e6/3=10e6, r=0.
        // seat i: gross=10e6, charge=10e6-10e6=0, refund=1e6-0=1e6.
        // seller=30e6, buyer=3*1e6=3e6, sponsor=30e6-3*10e6=0. total=33e6=N*A+S.
        uint256 expFSeller  = 30_000_000;
        uint256 expFBuyer   =  3_000_000;
        uint256 expFSponsor =          0;
        uint256 expFTotal   = expFSeller + expFBuyer + expFSponsor; // 33_000_000

        uint256 dl = block.timestamp + 100;
        address fSeller  = address(0xD001);
        address fSponsor = address(0xD002);
        address fBuyer   = address(0xD003);

        MockUSDC fUsdc = new MockUSDC();
        fUsdc.mint(fSponsor, fS);
        fUsdc.mint(fBuyer,   fA * fN);

        CommonRate cr = new CommonRate(
            address(fUsdc), fSeller, fSponsor,
            fC, fA, fB, fK, fM, dl,
            "fullsponsor", "fully sponsored", bytes32(0)
        );

        vm.startPrank(fSponsor);
        fUsdc.approve(address(cr), fS);
        cr.fundSponsor();
        vm.stopPrank();

        vm.startPrank(fBuyer);
        fUsdc.approve(address(cr), fA * fN);
        cr.reserve(fN);
        vm.stopPrank();

        assertEq(fUsdc.balanceOf(address(cr)), expFTotal, "held==33e6");

        vm.warp(dl);
        cr.finalize();

        assertTrue(cr.succeeded(), "fully sponsored succeeds");
        assertEq(cr.credits(fSeller),  expFSeller,  "seller 30e6");
        assertEq(cr.credits(fBuyer),   expFBuyer,   "buyer 3e6 (all A returned)");
        assertEq(cr.credits(fSponsor), expFSponsor, "sponsor 0 (fully used)");
        assertEq(cr.totalOutstanding(), expFTotal,  "outstanding 33e6");

        // Per-seat: charge=0, refund=A — NOT failure path (gross=10e6, not 0).
        for (uint256 i = 0; i < fN; i++) {
            (uint256 g, uint256 c, uint256 rf) = cr.seatAllocation(i);
            assertEq(g,  10_000_000, "gross 10e6");
            assertEq(c,           0, "charge 0 (fully covered by sponsor)");
            assertEq(rf,  1_000_000, "refund 1e6 == A");
        }

        // Preview before finalize on fresh contract: same math.
        CommonRate crPrev = new CommonRate(
            address(fUsdc), fSeller, fSponsor,
            fC, fA, fB, fK, fM, dl + 1,
            "fullsponsor-prev", "preview", bytes32(0)
        );
        fUsdc.mint(fSponsor, fS);
        vm.prank(fSponsor); fUsdc.approve(address(crPrev), fS);
        vm.prank(fSponsor); crPrev.fundSponsor();

        // previewAllocation(3): charge=0, refund=A=1e6.
        (, , uint256 pcQ, , uint256 prQ, ) = crPrev.previewAllocation(fN);
        assertEq(pcQ, 0,         "preview charge=0");
        assertEq(prQ, 1_000_000, "preview refund=A");

        // previewSponsorCredit(3)=0: S - N*B = 0.
        assertEq(crPrev.previewSponsorCredit(fN), 0, "preview sponsor 0");

        // Claims.
        vm.prank(fSeller); cr.claim();
        vm.prank(fBuyer);  cr.claim();
        // fSponsor has credit=0; claim reverts NothingToClaim.
        vm.expectRevert(CommonRate.NothingToClaim.selector);
        vm.prank(fSponsor); cr.claim();

        assertEq(fUsdc.balanceOf(address(cr)), 0,           "no dust");
        assertEq(fUsdc.balanceOf(fSeller),     expFSeller,  "seller received");
        assertEq(fUsdc.balanceOf(fBuyer),      expFBuyer,   "buyer received 3e6");
    }

}
