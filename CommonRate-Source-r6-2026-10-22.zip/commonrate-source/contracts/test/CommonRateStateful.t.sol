// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import "../CommonRate.sol";

interface Vm {
    function prank(address) external;
    function warp(uint256) external;
}

/// Independent test-only token. Faults occur AFTER token-side effects, so a
/// rejected campaign operation must roll back nested balances and allowances.
contract FaultToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public frozen;
    uint8 public incomingMode;
    uint8 public outgoingMode;

    function mint(address to, uint256 amount) external { balanceOf[to] += amount; }
    function burn(address from, uint256 amount) external { balanceOf[from] -= amount; }
    function freeze(address account, bool value) external { frozen[account] = value; }
    function modes(uint8 incoming, uint8 outgoing) external {
        incomingMode = incoming; outgoingMode = outgoing;
    }
    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }
    function _move(address from, address to, uint256 amount) internal {
        require(!frozen[from] && !frozen[to], "mock freeze");
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
    }
    function _result(uint8 mode) internal pure returns (bool) {
        if (mode == 1) return false;
        if (mode == 2) revert("mock after movement");
        if (mode == 3) { assembly ("memory-safe") { mstore(0, 1) return(31, 1) } }
        return true;
    }
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        allowance[from][msg.sender] -= amount;
        _move(from, to, amount);
        if (incomingMode == 4) balanceOf[to] -= 1; // exact-receipt violation
        return _result(incomingMode);
    }
    function transfer(address to, uint256 amount) external returns (bool) {
        _move(msg.sender, to, amount);
        return _result(outgoingMode);
    }
}

contract LifecycleSequenceTest {
    Vm constant vm = Vm(address(uint160(uint256(keccak256("hevm cheat code")))));
    address[4] actors = [address(0xA001), address(0xA002), address(0xA003), address(0xA004)];
    CommonRate[2] rounds;
    FaultToken token;

    struct Ledger {
        uint256 C; uint256 A; uint256 B; uint256 K; uint256 m; uint256 T;
        uint8 seller; uint8 sponsor;
        uint256 N; uint256 reserve; uint256 held; uint256 paid; uint256 terminalTime;
        bool funded; bool terminal; bool success;
        uint8[12] owner;
        uint256[12] refund;
        uint256[4] buyerAllocation;
        uint256[4] original;
        uint256[4] credit;
        uint256[4] claimed;
    }
    Ledger[2] model;
    uint256[4] walletBalance;
    uint256[4][2] permissions;
    bool[4] walletFrozen;
    bool[2] escrowFrozen;
    uint8 incoming;
    uint8 outgoing;
    uint256[4] accepted; // fund, reserve, finalize, claim
    uint256[4] rejected;
    uint256 assertionCheckpoints;

    event log_named_uint(string label, uint256 count);
    event SequenceContext(uint256 seed, uint256 step, uint256 round, uint256 operation, uint256 actor);

    function eq(uint256 a, uint256 b, string memory why) internal pure { require(a == b, why); }
    function yes(bool p, string memory why) internal pure { require(p, why); }

    function _setup(uint8 layout) internal {
        delete model; delete permissions; delete walletFrozen; delete escrowFrozen;
        incoming = 0; outgoing = 0;
        token = new FaultToken();
        for (uint256 i; i < 4; ++i) {
            walletBalance[i] = 1_000_000;
            token.mint(actors[i], walletBalance[i]);
        }
        // layout 0: distinct roles; 1: all role types overlap at actor0;
        // layout 2: no sponsor. Every layout permits any actor to own seats.
        _deploy(0, 61, 23, layout == 2 ? 0 : 3, 6, 3, 0,
            layout == 1 ? 0 : 1, block.timestamp + 100);
        _deploy(1, 53, 19, 0, 6, 3, 2, 0, block.timestamp + 180);
        _check();
    }

    function _deploy(uint256 r, uint256 C, uint256 A, uint256 B, uint256 K, uint256 m,
        uint8 seller, uint8 sponsor, uint256 T) internal {
        Ledger storage x = model[r];
        x.C=C; x.A=A; x.B=B; x.K=K; x.m=m; x.T=T; x.seller=seller; x.sponsor=sponsor;
        rounds[r] = new CommonRate(address(token), actors[seller], B == 0 ? address(0) : actors[sponsor],
            C, A, B, K, m, T, "Independent audit fixture", "Offline mock only", bytes32(0));
    }

    function _approve(uint256 r, uint256 a, uint256 amount) internal {
        vm.prank(actors[a]); token.approve(address(rounds[r]), amount);
        permissions[r][a] = amount;
        _check();
    }

    function _tokenCanReceive(uint256 r, uint256 a, uint256 amount) internal view returns (bool) {
        return incoming == 0 && !walletFrozen[a] && !escrowFrozen[r]
            && permissions[r][a] >= amount && walletBalance[a] >= amount;
    }

    function _assertCall(bool actual, bool expected, bytes memory data, bytes4 expectedError, string memory label)
        internal pure {
        require(actual == expected, label);
        if (!expected && expectedError != bytes4(0)) {
            require(data.length >= 4, "missing revert selector");
            bytes4 selector; assembly ("memory-safe") { selector := mload(add(data, 32)) }
            require(selector == expectedError, "wrong revert selector");
        }
    }

    function _fund(uint256 r, uint256 a) internal {
        Ledger storage x=model[r];
        bytes4 err;
        if (x.B == 0) err=CommonRate.NoSponsorRequired.selector;
        else if (a != x.sponsor) err=CommonRate.NotSponsor.selector;
        else if (x.funded) err=CommonRate.SponsorAlreadyFunded.selector;
        else if (block.timestamp >= x.T) err=CommonRate.DeadlinePassed.selector;
        uint256 amount=x.B*x.K;
        bool expected=err == bytes4(0) && _tokenCanReceive(r,a,amount);
        if (!expected && err == bytes4(0) && incoming != 3) err=SafeTransfer.SafeTransferFailed.selector;
        vm.prank(actors[a]);
        (bool ok, bytes memory data)=address(rounds[r]).call(abi.encodeCall(CommonRate.fundSponsor, ()));
        _assertCall(ok,expected,data,err,"fund/model disagreement");
        if (expected) {
            x.funded=true; x.reserve=amount; x.held+=amount;
            walletBalance[a]-=amount; permissions[r][a]-=amount; accepted[0]++;
        } else rejected[0]++;
        _check();
    }

    function _reserve(uint256 r, uint256 a, uint256 units) internal {
        Ledger storage x=model[r];
        bytes4 err;
        if (block.timestamp >= x.T) err=CommonRate.CampaignNotOpen.selector;
        else if (x.B > 0 && !x.funded) err=CommonRate.SponsorNotFunded.selector;
        else if (units == 0) err=CommonRate.ZeroBatchSize.selector;
        else if (units > x.K-x.N) err=CommonRate.BatchExceedsCapacity.selector;
        uint256 amount=units*x.A;
        bool expected=err == bytes4(0) && _tokenCanReceive(r,a,amount);
        if (!expected && err == bytes4(0) && incoming != 3) err=SafeTransfer.SafeTransferFailed.selector;
        vm.prank(actors[a]);
        (bool ok, bytes memory data)=address(rounds[r]).call(abi.encodeCall(CommonRate.reserve,(units)));
        _assertCall(ok,expected,data,err,"reserve/model disagreement");
        if (expected) {
            eq(abi.decode(data,(uint256)),x.N,"first seat mismatch");
            for (uint256 i; i < units; ++i) x.owner[x.N+i]=uint8(a);
            x.N+=units; x.held+=amount;
            walletBalance[a]-=amount; permissions[r][a]-=amount; accepted[1]++;
        } else rejected[1]++;
        _check();
    }

    /// Expressed independently as a refund pool and tail remainder, not the
    /// implementation's gross-cost quotient and head extra-charge formula.
    function _allocate(Ledger storage x) internal {
        x.success=x.N>=x.m && x.N>0 && (x.B==0 || x.funded) && x.N*(x.A+x.B)>=x.C;
        uint256 pool=x.success ? x.N*x.A-(x.C-x.N*x.B) : x.N*x.A;
        for (uint256 i; i<x.N; ++i) {
            uint256 refund=pool/x.N;
            if (i >= x.N-pool%x.N) refund++;
            x.refund[i]=refund;
            x.buyerAllocation[x.owner[i]]+=refund;
            x.original[x.owner[i]]+=refund;
        }
        if (x.success) x.original[x.seller]+=x.C;
        if (x.B>0) x.original[x.sponsor]+=x.success ? x.reserve-x.N*x.B : x.reserve;
        for (uint256 i; i<4; ++i) x.credit[i]=x.original[i];
    }

    function _finalize(uint256 r,uint256 a) internal {
        Ledger storage x=model[r];
        bytes4 err;
        if (block.timestamp<x.T) err=CommonRate.NotYetDeadline.selector;
        else if (x.terminal) err=CommonRate.AlreadyFinalized.selector;
        else if (x.held<x.N*x.A+x.reserve) err=CommonRate.InsufficientDepositsHeld.selector;
        bool expected=err==bytes4(0);
        vm.prank(actors[a]);
        (bool ok,bytes memory data)=address(rounds[r]).call(abi.encodeCall(CommonRate.finalize,()));
        _assertCall(ok,expected,data,err,"finalize/model disagreement");
        if (expected) { x.terminal=true; x.terminalTime=block.timestamp; _allocate(x); accepted[2]++; }
        else rejected[2]++;
        _check();
    }

    function _remaining(Ledger storage x) internal view returns(uint256 sum) {
        for (uint256 i;i<4;++i) sum+=x.credit[i];
    }

    function _claim(uint256 r,uint256 a) internal {
        Ledger storage x=model[r];
        uint256 amount=x.credit[a];
        bytes4 err;
        if (amount==0) err=CommonRate.NothingToClaim.selector;
        else if (x.held<_remaining(x)) err=CommonRate.InsufficientDepositsHeld.selector;
        bool expected=err==bytes4(0) && outgoing==0 && !walletFrozen[a] && !escrowFrozen[r];
        if (!expected && err==bytes4(0) && outgoing!=3) err=SafeTransfer.SafeTransferFailed.selector;
        vm.prank(actors[a]);
        (bool ok,bytes memory data)=address(rounds[r]).call(abi.encodeCall(CommonRate.claim,()));
        _assertCall(ok,expected,data,err,"claim/model disagreement");
        if (expected) {
            x.credit[a]=0; x.claimed[a]+=amount; x.paid+=amount; x.held-=amount;
            walletBalance[a]+=amount; accepted[3]++;
        } else rejected[3]++;
        _check();
    }

    function _modes(uint8 inMode,uint8 outMode) internal {
        incoming=inMode; outgoing=outMode; token.modes(inMode,outMode); _check();
    }
    function _freezeWallet(uint256 a,bool value) internal {
        walletFrozen[a]=value; token.freeze(actors[a],value); _check();
    }
    function _freezeEscrow(uint256 r,bool value) internal {
        escrowFrozen[r]=value; token.freeze(address(rounds[r]),value); _check();
    }
    function _donate(uint256 r,uint256 amount) internal {
        model[r].held+=amount; token.mint(address(rounds[r]),amount); _check();
    }
    function _burn(uint256 r,uint256 amount) internal {
        model[r].held-=amount; token.burn(address(rounds[r]),amount); _check();
    }
    function _warp(uint256 timestamp) internal {
        require(timestamp>=block.timestamp,"time must be monotonic"); vm.warp(timestamp); _check();
    }

    function _check() internal {
        assertionCheckpoints++;
        for (uint256 a;a<4;++a) eq(token.balanceOf(actors[a]),walletBalance[a],"wallet token balance");
        for (uint256 r;r<2;++r) {
            CommonRate cr=rounds[r]; Ledger storage x=model[r];
            eq(cr.unitCount(),x.N,"unit count");
            eq(cr.totalDepositsReceived(),x.N*x.A,"lifetime deposits");
            eq(cr.actualReserve(),x.reserve,"actual reserve");
            yes(cr.sponsorFunded()==x.funded,"funded flag");
            yes(cr.finalized()==x.terminal,"terminal flag");
            yes(cr.succeeded()==x.success,"success flag");
            eq(cr.finalizedAt(),x.terminalTime,"terminal timestamp");
            eq(token.balanceOf(address(cr)),x.held,"escrow token balance");
            uint256 remaining=_remaining(x);
            eq(cr.totalOutstanding(),remaining,"total outstanding");
            eq(cr.totalClaimed(),x.paid,"total claimed");
            eq(cr.accountedLiabilities(),x.terminal?remaining:x.N*x.A+x.reserve,"liabilities");
            uint256 sellerAllocation=x.terminal && x.success?x.C:0;
            uint256 sponsorAllocation=x.terminal?(x.success?x.reserve-x.N*x.B:x.reserve):0;
            eq(cr.sellerAllocation(),sellerAllocation,"seller allocation");
            eq(cr.sponsorAllocation(),sponsorAllocation,"sponsor allocation");
            uint8 phase=x.terminal?(x.success?4:5):block.timestamp>=x.T?3:
                x.B>0&&!x.funded?0:x.N==x.K?2:1;
            eq(cr.phase(),phase,"phase");
            uint256 originals;
            for (uint256 a;a<4;++a) {
                originals+=x.original[a];
                eq(cr.credits(actors[a]),x.credit[a],"wallet credit");
                eq(cr.claimedByWallet(actors[a]),x.claimed[a],"wallet cumulative claims");
                eq(token.allowance(actors[a],address(cr)),permissions[r][a],"token allowance rollback");
                (uint256 buyer,uint256 sell,uint256 sponsor,uint256 allocated,uint256 claimed,uint256 outstanding)=cr.walletAllocation(actors[a]);
                eq(buyer,x.buyerAllocation[a],"original buyer allocation");
                eq(sell,a==x.seller?sellerAllocation:0,"original seller role");
                eq(sponsor,x.B>0&&a==x.sponsor?sponsorAllocation:0,"original sponsor role");
                eq(allocated,x.original[a],"original aggregate allocation");
                eq(claimed,x.claimed[a],"read model claimed");
                eq(outstanding,x.credit[a],"read model outstanding");
                eq(x.original[a],x.claimed[a]+x.credit[a],"per-wallet conservation");
                uint256[] memory seats=cr.seatsOf(actors[a]); uint256 cursor;
                for (uint256 i;i<x.N;++i) if (x.owner[i]==a) {
                    require(cursor<seats.length,"missing owned seat"); eq(seats[cursor++],i,"owned seat order");
                }
                eq(cursor,seats.length,"unexpected owned seat");
            }
            if (x.terminal) {
                eq(originals,x.N*x.A+x.reserve,"initial allocation conservation");
                eq(x.paid+remaining,originals,"partial claim conservation");
            }
            for (uint256 i;i<x.K;++i) {
                yes(cr.seatOwner(i)==(i<x.N?actors[x.owner[i]]:address(0)),"seat ownership/rollback");
                if (x.terminal && i<x.N) {
                    (uint256 g,uint256 ch,uint256 refund)=cr.seatAllocation(i);
                    eq(refund,x.refund[i],"seat refund");
                    eq(ch,x.success?x.A-x.refund[i]:0,"seat charge");
                    eq(g,x.success?x.A-x.refund[i]+x.B:0,"seat gross");
                }
            }
        }
    }

    function _prepare(uint256 r,uint256 n,uint8 ownerPattern) internal {
        Ledger storage x=model[r];
        for (uint256 a;a<4;++a) _approve(r,a,1_000);
        if (x.B>0) _fund(r,x.sponsor);
        // Repeated noncontiguous reservations for the same wallet are intentional.
        for (uint256 i;i<n;++i) _reserve(r,ownerPattern==0?2+i%2:i%4,1);
    }

    function _finish() internal {
        _modes(0,0);
        for (uint256 a;a<4;++a) _freezeWallet(a,false);
        for (uint256 r;r<2;++r) {
            _freezeEscrow(r,false);
            Ledger storage x=model[r];
            uint256 liabilities=x.terminal?_remaining(x):x.N*x.A+x.reserve;
            if (x.held<liabilities) _donate(r,liabilities-x.held);
        }
        uint256 end=model[1].T;
        if(block.timestamp<end) _warp(end);
        for (uint256 r;r<2;++r) {
            if(!model[r].terminal) _finalize(r,3);
            _finalize(r,1); // exact repeat error
            for (uint256 a;a<4;++a) { _claim(r,a); _claim(r,a); }
            eq(_remaining(model[r]),0,"completion leaves liability");
        }
    }

    function _permutations(uint8 scenario) internal {
        uint256 count;
        for(uint256 a;a<4;++a) for(uint256 b;b<4;++b) if(b!=a)
        for(uint256 c;c<4;++c) if(c!=a&&c!=b)
        for(uint256 d;d<4;++d) if(d!=a&&d!=b&&d!=c) {
            _setup(scenario==2?1:scenario==4?2:0);
            _prepare(0,scenario==1?2:4,scenario<2?0:1);
            _donate(0,7);
            _warp(model[0].T-1); _finalize(0,3); _claim(0,a);
            _warp(model[0].T); _reserve(0,2,1); _finalize(0,3);
            uint256[4] memory order=[a,b,c,d];
            for(uint256 i;i<4;++i) {
                _claim(0,order[i]); _claim(0,order[i]);
                _finalize(0,order[i]); _reserve(0,order[i],1); _fund(0,order[i]);
            }
            eq(model[0].held,7,"unsolicited surplus changed by claim order");
            eq(_remaining(model[0]),0,"permutation did not drain all claims");
            count++;
        }
        eq(count,24,"not all four-wallet permutations");
        emit log_named_uint("claim-order permutations",count);
    }
    function test_24Orders_sponsoredSuccess() public { _permutations(0); }
    function test_24Orders_sponsoredFailure() public { _permutations(1); }
    function test_24Orders_allRoleTypesOverlap() public { _permutations(2); }
    function test_24Orders_sellerSponsorAlsoBuyers() public { _permutations(3); }
    function test_24Orders_unsponsoredSuccess() public { _permutations(4); }

    function test_blockedBuyerEscrowFreezeAndAfterMoveClaimRecovery() public {
        _setup(0); _prepare(0,4,0); _prepare(1,4,1);
        _freezeWallet(2,true); // before finalization; no token payout dependency
        _warp(model[0].T); _finalize(0,3);
        _claim(0,2); _claim(0,0); _claim(0,3);
        // Positive sponsor credit: nested token movement must be rolled back.
        for(uint8 mode=1;mode<=3;++mode) { _modes(0,mode); _claim(0,1); }
        _modes(0,0); _claim(0,1);
        _freezeWallet(2,false); _freezeEscrow(0,true); _claim(0,2);
        _warp(model[1].T); _finalize(1,0);
        for(uint256 a;a<4;++a) _claim(1,a); // same-token other escrow unaffected
        _freezeEscrow(0,false); _claim(0,2); _claim(0,2);
        _finish();
    }

    function test_postPartialClaimDeficitProtectsEveryRemainingWallet() public {
        _setup(0); _prepare(0,4,0);
        _warp(model[0].T); _finalize(0,3); _claim(0,2);
        uint256 partialPaid=model[0].paid; yes(partialPaid>0,"partial payout missing");
        _burn(0,1);
        for(uint256 a;a<4;++a) _claim(0,a);
        eq(model[0].paid,partialPaid,"underbacked pool paid a remaining wallet");
        _donate(0,1);
        for(uint256 a=4;a>0;--a) _claim(0,a-1);
        eq(model[0].held,0,"repair changes terminal pool");
        _finish();
    }

    function test_afterMoveIncomingFailuresRecoverWithStableSeatOrdering() public {
        _setup(0);
        for(uint256 a;a<4;++a) _approve(0,a,1_000);
        for(uint8 mode=1;mode<=4;++mode) { _modes(mode,0); _fund(0,1); }
        _modes(0,0); _fund(0,1); _reserve(0,2,1);
        for(uint8 mode=1;mode<=4;++mode) { _modes(mode,0); _reserve(0,3,2); }
        _modes(0,0); _reserve(0,0,1); _reserve(0,3,2); _reserve(0,2,1);
        _finish();
    }

    function _schedules(uint256 firstSeed, uint256 lastSeed) internal {
        for(uint256 seed=firstSeed;seed<=lastSeed;++seed) {
            _setup(uint8(seed%3));
            for(uint256 r;r<2;++r) for(uint256 a;a<4;++a) _approve(r,a,1_000);
            _claim(0,2); _finalize(0,3);
            if(model[0].B>0 && seed%4!=0) _fund(0,model[0].sponsor);
            uint256 wanted=seed%4==0?0:seed%4==1?2:seed%4==2?4:6;
            for(uint256 i;i<wanted;++i) _reserve(0,(seed+i)%4,1);
            for(uint256 i;i<seed%7;++i) _reserve(1,(seed*3+i)%4,1);
            uint256 rng=seed;
            for(uint256 step;step<64;++step) {
                if(step==16) _warp(model[0].T-1);
                if(step==24) { _warp(model[0].T); _finalize(0,3); }
                if(step==40) _warp(model[1].T-1);
                if(step==48) { _warp(model[1].T); _finalize(1,0); }
                rng=uint256(keccak256(abi.encode(rng,seed,step)));
                uint256 r=rng%2; uint256 a=(rng>>8)%4; uint256 op=(rng>>16)%12;
                emit SequenceContext(seed,step,r,op,a);
                if(op==0) _approve(r,a,(rng>>24)%5==0?0:(rng>>32)%100);
                else if(op==1) _fund(r,a);
                else if(op==2) _reserve(r,a,(rng>>24)%9);
                else if(op==3) _finalize(r,a);
                else if(op==4) _claim(r,a);
                else if(op==5) _modes(uint8((rng>>24)%5),uint8((rng>>32)%4));
                else if(op==6) _freezeWallet(a,!walletFrozen[a]);
                else if(op==7) _freezeEscrow(r,!escrowFrozen[r]);
                else if(op==8) _donate(r,1+(rng>>24)%5);
                else if(op==9) { if(model[r].held>0) _burn(r,1); else _claim(r,a); }
                else if(op==10) _reserve(r,a,1);
                else _claim(r,model[r].seller);
            }
            _finish();
        }
        for(uint256 i;i<4;++i) {
            yes(accepted[i]>0,"operation never succeeded");
            yes(rejected[i]>0,"operation never rejected");
        }
        emit log_named_uint("first seed",firstSeed);
        emit log_named_uint("last seed",lastSeed);
        emit log_named_uint("deterministic schedules",lastSeed-firstSeed+1);
        emit log_named_uint("generated actions",(lastSeed-firstSeed+1)*64);
        emit log_named_uint("full two-round assertion checkpoints",assertionCheckpoints);
        emit log_named_uint("fund accepted",accepted[0]); emit log_named_uint("fund rejected",rejected[0]);
        emit log_named_uint("reserve accepted",accepted[1]); emit log_named_uint("reserve rejected",rejected[1]);
        emit log_named_uint("finalize accepted",accepted[2]); emit log_named_uint("finalize rejected",rejected[2]);
        emit log_named_uint("claim accepted",accepted[3]); emit log_named_uint("claim rejected",rejected[3]);
    }
    function test_statefulSeeds01To04() public { _schedules(1,4); }
    function test_statefulSeeds05To08() public { _schedules(5,8); }
    function test_statefulSeeds09To12() public { _schedules(9,12); }
    function test_statefulSeeds13To16() public { _schedules(13,16); }
    function test_statefulSeeds17To20() public { _schedules(17,20); }
    function test_statefulSeeds21To24() public { _schedules(21,24); }
    function test_statefulSeeds25To28() public { _schedules(25,28); }
    function test_statefulSeeds29To32() public { _schedules(29,32); }
}
