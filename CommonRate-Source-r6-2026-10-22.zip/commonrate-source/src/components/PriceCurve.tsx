import type { CampaignTerms } from '../simulation/types';
import { computeGates } from '../simulation/math';
import { formatAmount, quoteSeats } from '../simulation/presentation';

interface Props { terms: CampaignTerms; highlightN: number; sponsorFunded: boolean }

/** Chart geometry uses bounded integer ratios. All money and quote arithmetic stays BigInt. */
export default function PriceCurve({ terms, highlightN, sponsorFunded }: Props) {
  const capacity = Number(terms.capacity);
  const points = Array.from({ length: capacity }, (_, i) => i + 1).flatMap(count => {
    const gates = computeGates(terms, count, sponsorFunded, true);
    if (!gates.gateMinUnits || !gates.gateEligibleFunding || !gates.gateSponsorFunded) return [];
    const seats = quoteSeats(terms, count, sponsorFunded);
    if (!seats?.length) return [];
    return [{ count, low: seats[seats.length - 1].charge, high: seats[0].charge }];
  });
  if (!points.length) return <p className="cr-note">No successful price is available until the required sponsor funding and minimum are met.</p>;
  const first = points[0].count;
  const x = (count: number) => 44 + (capacity === first ? 0.5 : (count - first) / (capacity - first)) * 412;
  const y = (value: bigint) => 30 + (terms.depositPerUnit === 0n ? 0 : Number((terms.depositPerUnit - value) * 110_000n / terms.depositPerUnit) / 1000);
  const selected = points.find(point => point.count === highlightN);
  const range = (low: bigint, high: bigint) => low === high ? formatAmount(low) : `${formatAmount(low)}–${formatAmount(high)}`;
  return (
    <figure className="cr-price-curve">
      <svg viewBox="0 0 500 185" role="img" aria-label={`Successful per-seat prices from ${first} to ${capacity} reserved seats. Exact values follow in the price table.`}>
        {[0n, terms.depositPerUnit / 2n, terms.depositPerUnit].map(value => (
          <g key={String(value)}>
            <line x1="44" x2="456" y1={y(value)} y2={y(value)} stroke="var(--cr-rule)" />
            <text x="32" y={y(value) + 4} textAnchor="end" fill="var(--cr-muted)" fontSize="11">{formatAmount(value)}</text>
          </g>
        ))}
        <path d={points.map((point, i) => `${i === 0 ? 'M' : 'L'} ${x(point.count)} ${y(point.high)}`).join(' ')} fill="none" stroke="var(--cr-accent)" strokeWidth="2" />
        {points.map(point => (
          <g key={point.count}>
            <circle cx={x(point.count)} cy={y(point.high)} r={point.count === highlightN ? 5 : 3} fill={point.count === highlightN ? 'var(--cr-accent)' : 'var(--cr-paper)'} stroke="var(--cr-accent)" strokeWidth="2" />
            <text x={x(point.count)} y="163" textAnchor="middle" fill="var(--cr-muted)" fontSize="12">{point.count}</text>
          </g>
        ))}
        <text x="250" y="182" textAnchor="middle" fill="var(--cr-muted)" fontSize="11">Reserved seats</text>
      </svg>
      <figcaption className="cr-note">{selected ? `${highlightN} seats: ${range(selected.low, selected.high)} USDC each.` : 'The current count has no successful price.'} Only successful, sponsor-funded outcomes are plotted. The line follows the higher exact charge when rounding creates two prices.</figcaption>
      <details className="cr-disclosure">
        <summary>Exact price table</summary>
        <div className="cr-table-scroll" tabIndex={0} role="region" aria-label="Exact price table, scroll horizontally if needed">
          <table><caption>Conditional successful prices at the deadline, in USDC</caption><thead><tr><th>Seats</th><th>Charge per seat</th><th>Refund per seat</th></tr></thead><tbody>
            {points.map(point => <tr key={point.count}><td>{point.count}</td><td>{range(point.low, point.high)}</td><td>{range(terms.depositPerUnit - point.high, terms.depositPerUnit - point.low)}</td></tr>)}
          </tbody></table>
        </div>
      </details>
    </figure>
  );
}
