import { useRef, type RefObject, type ReactNode } from 'react';
import type { SimState } from '../simulation/types';
import { computeGates } from '../simulation/math';
import { formatAmount, type SampleReceipt } from '../simulation/presentation';

export function receiptEmphasis(state: SimState, receipt: SampleReceipt) {
  if (state.finalized) {
    if (receipt.outstanding > 0n) return { label: 'Available to claim', amount: receipt.outstanding, state: 'Settled · simulated credit' };
    if (receipt.claimed > 0n) return { label: 'Marked claimed', amount: receipt.claimed, state: 'Recorded in this simulation' };
    return { label: 'Nothing to claim', amount: 0n, state: 'Settled · no outstanding credit' };
  }
  const gates = computeGates(state.terms, state.unitCount, state.sponsorFunded, state.deadlinePassed);
  if (!gates.gateSponsorFunded) return { label: 'Reservations closed', amount: null, state: state.deadlinePassed ? 'Awaiting finalization' : 'Waiting for sponsor funding' };
  if (!gates.gateMinUnits || !gates.gateEligibleFunding) return { label: 'Deposit held', amount: receipt.deposit, state: state.deadlinePassed ? 'Funding condition not met · awaiting finalization' : 'Funding condition not met' };
  return { label: 'Estimated final cost', amount: receipt.charge, state: state.deadlinePassed ? 'Awaiting finalization' : BigInt(state.unitCount) >= state.terms.capacity ? 'Full · waiting for deadline' : 'Open · estimate, not final' };
}

type Props = {
  state: SimState;
  receipt: SampleReceipt;
  compact?: boolean;
  outcomeControl?: ReactNode;
  onClaim: () => void;
  onExplore?: () => void;
  exploreRef?: RefObject<HTMLButtonElement>;
  receiptHeadingRef?: RefObject<HTMLHeadingElement>;
};

export default function ReservationReceipt({ state, receipt, compact = false, outcomeControl, onClaim, onExplore, exploreRef, receiptHeadingRef }: Props) {
  const localHeadingRef = useRef<HTMLHeadingElement>(null);
  const headingRef = receiptHeadingRef ?? localHeadingRef;
  const emphasis = receiptEmphasis(state, receipt);
  const gates = computeGates(state.terms, state.unitCount, state.sponsorFunded, state.deadlinePassed);
  const canSucceed = gates.gateMinUnits && gates.gateEligibleFunding && gates.gateSponsorFunded;
  const amount = emphasis.amount === null ? null : formatAmount(emphasis.amount);
  const estimate = state.deadlinePassed
    ? `The deadline has passed. ${canSucceed ? 'Funding conditions are met.' : 'Funding conditions were not met.'} Finalization is still required.`
    : canSucceed
    ? `Estimate assumes ${state.unitCount} seats at the deadline. Deposits stay locked until then.`
    : gates.gateSponsorFunded
      ? 'If the round fails at the deadline, the full deposit becomes claimable after finalization.'
      : 'Reservations open only after the required sponsor reserve is deposited.';
  const explanation = state.finalized
    ? `${state.finalizeResult?.branch === 'success' ? 'Funding conditions were met.' : receipt.deposit > 0n ? 'The failed funding round made the full deposit claimable.' : 'The round failed. This example wallet had no deposit to refund.'} Withdrawal is a separate step. No real funds moved.`
    : `${estimate} Finalization records credits; withdrawal is a separate step.`;

  return <aside className={`cr-receipt${compact ? ' cr-receipt-compact' : ''}`} aria-labelledby="receipt-title">
    <div className="cr-receipt-top"><span className="cr-eyebrow">Your reservation</span><span className="cr-receipt-state">{state.phase === 'Open' && canSucceed ? `${state.unitCount} seats · open` : emphasis.state}</span></div>
    <h2 id="receipt-title" ref={headingRef} tabIndex={-1}>{receipt.indices.length ? `${receipt.indices.length} ${receipt.indices.length === 1 ? 'seat' : 'seats'} · ${formatAmount(receipt.deposit)} USDC deposited` : 'No seats reserved yet.'}</h2>
    {outcomeControl && <div className="cr-receipt-outcome-control">{outcomeControl}</div>}
    <div className="cr-receipt-total">
      <span>{emphasis.label}</span>
      {amount !== null && <p className={amount.length > 8 ? 'is-exact-amount' : undefined}><span>{amount}</span><small>USDC</small></p>}
    </div>
    {(!compact || !state.finalized) && <dl className="cr-ledger cr-refund-summary"><div>
      <dt>{state.finalized ? 'Original refund allocation' : canSucceed ? 'Estimated deposit refund' : 'Refund if the round fails'}</dt>
      <dd>{receipt.refund === null ? 'Not available' : `${formatAmount(receipt.refund)} USDC`}</dd>
    </div></dl>}
    {state.finalized && receipt.outstanding > 0n && <button className="cr-btn cr-btn-primary cr-full-width" onClick={() => { onClaim(); window.requestAnimationFrame(() => headingRef.current?.focus({ preventScroll: true })); }}>Mark {formatAmount(receipt.outstanding)} USDC claimed</button>}
    {onExplore && <button ref={exploreRef} className={`cr-btn cr-full-width ${state.finalized && receipt.outstanding > 0n ? 'cr-btn-ghost' : 'cr-btn-primary'}`} onClick={onExplore}>Explore payment outcomes <span aria-hidden="true">→</span></button>}
    {compact && !state.finalized && receipt.deposit > 0n && <p className="cr-note cr-receipt-timing">{state.deadlinePassed ? 'Deadline passed. Finalize before any claim.' : 'Locked until deadline. Finalize, then claim.'}</p>}
    {!compact && <p className="cr-receipt-explainer">{explanation}</p>}
    <details className="cr-disclosure cr-receipt-details">
      <summary>{compact ? 'View full receipt' : 'Exact receipt and payment rules'}</summary>
      {compact && <p className="cr-receipt-explainer">{explanation}</p>}
      <dl className="cr-ledger">
        <div><dt>Original deposit</dt><dd>{formatAmount(receipt.deposit)} USDC</dd></div>
        <div><dt>{state.finalized ? 'Final cost' : 'Estimated cost if settled here'}</dt><dd>{receipt.charge === null ? 'Not available' : `${formatAmount(receipt.charge)} USDC`}</dd></div>
        {compact && state.finalized && <div><dt>Original refund allocation</dt><dd>{receipt.refund === null ? 'Not available' : `${formatAmount(receipt.refund)} USDC`}</dd></div>}
        {state.finalized && <><div><dt>Marked claimed</dt><dd>{formatAmount(receipt.claimed)} USDC</dd></div><div><dt>Still available to claim</dt><dd>{formatAmount(receipt.outstanding)} USDC</dd></div></>}
      </dl>
      <p className="cr-note">Example wallet participant.00. Seat indices: {receipt.indices.length ? receipt.indices.join(', ') : 'none'}. A seat is a paid unit, not a verified person. Exact wallet amounts add the owned indices, never a rounded average. The first cost-remainder indices pay one extra micro-USDC.</p>
      <p className="cr-note">Deposits cannot be withdrawn early. Funding-round refunds do not cover later cancellation, nonattendance or provider nondelivery. Use a provider you trust.</p>
    </details>
    <p className="cr-receipt-footnote">Simulation only. No wallet or real transaction.</p>
  </aside>;
}
