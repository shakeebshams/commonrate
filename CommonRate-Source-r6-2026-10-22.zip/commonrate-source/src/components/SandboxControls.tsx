import { useRef, useState } from 'react';
import type { SimState, WalletReceipt } from '../simulation/types';
import type { ScenarioId } from '../simulation/engine';
import { buildWalletReceipts, fundSponsor, reserve, passDeadline, finalize, simulateClaim, participantAddr } from '../simulation/engine';
import { formatAmount, quoteSeats } from '../simulation/presentation';

interface Props {
  state: SimState;
  onStateChange: (state: SimState, announcement?: string) => void;
  scenarioId: ScenarioId | null;
  onSelectScenario: (id: ScenarioId) => void;
  onReset: () => void;
  onViewReceipt: () => void;
}

export type CompletedReservation = { state: SimState; quantity: number };
export type CompletedSandboxAction = { state: SimState; message: string };

export function completedActionAnnouncement(completed: CompletedSandboxAction | null, current: SimState) {
  return completed?.state === current ? completed.message : null;
}

export function claimCompletionText(receipt: WalletReceipt) {
  return `Marked ${formatAmount(receipt.claimable)} USDC claimed for ${receipt.address} in this simulation. No real funds moved.`;
}

export function ClaimRow({ receipt, onClaim }: { receipt: WalletReceipt; onClaim: () => boolean }) {
  const walletHeading = useRef<HTMLHeadingElement>(null);
  return <div className="cr-claim-row"><div><h4 ref={walletHeading} tabIndex={-1}>{receipt.address}</h4><span>{receipt.role.join(' + ')} · {formatAmount(receipt.claimable)} USDC outstanding</span></div>{receipt.claimable > 0n ? <button className="cr-btn cr-btn-ghost" onClick={() => { if (onClaim()) window.requestAnimationFrame(() => walletHeading.current?.focus({ preventScroll: true })); }}>Mark claimed</button> : <span className="cr-note">{receipt.claimed > 0n ? `${formatAmount(receipt.claimed)} USDC marked claimed` : 'No credit to claim'}</span>}</div>;
}

export function reservationCompletionText(completed: CompletedReservation | null, current: SimState) {
  if (!completed || completed.state !== current || current.phase !== 'Open') return null;
  return `Added ${completed.quantity} ${completed.quantity === 1 ? 'seat' : 'seats'}. ${current.unitCount} of ${String(current.terms.capacity)} seats reserved.`;
}

export function ReservationCompletion({ message, onViewReceipt }: { message: string; onViewReceipt: () => void }) {
  return <div className="cr-reservation-completion"><p>{message}</p><button type="button" className="cr-text-button" onClick={onViewReceipt}>View updated receipt</button></div>;
}

export default function SandboxControls({ state, onStateChange, scenarioId, onSelectScenario, onReset, onViewReceipt }: Props) {
  const [form, setForm] = useState<{ scenarioId: ScenarioId | null; quantity: number; error: string | null }>({ scenarioId, quantity: 1, error: null });
  const [completed, setCompleted] = useState<CompletedReservation | null>(null);
  const completion = reservationCompletionText(completed, state);
  // A preset changes the form context without remounting the focused controls.
  const quantity = form.scenarioId === scenarioId ? form.quantity : 1;
  const error = form.scenarioId === scenarioId ? form.error : null;
  const updateForm = (next: { quantity?: number; error?: string | null }) => setForm({ scenarioId, quantity, error, ...next });
  const { terms, phase, unitCount } = state;
  const remaining = Number(terms.capacity) - unitCount;
  const validQuantity = Number.isSafeInteger(quantity) && quantity >= 1 && quantity <= remaining;
  const projectedCount = unitCount + quantity;
  const newSeats = validQuantity ? quoteSeats(terms, projectedCount, state.sponsorFunded)?.slice(unitCount) : null;
  const projectedCharge = newSeats?.reduce((sum, seat) => sum + seat.charge, 0n);
  const projectedReturn = newSeats?.reduce((sum, seat) => sum + seat.refund, 0n);
  const receipts = buildWalletReceipts(state);
  const act = (action: () => SimState, reservationQuantity?: number, announcement?: string) => {
    try {
      const next = action();
      updateForm({ error: null });
      setCompleted(reservationQuantity === undefined ? null : { state: next, quantity: reservationQuantity });
      onStateChange(next, announcement);
      return true;
    }
    catch (cause) { setCompleted(null); updateForm({ error: cause instanceof Error ? cause.message : String(cause) }); return false; }
  };
  const choose = (id: ScenarioId) => { setCompleted(null); updateForm({ quantity: 1, error: null }); onSelectScenario(id); };

  return <div className="cr-demo-grid">
    <section aria-label="Restart the simulation">
      <div className="cr-button-row">
        <button className="cr-btn cr-btn-ghost" onClick={() => { setCompleted(null); updateForm({ quantity: 1, error: null }); onReset(); }}>Reset to 10 open seats</button>
        <button className="cr-btn cr-btn-ghost" onClick={() => choose('await')}>Start unfunded</button>
      </div>
    </section>
    <section>
      <h3>Step through the round</h3>
      {error && <p role="alert" className="cr-error">{error}</p>}
      {phase === 'AwaitingSponsor' && <>
        <p>The required sponsor budget is {formatAmount(terms.sponsorReserve)} USDC. The actual deposited reserve is {formatAmount(state.actualReserve)} USDC.</p>
        <div className="cr-button-row">
          <button className="cr-btn cr-btn-primary" onClick={() => act(() => fundSponsor(state))}>Simulate sponsor funding</button>
          <button className="cr-btn cr-btn-ghost" onClick={() => act(() => passDeadline(state))}>Advance to deadline unfunded</button>
        </div>
        <p className="cr-note">If the deadline arrives first, settlement records failure and zero sponsor credit. No funds are invented.</p>
      </>}
      {phase === 'Open' && <>
        <label className="cr-field-label" htmlFor="reserve-quantity">Seats to add · {remaining} available</label>
        <input id="reserve-quantity" className="cr-number-input" type="number" inputMode="numeric" min={1} max={remaining} step={1} value={Number.isNaN(quantity) ? '' : quantity} onChange={event => { setCompleted(null); updateForm({ quantity: event.currentTarget.valueAsNumber }); }} />
        <div className="cr-review-box">
          <p className="cr-eyebrow">Review this simulated reservation</p>
          {validQuantity ? <>
            <dl className="cr-ledger"><div><dt>Maximum deposit for {quantity} {quantity === 1 ? 'seat' : 'seats'}</dt><dd>{formatAmount(terms.depositPerUnit * BigInt(quantity))} USDC</dd></div>
              <div><dt>New total after reserving</dt><dd>{projectedCount} seats</dd></div>
              <div><dt>Estimated charge for these new seats</dt><dd>{projectedCharge === undefined ? 'Unavailable' : `${formatAmount(projectedCharge)} USDC`}</dd></div>
              <div><dt>Estimated refund for these new seats</dt><dd>{projectedReturn === undefined ? 'Unavailable' : `${formatAmount(projectedReturn)} USDC`}</dd></div></dl>
            <p className="cr-note">Estimate uses the exact new seat indices at {projectedCount} seats, not the current {unitCount}-seat price. It can change until the deadline.</p>
          </> : <p className="cr-error">Enter a whole number from 1 to {remaining}.</p>}
          <p className="cr-note">Deposits stay locked until settlement after the deadline. No cancellation or early withdrawal. Claims are separate actions. Funding-round refunds do not cover later cancellation, nonattendance or provider nondelivery.</p>
        </div>
        <div className="cr-button-row">
          <button className="cr-btn cr-btn-primary" disabled={!validQuantity} onClick={() => act(() => reserve(state, quantity, participantAddr(0)), quantity)}>Simulate reservation</button>
          <button className="cr-btn cr-btn-ghost" onClick={() => act(() => passDeadline(state))}>Advance to deadline</button>
        </div>
        {completion && <ReservationCompletion message={completion} onViewReceipt={onViewReceipt} />}
      </>}
      {phase === 'FullAwaitDeadline' && <><p>All {String(terms.capacity)} seats are reserved. Filling the round does not settle it early.</p><button className="cr-btn cr-btn-primary" onClick={() => act(() => passDeadline(state))}>Advance to deadline</button></>}
      {phase === 'ReadyFinalize' && <><p>The deadline has passed. Settlement records each wallet’s credit; it does not transfer money.</p><button className="cr-btn cr-btn-primary" onClick={() => act(() => finalize(state))}>Simulate settlement</button></>}
      {state.finalized && <>
        <p>{state.finalizeResult?.branch === 'success' ? 'The round met its funding conditions.' : 'The round did not meet its funding conditions.'} These are simulated credits. Each wallet claims separately.</p>
        <div className="cr-claim-list">{receipts.map(receipt => <ClaimRow key={receipt.address} receipt={receipt} onClaim={() => act(() => simulateClaim(state, receipt.address), undefined, claimCompletionText(receipt))} />)}</div>
        <p className="cr-note">{formatAmount(state.totalOutstanding)} outstanding + {formatAmount(state.totalClaimed)} marked claimed = {formatAmount(state.totalOutstanding + state.totalClaimed)} USDC original deposits.</p>
      </>}
    </section>
  </div>;
}
