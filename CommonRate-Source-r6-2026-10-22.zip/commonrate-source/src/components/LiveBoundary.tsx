import { Component, createRef, type ReactNode } from 'react';

type Props = { children: ReactNode; onReturn: () => void };

/** A failed optional Live chunk must never take the local example down with it. */
export default class LiveBoundary extends Component<Props, { failed: boolean }> {
  state = { failed: false };
  private heading = createRef<HTMLHeadingElement>();

  static getDerivedStateFromError() { return { failed: true }; }

  componentDidCatch() { this.heading.current?.focus(); }

  render() {
    if (!this.state.failed) return this.props.children;
    return <section className="cr-live-error-boundary" aria-labelledby="live-unavailable-title" role="alert">
      <h1 ref={this.heading} tabIndex={-1} id="live-unavailable-title">The Live pilot could not open.</h1>
      <p>The simulated example is still available. No action will be retried automatically, and saved transaction references have not been cleared.</p>
      <p>If a wallet request was already opened, inspect its outcome before starting another. Returning to the example does not cancel a transaction.</p>
      <button className="cr-btn" onClick={this.props.onReturn}>Return to Sandbox</button>
      <p className="cr-note">To retry loading Live, reload this page. Reloading resets the simulated example, not your wallet activity.</p>
    </section>;
  }
}
