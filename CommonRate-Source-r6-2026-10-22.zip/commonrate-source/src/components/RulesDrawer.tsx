import { useEffect, useRef } from 'react';
import type { KeyboardEvent, RefObject } from 'react';

interface Props { open: boolean; onClose: () => void; openerRef?: RefObject<HTMLButtonElement> }

// Native modal focus can escape to the embedding page in Studio's iframe.
// Keep boundary Tab presses inside this dialog, including future focusable links.
export function trapDialogTab(event: KeyboardEvent<HTMLDialogElement>) {
  if (event.key !== 'Tab') return;
  const dialog = event.currentTarget;
  const focusable = Array.from(dialog.querySelectorAll<HTMLElement>('a[href], button:enabled, input:enabled:not([type="hidden"]), select:enabled, textarea:enabled, summary, [tabindex]:not(:disabled)'))
    .filter(element => element.tabIndex >= 0 && !element.hidden && element.getClientRects().length > 0);
  if (!focusable.length) { event.preventDefault(); dialog.focus(); return; }
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  const active = dialog.ownerDocument.activeElement;
  if (!focusable.includes(active as HTMLElement) || (event.shiftKey ? active === first : active === last)) {
    event.preventDefault();
    (event.shiftKey ? last : first).focus();
  }
}

export default function RulesDrawer({ open, onClose, openerRef }: Props) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const wasOpened = useRef(false);
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      dialog.showModal();
      wasOpened.current = true;
      closeRef.current?.focus();
    } else if (!open && dialog.open) {
      dialog.close();
      if (wasOpened.current) openerRef?.current?.focus();
    }
  }, [open, openerRef]);
  const sections = [
    {
      heading: 'One fixed cost, shared fairly',
      body: 'The seller sets a fixed total cost C. Each paid unit is assigned an integer share: q = ⌊C/N⌋, with the first C mod N units charged one extra micro-USDC so the exact sum is C. Buyer deposits A are the maximum; actual charge is always ≤ A.',
    },
    {
      heading: 'Sponsor subsidy reduces the charge',
      body: 'An optional sponsor pre-deposits B × K USDC (the full capacity reserve) before any buyer can reserve. B is subtracted from each unit\'s gross cost share on success. This is a fixed per-unit support, not a bulk-discount tier. On failure, the sponsor can claim exactly what was deposited.',
    },
    {
      heading: 'Paid units are not unique people',
      body: 'One wallet may hold multiple seat indices. The contract counts paid units, not identities. Allocation rules apply per seat index, regardless of how many a single wallet owns.',
    },
    {
      heading: 'Finalize is permissionless at the deadline',
      body: 'Anyone may call finalize() once the deadline has passed. Finalize records pull-claim credits — it does not transfer funds. Gates check minimum units, eligible funding N·(A+B) ≥ C, sponsor status, and deadline. Full capacity before the deadline is not early settlement.',
    },
    {
      heading: 'Claims are separate transactions',
      body: 'After finalize, each wallet calls claim() independently. One wallet\'s failed or blocked transfer cannot affect any other claimant. Credits do not expire. "Claimable" means the contract permits the claim — not that the transfer has occurred.',
    },
    {
      heading: 'No delivery guarantee',
      body: 'The contract enforces allocation rules only. It does not verify, escrow for, or guarantee seller delivery or performance. Funding-round refunds do not cover later cancellation, nonattendance or provider nondelivery. "Refund available to claim" describes the blockchain permission — it does not reverse a merchant transaction.',
    },
    {
      heading: 'No early withdrawal',
      body: 'Deposited funds are locked until the deadline. There is no cancellation, seat transfer, or early exit. If the round fails, full deposits become claimable after finalization.',
    },
    {
      heading: 'Direct token transfers create no position',
      body: 'Sending USDC directly to the contract address creates no seat, sponsorship, or claim record. Only reserve() and fundSponsor() create valid positions. Unsolicited transfers are ignored.',
    },
    {
      heading: 'USDC issuer and token risk',
      body: 'Immutable campaign terms do not remove all risk. Circle (the USDC issuer) retains the ability to freeze addresses or upgrade the USDC contract under its Terms of Service. These are external risks outside the scope of CommonRate\'s smart contract. Review Circle\'s published terms and the deployed token address before committing funds.',
    },
  ];

  return (
    <dialog ref={dialogRef} className="cr-rules-dialog" aria-labelledby="rules-title" tabIndex={-1} onKeyDown={trapDialogTab}
      onCancel={event => { event.preventDefault(); onClose(); }}
      onClick={event => { if (event.target === event.currentTarget) onClose(); }}>
      <div className="cr-rules-content">
        <div className="cr-section-head">
          <div><p className="cr-eyebrow">The terms, in plain language</p><h2 id="rules-title">How CommonRate works</h2></div>
          <button ref={closeRef} onClick={onClose} className="cr-btn cr-btn-ghost" aria-label="Close rules">Close</button>
        </div>
        <p className="cr-note">This is a local simulation. These explanations do not mean a contract has been deployed or independently audited.</p>
        {sections.map(section => <section key={section.heading} className="cr-rule-section"><h3>{section.heading}</h3><p>{section.body}</p></section>)}
      </div>
    </dialog>
  );
}
