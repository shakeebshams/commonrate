import { SCENARIOS, type ScenarioId } from '../simulation/engine';

type Props = { activeId: ScenarioId | null; onSelect: (id: ScenarioId) => void };
const LABELS: Record<ScenarioId, string> = {
  n10: '10 seats · settled successfully', n8: '8 seats · minimum reached',
  n9: '9 seats · exact remainder split', n12: '12 seats · full round settled',
  n7: '7 seats · failed round', n0: 'No reservations · closed round', await: 'Waiting for sponsor funding',
};

export default function ScenarioPicker({ activeId, onSelect }: Props) {
  return <label className="cr-field-label cr-scenario-field">Choose a payment outcome
    <select aria-describedby="outcome-help" value={activeId ?? ''} onChange={event => { if (SCENARIOS.some(s => s.id === event.target.value)) onSelect(event.target.value as ScenarioId); }}>
      <option value="" disabled>Your current working round</option>
      {SCENARIOS.map(scenario => <option key={scenario.id} value={scenario.id}>{LABELS[scenario.id]}</option>)}
    </select>
    <small id="outcome-help" className="cr-outcome-help">Replaces this simulation.</small>
  </label>;
}
