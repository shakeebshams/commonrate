import React from 'react';
import type { SimState } from '../simulation/types';
import { formatUSD } from '../simulation/math';

const PHASE_LABELS: Record<string, string> = {
  AwaitingSponsor:   'Awaiting sponsor',
  Open:              'Open',
  FullAwaitDeadline: 'Full — awaiting deadline',
  ReadyFinalize:     'Ready to finalize',
  Succeeded:         'Succeeded',
  Failed:            'Failed',
};
const PHASE_CLASS: Record<string, string> = {
  AwaitingSponsor:   'cr-phase-await',
  Open:              'cr-phase-open',
  FullAwaitDeadline: 'cr-phase-full',
  ReadyFinalize:     'cr-phase-ready',
  Succeeded:         'cr-phase-success',
  Failed:            'cr-phase-failed',
};

interface Props { state: SimState; }

export default function CampaignHero({ state }: Props) {
  const { terms, phase, unitCount, sponsorFunded, actualReserve } = state;
  const K = Number(terms.capacity);
  const m = Number(terms.minUnits);
  const totalHeld = BigInt(unitCount) * terms.depositPerUnit + actualReserve;

  return (
    <section
      aria-labelledby="hero-heading"
      style={{
        padding: '3rem 0 2rem',
        borderBottom: '1px solid var(--cr-rule)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Registration marks */}
      <span className="cr-regmark" style={{ position: 'absolute', top: 12, left: 12 }} aria-hidden="true" />
      <span className="cr-regmark" style={{ position: 'absolute', top: 12, right: 12 }} aria-hidden="true" />

      <div style={{ maxWidth: 680 }}>
        <div
          className={`cr-phase-badge ${PHASE_CLASS[phase] ?? 'cr-phase-open'}`}
          style={{ marginBottom: '1rem' }}
          aria-live="polite"
        >
          <span className="cr-dot" style={{
            background: phase === 'Succeeded' ? '#22c55e'
              : phase === 'Failed' ? 'var(--cr-rust)'
              : phase === 'AwaitingSponsor' ? '#f59e0b'
              : '#22c55e'
          }} />
          {PHASE_LABELS[phase] ?? phase}
        </div>

        <h1
          id="hero-heading"
          className="cr-serif"
          style={{ fontSize: 'clamp(2rem, 5vw, 3.25rem)', margin: '0 0 0.5rem', lineHeight: 1.1 }}
        >
          Bring more units.<br />Lower the share.
        </h1>
        <p style={{ fontSize: '1.0625rem', opacity: 0.7, margin: '0 0 2rem', maxWidth: '52ch', lineHeight: 1.6 }}>
          A community print workshop with a fixed total cost. Every paid unit splits that cost fairly.
          Paid units are <strong>not unique people</strong> — one wallet may hold multiple seats.
          The blockchain enforces allocation rules, not merchant delivery.
        </p>

        {/* Terms grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
            gap: '1px',
            background: 'var(--cr-rule)',
            border: '1px solid var(--cr-rule)',
            borderRadius: 8,
            overflow: 'hidden',
          }}
          role="list"
          aria-label="Campaign terms"
        >
          {[
            { label: 'Seller cost', value: formatUSD(terms.cost), note: 'fixed' },
            { label: 'Deposit / unit', value: formatUSD(terms.depositPerUnit), note: 'maximum, per buyer' },
            {
              label: 'Sponsor subsidy',
              value: terms.subsidyPerUnit > 0n ? formatUSD(terms.subsidyPerUnit) + '/unit' : 'None (B = 0)',
              note: terms.subsidyPerUnit > 0n ? `reserve ${formatUSD(terms.sponsorReserve)}` : 'unsponsored',
            },
            { label: 'Minimum units', value: String(m), note: `for success` },
            { label: 'Capacity', value: String(K), note: `max seats` },
            { label: 'Deadline', value: terms.deadlineLabel, note: 'immutable' },
          ].map(item => (
            <div
              key={item.label}
              role="listitem"
              style={{ background: '#fff', padding: '0.875rem 1rem' }}
            >
              <div className="cr-label" style={{ marginBottom: '0.2rem' }}>{item.label}</div>
              <div className="cr-mono" style={{ fontWeight: 600, fontSize: '0.9375rem' }}>
                {item.value}
              </div>
              <div style={{ fontSize: '0.7rem', opacity: 0.5, marginTop: '0.1rem' }}>{item.note}</div>
            </div>
          ))}
        </div>

        {/* Sponsor funding status */}
        <div style={{
          marginTop: '1rem',
          padding: '0.75rem 1rem',
          background: sponsorFunded
            ? 'color-mix(in srgb, var(--cr-butter) 22%, var(--cr-cream))'
            : 'color-mix(in srgb, var(--cr-rust) 8%, var(--cr-cream))',
          borderRadius: 6,
          border: '1px solid',
          borderColor: sponsorFunded ? 'color-mix(in srgb, var(--cr-butter) 60%, transparent)' : 'color-mix(in srgb, var(--cr-rust) 30%, transparent)',
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          fontSize: '0.875rem',
        }}>
          <span
            className="cr-dot"
            style={{ background: sponsorFunded ? '#22c55e' : 'var(--cr-rust)', flexShrink: 0 }}
          />
          <span>
            {sponsorFunded
              ? <>Sponsor reserve <strong className="cr-mono">{formatUSD(actualReserve)}</strong> deposited and held.
                  Sponsor subsidy {formatUSD(terms.subsidyPerUnit)}/unit
                  will reduce each buyer's effective charge on success.</>
              : <>Sponsor has <strong>not yet funded</strong> the required reserve of{' '}
                  <strong className="cr-mono">{formatUSD(terms.sponsorReserve)}</strong>.
                  Buyer reservations are blocked until the exact full amount arrives.</>
            }
          </span>
        </div>

        {/* Current funding */}
        {unitCount > 0 && (
          <p style={{ fontSize: '0.8125rem', opacity: 0.6, marginTop: '0.75rem', marginBottom: 0 }}>
            {unitCount} unit{unitCount !== 1 ? 's' : ''} reserved ·{' '}
            <strong className="cr-mono">{formatUSD(BigInt(unitCount) * terms.depositPerUnit)}</strong> buyer deposits
            {sponsorFunded && <> + <strong className="cr-mono">{formatUSD(actualReserve)}</strong> sponsor reserve</>} ={' '}
            <strong className="cr-mono">{formatUSD(totalHeld)}</strong> total held.{' '}
            <span style={{ color: 'var(--cr-rust)', fontWeight: 500 }}>
              These funds are locked until the deadline. No early withdrawal.
            </span>
          </p>
        )}

        <p style={{ fontSize: '0.75rem', opacity: 0.45, marginTop: '0.625rem', marginBottom: 0 }}>
          ⚠ Direct token transfers to the contract create no seats, sponsorship, or claims.
        </p>
      </div>
    </section>
  );
}
