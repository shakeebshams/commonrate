import React, { useMemo } from 'react';
import type { SimState } from '../simulation/types';
import { formatMicro } from '../simulation/math';

interface Props {
  state: SimState;
  compact?: boolean;  // omit heading/section wrapper when true
}

interface Band {
  label: string;
  amount: bigint;
  color: string;
}

function BandRow({ bands, total, label }: { bands: Band[]; total: bigint; label: string }) {
  const nonZero = bands.filter(b => b.amount > 0n);
  if (total === 0n || nonZero.length === 0) {
    return <div className="cr-label" style={{ padding: '0.75rem 0', color: 'var(--cr-muted)' }}>No funds held.</div>;
  }
  return (
    <figure style={{ margin: 0 }} aria-label={label}>
      <div
        style={{ display: 'flex', gap: 2, height: 28, borderRadius: 5, overflow: 'hidden' }}
        role="img"
        aria-hidden="true"
      >
        {nonZero.map(b => {
          const pct = Number((b.amount * 10000n) / total) / 100;
          return (
            <div
              key={b.label}
              className="cr-band"
              style={{ width: `${pct}%`, background: b.color, minWidth: 4 }}
            />
          );
        })}
      </div>
      {/* Accessible exact-text equivalent */}
      <figcaption style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem 1rem', marginTop: '0.5rem' }}>
        {bands.map(b => (
          <span key={b.label} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.875rem' }}>
            <span style={{ width: 9, height: 9, borderRadius: 2, background: b.color, flexShrink: 0, display: 'inline-block' }} aria-hidden="true" />
            <span>{b.label}</span>
            <span className="cr-mono" style={{ fontSize: '0.875rem', color: 'var(--cr-muted)' }}>
              {formatMicro(b.amount)} USDC
            </span>
          </span>
        ))}
      </figcaption>
    </figure>
  );
}

export default function MoneyMap({ state, compact = false }: Props) {
  const { terms, finalizeResult, unitCount, actualReserve, claimed } = state;

  // Historical deposits (locked at point of action, never decreases)
  const historicalBuyerDeposits = BigInt(unitCount) * terms.depositPerUnit;
  const historicalHeld = historicalBuyerDeposits + actualReserve;

  // Current remaining = historical - simulated claimed
  const totalSimClaimed = Object.values(claimed).reduce((a, b) => a + b, 0n);

  const beforeBands: Band[] = [
    { label: 'Buyer deposits (max per unit)',  amount: historicalBuyerDeposits, color: 'var(--cr-sage)' },
    { label: 'Sponsor deposit',                amount: actualReserve,           color: 'var(--cr-butter)' },
  ];

  const afterBands: Band[] = useMemo(() => {
    if (!finalizeResult) return [];
    if (finalizeResult.branch === 'success') {
      const totalBuyerRefund = finalizeResult.seats.reduce((s, seat) => s + seat.refund, 0n);
      return [
        { label: 'Seller allocation',  amount: finalizeResult.sellerCredit,  color: 'var(--cr-forest)' },
        { label: 'Buyer refund allocation',  amount: totalBuyerRefund,             color: 'var(--cr-sage)'   },
        { label: 'Unused sponsor allocation', amount: finalizeResult.sponsorCredit, color: 'var(--cr-butter)' },
      ];
    } else {
      return [
        { label: 'Seller — 0',               amount: 0n,                          color: 'var(--cr-rule)'   },
        { label: 'Buyer deposit allocation', amount: BigInt(finalizeResult.N) * terms.depositPerUnit, color: 'var(--cr-sage)' },
        { label: 'Sponsor deposit allocation',amount: finalizeResult.sponsorCredit, color: 'var(--cr-butter)' },
      ];
    }
  }, [finalizeResult, terms]);

  // Gate checks (only after finalize)
  const gates = finalizeResult ? [
    {
      label: `Minimum units: ${finalizeResult.N} paid units${finalizeResult.N >= Number(terms.minUnits) ? ` ≥ ${String(terms.minUnits)}` : ` < minimum ${String(terms.minUnits)}`}`,
      pass: finalizeResult.gateMinUnits,
    },
    {
      label: `Eligible funding N·(A+B): ${formatMicro(BigInt(finalizeResult.N) * (terms.depositPerUnit + terms.subsidyPerUnit))} USDC${finalizeResult.gateEligibleFunding ? ` ≥ C ${formatMicro(terms.cost)}` : ` < C ${formatMicro(terms.cost)}`}`,
      pass: finalizeResult.gateEligibleFunding,
    },
    {
      label: terms.subsidyPerUnit === 0n
        ? 'Sponsor funded: not required (B = 0)'
        : `Sponsor funded: ${finalizeResult.gateSponsorFunded ? 'yes' : 'no — deadline expired without funding'}`,
      pass: finalizeResult.gateSponsorFunded,
    },
    { label: 'Deadline passed: yes', pass: true },
  ] : null;

  // Conservation equation
  const conservation = useMemo(() => {
    if (!finalizeResult) return null;
    const N = BigInt(finalizeResult.N);
    if (finalizeResult.branch === 'success') {
      return `C + (N·A − C + N·B) + (S − N·B) = N·A + S  →  ${formatMicro(N * terms.depositPerUnit + actualReserve)} USDC ✓`;
    } else {
      return `N·A + S_actual = ${formatMicro(N * terms.depositPerUnit + actualReserve)} USDC refundable ✓`;
    }
  }, [finalizeResult, terms, actualReserve]);

  // Eligible vs held (N=7 explanation)
  const n7note = useMemo(() => {
    if (!finalizeResult || finalizeResult.branch !== 'failure' || finalizeResult.N === 0) return null;
    const N = BigInt(finalizeResult.N);
    const eligible = N * (terms.depositPerUnit + terms.subsidyPerUnit);
    if (eligible < historicalHeld) {
      const gap = terms.cost > eligible ? terms.cost - eligible : 0n;
      return { held: historicalHeld, eligible, gap, minimumFailed: !finalizeResult.gateMinUnits, fundingFailed: !finalizeResult.gateEligibleFunding };
    }
    return null;
  }, [finalizeResult, terms, historicalHeld]);

  const body = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: compact ? '0.875rem' : '1.25rem' }}>

      {/* Settlement gate */}
      {gates && (
        <div className="cr-card" style={{ padding: '0.875rem 1.125rem' }}>
          {!compact && <div className="cr-label" style={{ marginBottom: '0.5rem' }}>Settlement gate</div>}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
            {gates.map(g => (
              <div key={g.label} className="cr-gate-row">
                <span className="cr-dot" style={{ background: g.pass ? '#22c55e' : 'var(--cr-rust)', flexShrink: 0 }} />
                <span style={{ fontSize: '0.8125rem', flex: 1 }}>{g.label}</span>
                <span style={{ fontWeight: 700, fontSize: '0.875rem', color: g.pass ? 'var(--cr-forest)' : 'var(--cr-rust)', flexShrink: 0 }}>
                  {g.pass ? 'PASS' : 'FAIL'}
                </span>
              </div>
            ))}
          </div>

          {/* N=7 held vs eligible note */}
          {n7note && (
            <div style={{
              marginTop: '0.75rem',
              padding: '0.5rem 0.75rem',
              background: 'color-mix(in srgb, var(--cr-butter) 20%, transparent)',
              borderRadius: 4,
              fontSize: '0.8rem',
            }}>
              <strong>Held {formatMicro(n7note.held)} USDC</strong> — but eligible funding{' '}
              N·(A+B) = <strong>{formatMicro(n7note.eligible)} USDC</strong>.
              {n7note.fundingFailed && <> Funding gap = {formatMicro(n7note.gap)} USDC. Reserve for unfilled capacity cannot cover this shortfall.</>}
              {' '}{n7note.minimumFailed && n7note.fundingFailed ? 'Both the minimum and eligible-funding conditions failed.' : n7note.minimumFailed ? 'The minimum was not reached, even though eligible funding covers the cost.' : 'Eligible funding does not cover the cost.'}
            </div>
          )}
        </div>
      )}

      {/* BEFORE band */}
      <div>
        <div className="cr-label" style={{ marginBottom: '0.4rem' }}>
          Recorded deposits · {formatMicro(historicalHeld)} USDC
        </div>
        <BandRow
          bands={beforeBands}
          total={historicalHeld}
          label={`Historical deposits: ${formatMicro(historicalHeld)} USDC total`}
        />
      </div>

      {finalizeResult ? (
        <>
          <div style={{ borderTop: '1px solid var(--cr-rule)', margin: '0.125rem 0' }} />
          {/* AFTER band */}
          <div>
            <div className="cr-label" style={{ marginBottom: '0.4rem' }}>
              Original allocation at settlement ·{' '}
              <span style={{
                fontWeight: 700,
                color: finalizeResult.branch === 'success' ? 'var(--cr-forest)' : 'var(--cr-rust)',
              }}>
                {finalizeResult.branch === 'success' ? 'SUCCESS' : 'FAILURE'}
              </span>
              {' '}· historical credits, not current outstanding balances
            </div>
            <BandRow
              bands={afterBands}
              total={historicalHeld}
              label={`After finalize: ${finalizeResult.branch}`}
            />
          </div>

          {/* Conservation */}
          {conservation && (
            <div style={{
              fontFamily: 'var(--cr-font-mono)',
              fontSize: '0.875rem',
              padding: '0.5rem 0.75rem',
              background: 'var(--cr-mist)',
              borderRadius: 4,
              wordBreak: 'break-all',
            }}>
              {conservation}
            </div>
          )}

          {/* Per-seat table */}
          {!compact && finalizeResult.seats.length > 0 && (
            <details>
              <summary style={{ cursor: 'pointer', fontSize: '0.8125rem', fontWeight: 600, userSelect: 'none', padding: '0.2rem 0' }}>
                Per-seat allocation ({finalizeResult.N} seats)
              </summary>
              <div style={{ overflowX: 'auto', maxWidth: '100%', marginTop: '0.625rem' }} tabIndex={0} role="region" aria-label="Exact seat allocations, scroll horizontally if needed">
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }} aria-label="Per-seat allocation">
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--cr-rule)' }}>
                      {['Seat', 'Owner', 'Gross', 'Charge', 'Original refund allocation'].map(h => (
                        <th key={h} style={{ textAlign: 'left', padding: '0.3rem 0.4rem', fontWeight: 600, whiteSpace: 'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {finalizeResult.seats.map((seat) => {
                      const isClaimed = (claimed[state.seatOwners[seat.index]] ?? 0n) > 0n;
                      return (
                        <tr key={seat.index} style={{ borderBottom: '1px solid color-mix(in srgb, var(--cr-rule) 50%, transparent)', opacity: 1 }}>
                          <td className="cr-mono" style={{ padding: '0.25rem 0.4rem' }}>{seat.index}</td>
                          <td style={{ padding: '0.25rem 0.4rem', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {state.seatOwners[seat.index] ?? '—'}
                          </td>
                          <td className="cr-mono" style={{ padding: '0.25rem 0.4rem' }}>{formatMicro(seat.gross)}</td>
                          <td className="cr-mono" style={{ padding: '0.25rem 0.4rem' }}>{formatMicro(seat.charge)}</td>
                          <td className="cr-mono" style={{ padding: '0.25rem 0.4rem', color: seat.refund > 0n ? 'var(--cr-forest)' : undefined }}>
                            {formatMicro(seat.refund)}{isClaimed ? ' ✓' : ''}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </details>
          )}

          {/* Current held note */}
          {totalSimClaimed > 0n && (
            <p style={{ fontSize: '0.875rem', color: 'var(--cr-muted)', margin: 0 }}>
              Simulation: {formatMicro(totalSimClaimed)} USDC marked claimed; remaining simulated balance = {formatMicro(historicalHeld - totalSimClaimed)} USDC.
              Bands and per-seat values retain the original allocation; receipts show what is still outstanding.
            </p>
          )}
        </>
      ) : (
        <div style={{ color: 'var(--cr-muted)', fontSize: '0.85rem', padding: '0.25rem 0' }}>
          After-finalize bands appear once finalize() is called.
        </div>
      )}
    </div>
  );

  if (compact) return body;

  return (
    <section id="money-map" aria-labelledby="money-map-heading">
      <h2
        id="money-map-heading"
        className="cr-section-title"
        style={{ fontSize: '1.4rem', margin: '0 0 0.25rem' }}
      >
        Where the money goes
      </h2>
      <p style={{ margin: '0 0 1.25rem', fontSize: '0.875rem', color: 'var(--cr-muted)', maxWidth: '58ch' }}>
        Proportional bands show where each USDC lives. Total held ≠ eligible funding:
        the sponsor reserve includes budget for unfilled capacity that cannot earn the cost.
        Credits are claimable after finalize — not automatically transferred.
      </p>
      {body}
    </section>
  );
}
