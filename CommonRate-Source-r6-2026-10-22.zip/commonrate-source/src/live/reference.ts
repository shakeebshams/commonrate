/** Public, untrusted lookup coordinates, never evidence of a verified campaign. */
export type CampaignReference = {
  chain: 5042 | 5042002;
  deploymentHash: `0x${string}`;
};

const MAX_REFERENCE_LENGTH = 256;

function supportedChain(value: unknown): CampaignReference['chain'] {
  if (value === 5042 || value === 5042002) return value;
  throw new Error('Unsupported network. Use chain 5042 (Arc Mainnet) or 5042002 (Arc Testnet).');
}

function normalizedHash(value: unknown): CampaignReference['deploymentHash'] {
  if (typeof value !== 'string' || value.length !== 66 || !/^0x[0-9a-f]{64}$/i.test(value)) {
    throw new Error('Use a deployment transaction hash: 0x followed by exactly 64 hexadecimal characters, not a contract address.');
  }
  return value.toLowerCase() as CampaignReference['deploymentHash'];
}

/**
 * Parse only commonrate:1:<chainId>:<deploymentTransactionHash>.
 * Allows surrounding ASCII spaces, tabs, CR and LF, but no other normalization.
 * The raw input limit includes that whitespace. Nothing is loaded or persisted.
 * Callers must still run the existing network and deployment provenance checks.
 */
export function parseCampaignReference(input: string): CampaignReference {
  if (typeof input !== 'string') throw new Error('Paste a CommonRate reference as text.');
  if (input.length > MAX_REFERENCE_LENGTH) throw new Error('This reference is too long. Use at most 256 characters, including surrounding whitespace.');
  if (/[^\x20-\x7e\t\r\n]/.test(input)) {
    throw new Error('Use plain ASCII reference text. Remove hidden, non-ASCII or control characters.');
  }

  const text = input.replace(/^[ \t\r\n]+|[ \t\r\n]+$/g, '');
  if (!text) throw new Error('Paste a CommonRate reference.');
  if (/[ \t\r\n]/.test(text)) throw new Error('Whitespace is allowed only before or after the complete reference.');
  const parts = text.split(':');
  if (parts.length !== 4 || parts[0] !== 'commonrate') {
    throw new Error('Use commonrate:1:<chainId>:<deploymentTransactionHash>. URLs and extra fields are not supported.');
  }
  if (parts[1] !== '1') throw new Error('Unsupported reference version. Use a commonrate:1 reference.');
  // Exact decimal spelling prevents signs, exponents, hex IDs and leading zeros.
  if (parts[2] !== '5042' && parts[2] !== '5042002') {
    throw new Error('Unsupported network. Use chain 5042 (Arc Mainnet) or 5042002 (Arc Testnet).');
  }
  return {
    chain: parts[2] === '5042' ? 5042 : 5042002,
    deploymentHash: normalizedHash(parts[3]),
  };
}

/** Format lookup coordinates only. This does not verify or trust their target. */
export function formatCampaignReference(reference: CampaignReference): string {
  if (!reference || typeof reference !== 'object') throw new Error('Provide a network and deployment transaction hash.');
  const chain = supportedChain(reference.chain);
  const deploymentHash = normalizedHash(reference.deploymentHash);
  return `commonrate:1:${chain}:${deploymentHash}`;
}
