import { encodeFunctionData, erc20Abi, type Abi, type Address, type EIP1193Provider, type Hex } from 'viem';
import { ActionGuard, assertIdentity, canCheckReceipt, hasUnresolved, isRejected, receiptStatus, type ActionKind, type ActionReceipt } from './actionState';
import { callMatches, replacementLineageMatches, deploymentData, readClient, snapshotFingerprint, verifyCampaign, verifyNetwork, walletClient, type CampaignSnapshot, type NetworkCheck, type Reader, type ReadRoute } from './chain';
import { constructorArgs, errorText, NETWORKS, PILOT, publicAddress, quantity, requireCondition, sameAddress, TOKEN, transactionHash, validateDeadline, type NetworkId, type PilotTerms } from './pilot';
import { ARTIFACT, assertRelease } from './verification';
import { parseCampaignReference, type CampaignReference } from './reference';

export type Review = { action: ActionKind; epoch: number; chain: NetworkId; account: Address; to: Address | null; campaign?: Address; data: Hex; amount: bigint; gas: bigint; nonce: number; quantity: bigint; terms?: PilotTerms; fingerprint?: string; allowance?: bigint; estimate?: { projectedCount: bigint; indices: bigint[]; charge: bigint; refund: bigint }; deploymentHash?: Hex };
export type LiveState = { chain?: NetworkId; route: ReadRoute; account?: Address; network?: NetworkCheck; snapshot?: CampaignSnapshot; review?: Review; receipts: ActionReceipt[]; busy: boolean; error: string; notice: string; storageWarning: string; savedHash: string; embedded: boolean; hasProvider: boolean };
const STORAGE_KEY = 'commonrate.live.public.v1';
type ExpectedCall = Pick<Review, 'account' | 'chain' | 'to' | 'data' | 'nonce' | 'deploymentHash'>;
export function receiptMayRefresh(state: Pick<LiveState, 'chain' | 'account' | 'savedHash'>, record: ActionReceipt, expected?: ExpectedCall) {
  if (!expected || state.chain !== record.chain || !state.account || !sameAddress(state.account, record.account)) return false;
  const hash = record.action === 'deploy' ? record.originalHash ?? record.hash : expected.deploymentHash;
  return !!hash && state.savedHash.toLowerCase() === hash.toLowerCase();
}
type StoragePort = Pick<Storage, 'getItem' | 'setItem'>;
function publicPendingKey(value: unknown): string {
  if (!value || typeof value !== 'object') return JSON.stringify(value);
  const record = value as Record<string, unknown>;
  if (typeof record.referenceId === 'string') return `reference:${record.referenceId}`;
  const call = record.expected as Record<string, unknown> | undefined;
  const normalize = (field: unknown) => typeof field === 'string' ? field.toLowerCase() : field;
  return JSON.stringify([record.chain, normalize(record.account), record.action,
    call ? [call.nonce, normalize(call.to), normalize(call.data)] : [normalize(record.hash), normalize(record.originalHash)]]);
}
export function actionCall(action: Exclude<ActionKind, 'deploy'>, address: Address, amount: bigint, units: bigint): { address: Address; abi: Abi; functionName: string; args: readonly unknown[] } {
  if (action === 'approveSponsor' || action === 'approveReserve') return { address: TOKEN, abi: erc20Abi, functionName: 'approve', args: [address, amount] as readonly unknown[] };
  return { address, abi: ARTIFACT.abi, functionName: ({ fund: 'fundSponsor', reserve: 'reserve', finalize: 'finalize', claim: 'claim' } as const)[action], args: action === 'reserve' ? [units] : [] };
}
export function validateAction(action: Exclude<ActionKind, 'deploy'>, snapshot: CampaignSnapshot, account: Address, units: bigint): bigint {
  const beforeDeadline = snapshot.timestamp < snapshot.terms.deadline;
  if (action === 'approveSponsor' || action === 'fund') {
    requireCondition(sameAddress(account, snapshot.terms.sponsor), 'Only the named sponsor can fund this pilot.');
    requireCondition(!snapshot.sponsorFunded && !snapshot.finalized && beforeDeadline, 'Sponsor funding is unavailable or already complete.');
    if (action === 'fund') requireCondition((snapshot.allowance ?? 0n) >= PILOT.reserve, 'Review the exact sponsor approval first.');
    else requireCondition((snapshot.allowance ?? 0n) < PILOT.reserve, 'Sufficient allowance already exists. Review funding separately.');
    requireCondition((snapshot.balance ?? 0n) > PILOT.reserve, 'Keep additional USDC for gas beyond the 0.03 USDC sponsor reserve.'); return PILOT.reserve;
  }
  if (action === 'approveReserve' || action === 'reserve') {
    requireCondition(snapshot.sponsorFunded && !snapshot.finalized && beforeDeadline, 'Reservations require prefunding and an open deadline.');
    quantity(units, PILOT.capacity - snapshot.unitCount); const amount = units * PILOT.deposit;
    if (action === 'reserve') requireCondition((snapshot.allowance ?? 0n) >= amount, 'Review the exact reservation approval first.');
    else requireCondition((snapshot.allowance ?? 0n) < amount, 'Sufficient allowance already exists. Review reservation separately.');
    requireCondition((snapshot.balance ?? 0n) > amount, 'Keep additional USDC for gas beyond your deposit.'); return amount;
  }
  if (action === 'finalize') { requireCondition(!snapshot.finalized && !beforeDeadline, 'Finalize only at or after the onchain deadline, even when full.'); return 0n; }
  requireCondition(snapshot.finalized && (snapshot.credit ?? 0n) > 0n, 'There is no finalized claimable credit for this wallet.'); return snapshot.credit!;
}
export type LiveDependencies = { readClient: typeof readClient; walletClient: typeof walletClient; verifyCampaign: typeof verifyCampaign; verifyNetwork: typeof verifyNetwork };
const DEFAULT_DEPENDENCIES: LiveDependencies = { readClient, walletClient, verifyCampaign, verifyNetwork };
export class LiveController {
  private guard = new ActionGuard();
  private listeners = new Set<() => void>();
  private sequence = 0;
  private listening = false;
  private disposed = false;
  private unreadableSavedState = false;
  private pendingCalls = new Map<number, ExpectedCall>();
  private publicReferenceIds = new Map<number, string>();
  private state: LiveState;
  constructor(private provider: EIP1193Provider | undefined, embedded: boolean, private storage?: StoragePort, private dependencies: LiveDependencies = DEFAULT_DEPENDENCIES) {
    this.state = { route: 'public', receipts: [], busy: false, error: '', notice: '', storageWarning: '', savedHash: '', embedded, hasProvider: !!provider };
    // Loading public references does not connect, read wallet accounts, or issue RPC calls.
    try {
      const raw = storage?.getItem(STORAGE_KEY); const saved: unknown = raw ? JSON.parse(raw) : null;
      if (saved && typeof saved === 'object') {
        if ('chain' in saved && (saved.chain === 5042 || saved.chain === 5042002)) this.state.chain = saved.chain;
        if ('deploymentHash' in saved && typeof saved.deploymentHash === 'string') this.state.savedHash = transactionHash(saved.deploymentHash);
        if ('pending' in saved && Array.isArray(saved.pending)) {
          for (const entry of saved.pending.slice(0, 20) as unknown[]) {
            if (!entry || typeof entry !== 'object') continue;
            const record = entry as Record<string, unknown>;
            if ((record.chain !== 5042 && record.chain !== 5042002) || typeof record.action !== 'string' || !['deploy', 'approveSponsor', 'fund', 'approveReserve', 'reserve', 'finalize', 'claim'].includes(record.action)) continue;
            const hash = typeof record.hash === 'string' ? transactionHash(record.hash) : undefined;
            const id = ++this.sequence; const account = publicAddress(record.account);
            if (typeof record.referenceId === 'string' && /^[0-9a-f-]{36}$/i.test(record.referenceId)) this.publicReferenceIds.set(id, record.referenceId);
            this.state.receipts.push({ id, chain: record.chain, account, action: record.action as ActionKind, amount: typeof record.amount === 'string' && /^\d+$/.test(record.amount) ? BigInt(record.amount) : 0n, hash, originalHash: typeof record.originalHash === 'string' ? transactionHash(record.originalHash) : hash, status: 'unknown', message: 'Restored public transaction reference. Check its receipt; nothing was reconnected or resubmitted.' });
            if (record.expected && typeof record.expected === 'object') {
              const expected = record.expected as Record<string, unknown>;
              if (typeof expected.data === 'string' && /^0x(?:[0-9a-f]{2})+$/i.test(expected.data) && typeof expected.nonce === 'number' && Number.isSafeInteger(expected.nonce) && expected.nonce >= 0) this.pendingCalls.set(id, { account, chain: record.chain, to: expected.to === null ? null : publicAddress(expected.to), data: expected.data as Hex, nonce: expected.nonce, deploymentHash: typeof expected.deploymentHash === 'string' ? transactionHash(expected.deploymentHash) : undefined });
            }
          }
        }
      }
    } catch { this.unreadableSavedState = true; this.state.storageWarning = 'Saved references could not be read. Wallet transactions are blocked; inspect wallet activity and retain its transaction hashes.'; }
  }
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => { this.disposed = false; this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  private update(partial: Partial<LiveState>) { this.state = { ...this.state, ...partial }; for (const listener of this.listeners) listener(); }
  private storedPending(): unknown[] {
    const raw = this.storage?.getItem(STORAGE_KEY); const saved: unknown = raw ? JSON.parse(raw) : null;
    if (!saved) return [];
    requireCondition(typeof saved === 'object', 'Saved public references are malformed.');
    if (!('pending' in saved)) return [];
    requireCondition(Array.isArray(saved.pending), 'Saved pending references are malformed.'); return saved.pending;
  }
  private requireNoSavedPending() {
    requireCondition(this.storedPending().length === 0, 'A saved request is unresolved, possibly in another window. Close other Live windows, reopen this panel and check its receipt before preparing another action.');
  }
  private persist(): boolean {
    // An unmounted instance must never overwrite a newer instance's public pending
    // references. Its last persisted unresolved record requires explicit recovery.
    if (this.disposed) return false;
    try {
      requireCondition(!this.unreadableSavedState, 'Saved references could not be read safely.');
      requireCondition(this.storage, 'Public transaction storage is unavailable.');
      const publicRecord = (r: ActionReceipt) => ({ referenceId: this.publicReferenceIds.get(r.id), chain: r.chain, account: r.account, action: r.action, amount: r.amount.toString(), hash: r.hash, originalHash: r.originalHash, expected: this.pendingCalls.get(r.id) });
      const owned = new Set(this.state.receipts.map(r => publicPendingKey(publicRecord(r))));
      // Preserve unfamiliar unresolved requests instead of overwriting another window.
      // This is not an atomic cross-tab lock; the pilot still requires one window.
      const foreign = this.storedPending().filter(record => !owned.has(publicPendingKey(record)));
      const pending = this.state.receipts.filter(r => ['pending', 'unknown', 'awaiting-wallet'].includes(r.status)).map(publicRecord);
      const value = JSON.stringify({ chain: this.state.chain, deploymentHash: this.state.savedHash || undefined, pending: [...foreign, ...pending] });
      this.storage.setItem(STORAGE_KEY, value);
      requireCondition(this.storage.getItem(STORAGE_KEY) === value, 'Public transaction storage could not be verified.');
      if (this.state.storageWarning) this.update({ storageWarning: '' });
      return true;
    } catch {
      this.update({ storageWarning: 'Public transaction references could not be saved on this device. New wallet transactions are blocked; read-only checks remain available.' }); return false;
    }
  }
  invalidateReview = () => { this.guard.invalidate(); this.update({ review: undefined }); };
  invalidate = () => { this.guard.invalidate(); this.update({ review: undefined, network: undefined, snapshot: undefined, error: '', notice: '' }); };
  private onWalletChange = () => { this.invalidate(); this.update({ account: undefined, notice: 'Wallet context changed. Connect explicitly and verify again.' }); };
  dispose = () => {
    this.disposed = true; this.guard.invalidate();
    if (this.listening && this.provider?.removeListener) { this.provider.removeListener('accountsChanged', this.onWalletChange); this.provider.removeListener('chainChanged', this.onWalletChange); this.provider.removeListener('disconnect', this.onWalletChange); }
    this.listening = false;
  };
  selectChain = (chain?: NetworkId) => { this.invalidate(); this.update({ chain, account: undefined, savedHash: '', error: '', notice: '' }); this.persist(); };
  selectRoute = (route: ReadRoute) => { this.invalidate(); this.update({ route, error: '' }); };
  importReference = (input: string): CampaignReference | undefined => {
    try {
      requireCondition(!this.state.busy, 'Wait for the current operation before importing a different reference.');
      requireCondition(!this.unreadableSavedState, 'Saved references could not be read safely. Resolve that recovery state before changing context.');
      requireCondition(!hasUnresolved(this.state.receipts), 'Resolve the pending or unknown transaction before importing a different reference.');
      this.requireNoSavedPending();
      const reference = parseCampaignReference(input);
      this.invalidate();
      // Import is an explicit local selection, not a network check. Do not persist
      // unverified coordinates or replace another window's recovery references.
      this.update({ chain: reference.chain, route: 'public', account: undefined, savedHash: '', error: '', notice: 'Reference imported, not verified. No wallet or network request was made. Use Verify to check the deployment and its immutable terms.' });
      return reference;
    } catch (error) {
      this.update({ error: errorText(error) });
      return undefined;
    }
  };
  disconnect = () => { this.onWalletChange(); this.update({ notice: 'Disconnected in this app. Existing wallet permissions are unchanged.' }); };
  private environment() { requireCondition(!this.state.embedded, 'Open the deployed app directly. Wallet actions are disabled inside every embedded frame.'); requireCondition(this.provider, 'No injected wallet is available. Install or open your own wallet to continue.'); requireCondition(this.state.chain, 'Choose a network explicitly.'); return { provider: this.provider, chain: this.state.chain }; }
  private async identity(epoch: number) {
    const { provider, chain } = this.environment(); const account = this.state.account; requireCondition(account, 'Use Connect wallet first.');
    const [accounts, chainHex] = await Promise.all([provider.request({ method: 'eth_accounts' }), provider.request({ method: 'eth_chainId' })]);
    this.guard.assert(epoch); assertIdentity({ account, chain }, accounts, chainHex); return { provider, chain, account };
  }
  private async run(operation: (epoch: number) => Promise<void>) {
    let epoch: number;
    try { epoch = this.guard.begin(); } catch (error) { this.update({ error: errorText(error) }); return; }
    this.update({ busy: true, error: '', notice: '' });
    try { await operation(epoch); } catch (error) { this.update({ review: undefined, network: undefined, snapshot: undefined, error: errorText(error), notice: '' }); }
    finally { this.guard.end(); this.update({ busy: false }); }
  }
  connect = () => this.run(async epoch => {
    const { provider, chain } = this.environment();
    const accounts = await provider.request({ method: 'eth_requestAccounts' });
    this.guard.assert(epoch); requireCondition(accounts.length > 0, 'The wallet returned no account.'); const account = publicAddress(accounts[0]);
    const chainHex = await provider.request({ method: 'eth_chainId' }); this.guard.assert(epoch); assertIdentity({ account, chain }, accounts, chainHex);
    if (!this.listening) { provider.on?.('accountsChanged', this.onWalletChange); provider.on?.('chainChanged', this.onWalletChange); provider.on?.('disconnect', this.onWalletChange); this.listening = true; }
    this.update({ account, notice: 'Connected only after your request. Each transaction needs a separate review and wallet confirmation.' });
  });
  refresh = (hashInput: string) => this.run(async epoch => {
    requireCondition(this.state.chain, 'Choose a network explicitly.');
    if (this.state.route === 'wallet') await this.identity(epoch);
    const reader = this.dependencies.readClient(this.state.chain, this.state.route, this.provider); const network = await this.dependencies.verifyNetwork(reader, this.state.chain); this.guard.assert(epoch);
    if (!hashInput.trim()) { this.update({ network, review: undefined, snapshot: undefined, notice: 'Chain, canonical token code, decimals and chain time were read successfully. No campaign has been verified.' }); return; }
    const hash = transactionHash(hashInput.trim()); const snapshot = await this.dependencies.verifyCampaign(reader, this.state.chain, hash, this.state.account); this.guard.assert(epoch);
    this.update({ network, snapshot, savedHash: hash, review: undefined, notice: 'Code, disclosed terms and direct creation provenance verified at the displayed block. This is not an audit or a delivery guarantee.' }); this.persist();
  });
  private async buildReview(action: ActionKind, units: bigint, terms: PilotTerms | undefined, epoch: number): Promise<Review> {
    assertRelease(); const { chain, account } = await this.identity(epoch); const reader = this.dependencies.readClient(chain, this.state.route, this.provider); const nonce = await reader.getTransactionCount({ address: account, blockTag: 'pending' }); let review: Review;
    if (action === 'deploy') {
      requireCondition(terms, 'Enter the seller, sponsor and an explicit UTC deadline.'); const network = await this.dependencies.verifyNetwork(reader, chain); validateDeadline(terms, network.timestamp, true);
      const data = deploymentData(terms); const gas = await reader.estimateGas({ account, data, value: 0n });
      review = { action, epoch, chain, account, to: null, data, gas, nonce, amount: 0n, quantity: 0n, terms };
      this.guard.assert(epoch); this.update({ network });
    } else {
      const hash = transactionHash(this.state.savedHash); const snapshot = await this.dependencies.verifyCampaign(reader, chain, hash, account); const amount = validateAction(action, snapshot, account, units);
      let estimate: Review['estimate'];
      if (action === 'reserve' || action === 'approveReserve') {
        const projectedCount = snapshot.unitCount + units; const indices = Array.from({ length: Number(units) }, (_, i) => snapshot.unitCount + BigInt(i));
        const refund = await reader.readContract({ address: snapshot.address, abi: ARTIFACT.abi, functionName: 'previewWalletRefundExact', args: [projectedCount, indices], blockNumber: snapshot.block });
        requireCondition(typeof refund === 'bigint' && refund >= 0n && refund <= amount, 'The verified contract returned an invalid reservation quote.');
        estimate = { projectedCount, indices, charge: amount - refund, refund };
      }
      const call = actionCall(action, snapshot.address, amount, units);
      await reader.simulateContract({ ...call, account, value: 0n });
      const data = encodeFunctionData(call); const gas = await reader.estimateGas({ account, to: call.address, data, value: 0n });
      review = { action, epoch, chain, account, to: call.address, campaign: snapshot.address, data, gas, nonce, amount, quantity: units, fingerprint: snapshotFingerprint(snapshot), allowance: snapshot.allowance, estimate, deploymentHash: hash, terms: snapshot.terms };
      this.guard.assert(epoch); this.update({ snapshot, network: snapshot });
    }
    await this.identity(epoch); return review;
  }
  prepare = (action: ActionKind, units = 1n, terms?: PilotTerms) => this.run(async epoch => {
    requireCondition(!hasUnresolved(this.state.receipts), 'Resolve the pending or unknown transaction before preparing another action.');
    this.requireNoSavedPending(); this.update({ review: undefined }); const review = await this.buildReview(action, units, terms, epoch); this.guard.assert(epoch); this.update({ review });
  });
  private record(record: ActionReceipt) { this.update({ receipts: [...this.state.receipts.filter(r => r.id !== record.id), record] }); return this.persist(); }
  confirm = () => this.run(async epoch => {
    const review = this.state.review; requireCondition(review && review.epoch === epoch, 'Prepare a fresh review first.');
    requireCondition(!hasUnresolved(this.state.receipts), 'Resolve the earlier request first.'); this.requireNoSavedPending(); this.update({ review: undefined });
    const fresh = await this.buildReview(review.action, review.quantity, review.terms, epoch);
    requireCondition(fresh.fingerprint === review.fingerprint && fresh.data === review.data && fresh.account === review.account && fresh.chain === review.chain, 'Onchain state or reviewed inputs changed. Review again.');
    const { provider, account, chain } = await this.identity(epoch); this.guard.assert(epoch);
    this.requireNoSavedPending();
    const record: ActionReceipt = { id: ++this.sequence, action: review.action, account, chain, amount: review.amount, status: 'awaiting-wallet', message: 'Awaiting your wallet. No transaction hash has been returned.' };
    this.publicReferenceIds.set(record.id, crypto.randomUUID());
    const submittedReview: ExpectedCall = { account: fresh.account, chain: fresh.chain, to: fresh.to, data: fresh.data, nonce: fresh.nonce, deploymentHash: fresh.deploymentHash }; this.pendingCalls.set(record.id, submittedReview);
    if (!this.record(record)) {
      this.pendingCalls.delete(record.id); this.update({ receipts: this.state.receipts.filter(r => r.id !== record.id) });
      throw new Error('No wallet request was sent: public pending-transaction storage must work before a transaction can be requested.');
    }
    let hash: Hex;
    let dispatched = false; let cancelledBeforeDispatch = false;
    // viem awaits its own chain read after the controller's last identity check.
    // Recheck at the actual submission boundary, with no await before forwarding.
    // Only this local, proven no-dispatch branch may turn a stale context into a
    // cancellation. Once forwarded, a changed context cannot prove non-submission.
    const submissionProvider: EIP1193Provider = {
      on: (event, listener) => provider.on?.(event, listener),
      removeListener: (event, listener) => provider.removeListener?.(event, listener),
      request: async request => {
        if (request.method === 'eth_sendTransaction') {
          if (this.disposed || epoch !== this.guard.capture()) {
            cancelledBeforeDispatch = true;
            throw new Error('Wallet context changed before submission.');
          }
          dispatched = true;
        }
        return provider.request(request as Parameters<EIP1193Provider['request']>[0]);
      },
    };
    try {
      const wallet = this.dependencies.walletClient(chain, account, submissionProvider);
      hash = review.action === 'deploy'
        ? await wallet.deployContract({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs(review.terms!), account, chain: NETWORKS[chain], value: 0n, gas: fresh.gas, nonce: fresh.nonce })
        : await wallet.writeContract({ ...actionCall(review.action, this.state.snapshot!.address, review.amount, review.quantity), account, chain: NETWORKS[chain], value: 0n, gas: fresh.gas, nonce: fresh.nonce });
      hash = transactionHash(hash);
    } catch (error) {
      const cancelled = cancelledBeforeDispatch && !dispatched;
      const rejected = !cancelled && isRejected(error);
      this.record({ ...record, status: cancelled ? 'cancelled' : rejected ? 'rejected' : 'unknown', message: cancelled ? 'Cancelled before submission because the wallet context changed. No wallet transaction request was sent. A new action needs a fresh review.' : rejected ? 'You rejected the wallet request. Nothing is assumed submitted.' : `Wallet outcome is unknown. Check wallet history before doing anything else. ${errorText(error)}` }); return;
    }
    const submitted = { ...record, hash, originalHash: hash, status: 'pending' as const, message: 'Submitted. A hash is not proof of confirmation.' }; this.record(submitted);
    if (review.action === 'deploy' && epoch === this.guard.capture()) { this.update({ savedHash: hash }); this.persist(); }
    await this.watchReceipt(submitted, this.dependencies.readClient(chain, this.state.route, provider), epoch, submittedReview);
  });
  private async watchReceipt(record: ActionReceipt, reader: Reader, epoch: number, review?: ExpectedCall) {
    requireCondition(record.hash, 'No hash is available. Inspect the wallet history; do not repeat the transaction.');
    let replacement: { reason: 'repriced' | 'replaced' | 'cancelled'; callMatches: boolean; lineageMatches: boolean } | undefined;
    let current = record;
    try {
      const receipt = await reader.waitForTransactionReceipt({ hash: record.hash, confirmations: 1, timeout: 90000, retryCount: 0,
        onReplaced: change => {
          replacement = { reason: change.reason, callMatches: !!review && callMatches(change.transaction, review), lineageMatches: !!review && replacementLineageMatches(change.replacedTransaction, change.transaction, review) };
          current = { ...current, hash: change.transaction.hash, originalHash: record.originalHash ?? record.hash, message: `Wallet transaction ${change.reason}. Checking the replacement receipt.` }; this.record(current);
        },
      });
      requireCondition(receipt.transactionHash.toLowerCase() === current.hash?.toLowerCase(), 'The receipt hash does not match the submitted or observed replacement hash.');
      let status = receiptStatus(receipt.status, replacement);
      if (review && !replacement) { const tx = await reader.getTransaction({ hash: receipt.transactionHash }); if (!callMatches(tx, review)) status = 'unknown'; }
      if (!review) status = 'unknown';
      this.record({ ...current, hash: receipt.transactionHash, status, message: status === 'confirmed' ? 'Receipt status: success. This does not guarantee chain finality or delivery.' : `Receipt outcome: ${status}. The original action is not treated as successful.` });
      if (status === 'confirmed' && epoch === this.guard.capture() && receiptMayRefresh(this.state, record, review)) {
        if (record.action === 'deploy') { this.update({ savedHash: receipt.transactionHash }); this.persist(); }
        if (this.state.savedHash) {
          try { const snapshot = await this.dependencies.verifyCampaign(reader, record.chain, transactionHash(this.state.savedHash), this.state.account); this.guard.assert(epoch); this.update({ snapshot, network: snapshot }); }
          catch (error) { this.update({ snapshot: undefined, network: undefined, error: `The receipt was successful, but fresh verification failed: ${errorText(error)}` }); }
        }
      }
    } catch (error) { this.record({ ...current, status: 'unknown', message: `Confirmation is unknown or timed out. Use Check receipt, never automatic retry. ${errorText(error)}` }); }
  }
  attachHash = (id: number, input: string) => {
    try {
      requireCondition(!this.state.busy, 'Wait for the current request to finish.');
      const record = this.state.receipts.find(r => r.id === id); requireCondition(record?.status === 'unknown', 'Only unknown receipts accept a recovery hash.');
      requireCondition(this.pendingCalls.has(id), 'The expected transaction details are unavailable. Resolve this request outside the app; it cannot be safely matched.');
      const hash = transactionHash(input.trim()); this.record({ ...record, hash, originalHash: record.originalHash ?? hash, message: 'Hash attached from your wallet history. Check receipt to match account, chain, nonce, target, value and calldata. Nothing was resubmitted.' });
    } catch (error) { this.update({ error: errorText(error) }); }
  };
  checkReceipt = (id: number) => this.run(async epoch => {
    const record = this.state.receipts.find(r => r.id === id); requireCondition(record?.hash, 'No transaction hash was returned. Inspect the wallet history before continuing.');
    if (!canCheckReceipt(record)) { this.update({ notice: 'This request already has a verified cancellation or replacement outcome. Its history is retained; use the explorer link to inspect that transaction.' }); return; }
    // Explicit receipt checks work without reconnecting, using this receipt's original chain.
    const useWallet = this.state.route === 'wallet' && this.state.chain === record.chain;
    if (useWallet) await this.identity(epoch);
    await this.watchReceipt(record, this.dependencies.readClient(record.chain, useWallet ? 'wallet' : 'public', this.provider), epoch, this.pendingCalls.get(id));
  });
}
