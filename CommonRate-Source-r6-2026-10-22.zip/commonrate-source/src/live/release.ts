// Exact Studio export14, independently rebuilt with solc 0.8.28, Paris, via IR,
// optimizer 200. These hashes are source/build identity, not an audit certificate.
export const RELEASE_SOURCE_SHA256 = '2bf92c6640fb9c5c8e974b4f75599ccf15a6faa56cdad095f0404f07e5ee6489';
export const RELEASE_CREATION_KECCAK256 = '0xbf1d0a281ffb62535abb0b3d53340624ab3865551a934c09274fe0572c56edea';
export const RELEASE_RUNTIME_KECCAK256 = '0xb688207f62d488565c4e7518373149a7558f76b859275aca0aaf118feed62894';
// keccak256(UTF8(JSON.stringify(JSON.parse(exact artifact file)))) also pins ABI,
// immutable ranges, compiler/settings and metadata. Whitespace is insignificant.
export const RELEASE_ARTIFACT_JSON_KECCAK256 = '0xb8c1dc8a6b84a6bfb359c39e36e835c60b93eae5483e235775df607e68126d29';
