import type { Address, Hex } from 'viem';
import { requireCondition, sameAddress, type NetworkId } from './pilot';

export type ActionKind = 'deploy' | 'approveSponsor' | 'fund' | 'approveReserve' | 'reserve' | 'finalize' | 'claim';
export type ReceiptStatus = 'awaiting-wallet' | 'rejected' | 'pending' | 'confirmed' | 'reverted' | 'replaced' | 'cancelled' | 'unknown';
export type ActionReceipt = { id: number; action: ActionKind; chain: NetworkId; account: Address; amount: bigint; status: ReceiptStatus; hash?: Hex; originalHash?: Hex; message: string };
export type Identity = { chain: NetworkId; account: Address };
export class ActionGuard {
  epoch = 0;
  private locked = false;
  invalidate() { this.epoch++; }
  capture() { return this.epoch; }
  assert(epoch: number) { requireCondition(epoch === this.epoch, 'The wallet, network or reviewed inputs changed. Review again.'); }
  begin() { requireCondition(!this.locked, 'Another request is still in progress. Do not submit twice.'); this.locked = true; return this.epoch; }
  end() { this.locked = false; }
}
export function assertIdentity(expected: Identity, accounts: unknown, chainHex: unknown) {
  requireCondition(Array.isArray(accounts) && typeof accounts[0] === 'string' && sameAddress(accounts[0], expected.account), 'Connected account changed. Connect and review again.');
  requireCondition(typeof chainHex === 'string' && /^0x[0-9a-f]+$/i.test(chainHex) && BigInt(chainHex) === BigInt(expected.chain), 'Wallet network changed. Select the expected network in your wallet and review again.');
}
export function isRejected(error: unknown): boolean {
  let candidate: unknown = error;
  for (let i = 0; i < 8 && candidate && typeof candidate === 'object'; i++) {
    if ('code' in candidate && candidate.code === 4001) return true;
    candidate = 'cause' in candidate ? candidate.cause : undefined;
  }
  return false;
}
export function receiptStatus(status: 'success' | 'reverted', replacement?: { reason: 'repriced' | 'replaced' | 'cancelled'; callMatches: boolean; lineageMatches: boolean }): ReceiptStatus {
  if (status !== 'success' && status !== 'reverted') return 'unknown';
  if (replacement && !replacement.lineageMatches) return 'unknown';
  if (replacement?.reason === 'cancelled') return 'cancelled';
  if (replacement && (replacement.reason !== 'repriced' || !replacement.callMatches)) return 'replaced';
  return status === 'success' ? 'confirmed' : 'reverted';
}
export function hasUnresolved(receipts: ActionReceipt[]) { return receipts.some(r => ['awaiting-wallet', 'pending', 'unknown'].includes(r.status)); }

// Terminal replacement hashes identify a different call. Rechecking them as the
// original action would discard the already verified replacement lineage.
export function canCheckReceipt(receipt: Pick<ActionReceipt, 'status' | 'hash'>) { return !!receipt.hash && receipt.status !== 'cancelled' && receipt.status !== 'replaced'; }
