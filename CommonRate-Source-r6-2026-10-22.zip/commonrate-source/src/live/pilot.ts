import { defineChain, getAddress, isAddress, keccak256, stringToHex, type Address, type Hex } from 'viem';

export const TOKEN = '0x3600000000000000000000000000000000000000' as const;
export const PILOT = Object.freeze({ cost: 120000n, deposit: 60000n, subsidy: 10000n, minimum: 2n, capacity: 3n, reserve: 30000n });
export const PILOT_TITLE = 'CommonRate controlled-wallet pilot';
export const PILOT_DESCRIPTION = 'A tiny experimental allocation test using controlled wallets. Not a workshop, delivery sale, investment, or audited financial product.';
export const PILOT_TERMS = 'CommonRate controlled-wallet pilot. Seller cost: 0.12 USDC. Buyer deposit: 0.06 USDC per unit. Sponsor subsidy: 0.01 USDC per unit. Minimum: 2 units. Capacity: 3 units. Sponsor prefund: 0.03 USDC. Finalization and claims only at or after the disclosed UTC deadline; no pre-deadline cancellation. At 2 units: seller allocation 0.12 USDC, total buyer refunds 0.02 USDC, unused sponsor allocation 0.01 USDC. This is an unaudited experimental controlled-wallet test, not a real sale. Allocation does not guarantee delivery or withdrawal. Network, contract, wallet, and USDC issuer freeze or proxy-upgrade risks remain. Native gas and ERC-20 balances are two decimal views of the same USDC; retain additional USDC for gas.';
export const TERMS_HASH = keccak256(stringToHex(PILOT_TERMS));
export const NETWORKS = {
  5042: defineChain({ id: 5042, name: 'Arc Mainnet · REAL USDC', nativeCurrency: { name: 'USDC', symbol: 'USDC', decimals: 18 }, rpcUrls: { default: { http: ['https://rpc.mainnet.arc.io'] } }, blockExplorers: { default: { name: 'Arc explorer', url: 'https://explorer.arc.io' } } }),
  5042002: defineChain({ id: 5042002, name: 'Arc Testnet · test USDC', nativeCurrency: { name: 'USDC', symbol: 'USDC', decimals: 18 }, rpcUrls: { default: { http: ['https://rpc.testnet.arc.io'] } }, blockExplorers: { default: { name: 'Arc testnet explorer', url: 'https://explorer.testnet.arc.io' } } }),
} as const;
export type NetworkId = keyof typeof NETWORKS;
export const MAX_SUPPORTED_DEADLINE = 253402300799n; // 9999-12-31T23:59:59Z, matching the explicit four-digit UTC input.
export type PilotTerms = { seller: Address; sponsor: Address; deadline: bigint };
export function requireCondition(value: unknown, message: string): asserts value { if (!value) throw new Error(message); }
export function publicAddress(value: unknown): Address {
  requireCondition(typeof value === 'string' && isAddress(value, { strict: true }) && !/^0x0{40}$/i.test(value), 'Enter a valid, nonzero public address.');
  return getAddress(value);
}
export function transactionHash(value: string): Hex {
  requireCondition(/^0x[0-9a-fA-F]{64}$/.test(value), 'Enter the deployment transaction hash, not a contract address.');
  return value.toLowerCase() as Hex;
}
export function sameAddress(a: string, b: string) { return a.toLowerCase() === b.toLowerCase(); }
export function usdc(value: bigint) {
  const negative = value < 0n; const n = negative ? -value : value;
  return `${negative ? '-' : ''}${n / 1000000n}.${(n % 1000000n).toString().padStart(6, '0')}`;
}
export function deadlineFromUTC(value: string) {
  requireCondition(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?Z$/.test(value), 'Enter an explicit UTC deadline, for example 2026-11-01T12:30:00Z.');
  const ms = Date.parse(value); requireCondition(Number.isFinite(ms), 'Invalid UTC deadline.');
  const canonical = value.length === 17 ? value.replace('Z', ':00Z') : value;
  requireCondition(new Date(ms).toISOString().replace('.000Z', 'Z') === canonical, 'Invalid UTC calendar date or time; no automatic normalization is allowed.');
  return BigInt(Math.floor(ms / 1000));
}
export function validateDeadline(terms: PilotTerms, now: bigint, review = false) {
  publicAddress(terms.seller); publicAddress(terms.sponsor);
  requireCondition(terms.deadline <= MAX_SUPPORTED_DEADLINE, 'This deployment deadline is outside the supported UTC range.');
  requireCondition(terms.deadline > now && (!review || terms.deadline >= now + 600n), review ? 'Choose a deadline at least 10 minutes beyond the current chain time.' : 'Deployment deadline must follow its block timestamp.');
}
export function constructorArgs(terms: PilotTerms) {
  return [TOKEN, terms.seller, terms.sponsor, PILOT.cost, PILOT.deposit, PILOT.subsidy, PILOT.capacity, PILOT.minimum, terms.deadline, PILOT_TITLE, PILOT_DESCRIPTION, TERMS_HASH] as const;
}
export function quantity(value: string | bigint, remaining: bigint = PILOT.capacity): bigint {
  requireCondition(typeof value === 'bigint' || /^[1-3]$/.test(value), 'Choose an integer quantity from 1 to 3.');
  const n = BigInt(value); requireCondition(n >= 1n && n <= remaining && n <= PILOT.capacity, 'Quantity exceeds the remaining capacity.'); return n;
}
export function inFrame(target: Pick<Window, 'top' | 'self'> | undefined) {
  if (!target) return true;
  try { return target.top !== target.self; } catch { return true; }
}
export function errorText(error: unknown) { return error instanceof Error ? error.message : 'The request failed. No success has been assumed.'; }

export function campaignStateLabel(state: { finalized: boolean; succeeded: boolean; unitCount: bigint; timestamp: bigint; terms: PilotTerms; sponsorFunded: boolean }) {
  if (state.finalized) return state.succeeded ? 'Finalized: minimum met' : state.unitCount === 0n ? 'Finalized: no reservations' : 'Finalized: minimum not met';
  if (state.timestamp >= state.terms.deadline) return 'Deadline reached; awaiting finalization';
  if (!state.sponsorFunded) return 'Awaiting sponsor funding';
  if (state.unitCount === PILOT.capacity) return 'Full; awaiting deadline';
  return 'Open until deadline';
}
