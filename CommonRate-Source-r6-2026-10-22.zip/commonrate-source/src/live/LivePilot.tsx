import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import type { Address, EIP1193Provider } from 'viem';
import { canCheckReceipt, hasUnresolved, type ActionKind } from './actionState';
import { LiveController, type Review } from './controller';
import { campaignStateLabel, deadlineFromUTC, errorText, MAX_SUPPORTED_DEADLINE, inFrame, NETWORKS, PILOT, PILOT_DESCRIPTION, PILOT_TERMS, PILOT_TITLE, publicAddress, TERMS_HASH, TOKEN, transactionHash, usdc, type NetworkId } from './pilot';
import { ARTIFACT, assertRelease } from './verification';
import { formatCampaignReference } from './reference';
import { ReferenceExport, ReferenceImport } from './PilotReference';
import './live.css';

const LABELS: Record<ActionKind, string> = { deploy: 'Deploy tiny pilot', approveSponsor: 'Approve sponsor reserve', fund: 'Fund sponsor reserve', approveReserve: 'Approve reservation', reserve: 'Reserve units', finalize: 'Finalize allocations', claim: 'Claim wallet credit' };
function browserController() {
  if (typeof window === 'undefined') return new LiveController(undefined, true);
  let storage: Storage | undefined; try { storage = window.localStorage; } catch { /* Read-only mode remains available; transactions require verified persistence. */ }
  const provider = (window as unknown as { ethereum?: EIP1193Provider }).ethereum;
  return new LiveController(provider, inFrame(window), storage);
}
function utc(timestamp: bigint) { return timestamp >= 0n && timestamp <= MAX_SUPPORTED_DEADLINE ? new Date(Number(timestamp) * 1000).toISOString().replace('.000Z', ' UTC') : `${timestamp} seconds since Unix epoch (outside display range)`; }
function Row({ label, children }: { label: string; children: React.ReactNode }) { return <div><dt>{label}</dt><dd>{children}</dd></div>; }
export function CampaignAddress({ address }: { address: Address }) {
  return <span><span>{address}</span><small className="cr-live-address-warning">Do not send USDC directly to this campaign/spender address. Direct transfers do not create seats or refundable credits.</small></span>;
}
export function deploymentDraftMatches(draft: string, verifiedHash: string) {
  try { return transactionHash(draft.trim()) === transactionHash(verifiedHash); }
  catch { return false; }
}
export function deadlineFromLastCheck(check: { chain: NetworkId; timestamp: bigint } | undefined, selectedChain?: NetworkId) {
  if (!check || check.chain !== selectedChain || typeof check.timestamp !== 'bigint' || check.timestamp < 0n || check.timestamp > MAX_SUPPORTED_DEADLINE - 1800n) return undefined;
  return new Date(Number(check.timestamp + 1800n) * 1000).toISOString().replace('.000Z', 'Z');
}
function ReviewSheet({ review }: { review: Review }) {
  return <>
    <h3>{LABELS[review.action]}</h3>
    <dl className="cr-live-facts">
      <Row label="Network">{NETWORKS[review.chain].name} · {review.chain}</Row>
      <Row label="Signing account">{review.account}</Row>
      <Row label="Contract / target">{review.campaign && review.to === review.campaign ? <CampaignAddress address={review.campaign} /> : review.to ?? 'New contract creation (no existing target)'}</Row>
      <Row label="Canonical token">{TOKEN}</Row>
      <Row label="Function">{review.action === 'deploy' ? 'constructor(token, seller, sponsor, C, A, B, K, m, deadline, title, description, termsHash)' : review.action.startsWith('approve') ? 'approve(campaign, exact amount)' : review.action === 'fund' ? 'fundSponsor()' : review.action === 'reserve' ? `reserve(${review.quantity})` : `${review.action}()`}</Row>
      {review.action !== 'deploy' && <Row label={review.action.startsWith('approve') ? 'Exact approval' : review.action === 'claim' ? 'Claim to this account' : 'USDC transferred'}>{usdc(review.amount)} USDC</Row>}
      {review.action.startsWith('approve') && <Row label="Spender">{review.campaign && <CampaignAddress address={review.campaign} />}</Row>}
      {(review.action === 'reserve' || review.action === 'approveReserve') && <Row label="Units">{review.quantity.toString()} × 0.060000 USDC</Row>}
      {review.estimate && <><Row label="Projected total after reservation">{review.estimate.projectedCount.toString()} units</Row><Row label="New seat numbers">{review.estimate.indices.map(index => (index + 1n).toString()).join(', ')}</Row><Row label="Estimated charge for these new seats">{usdc(review.estimate.charge)} USDC</Row><Row label="Estimated refund for these new seats">{usdc(review.estimate.refund)} USDC</Row></>}
      {review.allowance !== undefined && <Row label="Current allowance">{usdc(review.allowance)} USDC</Row>}
      <Row label="Native transaction value">0 USDC (gas is additional)</Row>
      <Row label="Estimated gas units">{review.gas.toString()} · wallet shows final fee</Row>
      {review.terms && <><Row label="Seller">{review.terms.seller}</Row><Row label="Sponsor">{review.terms.sponsor}</Row><Row label="Immutable deadline">{utc(review.terms.deadline)}</Row></>}
    </dl>
    {review.estimate && <p className="cr-note">The verified contract quoted these exact new seat indices at the projected count. This is conditional on that being the final count, successful finalization and token transfer availability, not a guaranteed withdrawal. Other reservations can change the outcome.</p>}
    <p className="cr-note">{review.action === 'finalize' ? 'Finalization records allocations only. It sends no tokens; each wallet must claim separately.' : review.action.startsWith('approve') ? 'This grants an exact allowance. It does not fund or reserve anything. Review the separate transfer afterward.' : review.action === 'claim' ? 'All roles for this wallet are aggregated and paid only to the same caller.' : 'Nothing else will be submitted automatically after this transaction.'}</p>
  </>;
}
export default function LivePilot() {
  const [controller] = useState(browserController);
  const [deployOpen, setDeployOpen] = useState(false);
  const [activity, setActivity] = useState<'check' | 'connect' | 'deploy' | 'campaign' | 'history'>('check');
  const [operation, setOperation] = useState('');
  const feedbackRef = useRef<HTMLDivElement>(null);
  const reviewHeading = useRef<HTMLHeadingElement>(null);
  const reviewOpener = useRef<HTMLElement | null>(null);
  const verifyButton = useRef<HTMLButtonElement>(null);
  const state = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
  const [seller, setSeller] = useState(''); const [sponsor, setSponsor] = useState(''); const [deadline, setDeadline] = useState('');
  const [recovery, setRecovery] = useState<Record<number, string>>({});
  const [hash, setHash] = useState(state.savedHash); const [units, setUnits] = useState('1'); const [accepted, setAccepted] = useState(false); const [formError, setFormError] = useState('');
  const [observedSavedHash, setObservedSavedHash] = useState(state.savedHash);
  // Follow a newly authoritative deployment hash, not unrelated controller updates.
  // An empty savedHash deliberately leaves an imported, unverified draft intact.
  if (state.savedHash !== observedSavedHash) {
    setObservedSavedHash(state.savedHash);
    if (state.savedHash) setHash(state.savedHash);
  }
  useEffect(() => () => controller.dispose(), [controller]);
  useEffect(() => { if (state.error || formError || state.storageWarning) feedbackRef.current?.focus(); }, [state.error, formError, state.storageWarning]);
  useEffect(() => { if (state.review) reviewHeading.current?.focus(); }, [state.review]);
  let releaseError = ''; try { assertRelease(); } catch (error) { releaseError = errorText(error); }
  const walletBlocked = state.embedded || !state.hasProvider || !state.account || !state.chain || state.busy || hasUnresolved(state.receipts) || !!releaseError;
  const snapshot = state.snapshot;
  const draftMismatch = !!snapshot && !deploymentDraftMatches(hash, snapshot.deploymentHash);
  const campaignBlocked = walletBlocked || !snapshot || draftMismatch;
  const changed = () => { setAccepted(false); setFormError(''); controller.invalidateReview(); };
  const prepare = (action: ActionKind) => {
    reviewOpener.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setActivity(action === 'deploy' ? 'deploy' : 'campaign');
    setOperation('Checking this action’s exact terms and current state. No transaction has been submitted.');
    setAccepted(false); setFormError('');
    if (action !== 'deploy') { void controller.prepare(action, BigInt(units)); return; }
    try { void controller.prepare('deploy', 0n, { seller: publicAddress(seller), sponsor: publicAddress(sponsor), deadline: deadlineFromUTC(deadline) }); }
    catch (error) { setFormError(errorText(error)); }
  };
  const feedbackLocation = (activity === 'campaign' && !snapshot) || (activity === 'deploy' && !deployOpen) || (activity === 'history' && !state.receipts.length) ? 'check' : activity;
  const feedback = (where: typeof activity) => feedbackLocation === where && (state.error || formError || state.notice || state.storageWarning || state.busy) ? <div ref={feedbackRef} className="cr-live-feedback" tabIndex={-1}>
    {(state.error || formError) && <p className="cr-live-error" role="alert">{formError || state.error}</p>}
    {state.storageWarning && <p className="cr-note" role="status">{state.storageWarning}</p>}
    {state.busy ? <p className="cr-note" role="status">{operation || 'Checking the requested operation. Do not submit again.'}</p> : !state.error && !formError && state.notice && <p className="cr-note" role="status">{state.notice}</p>}
  </div> : null;
  const unresolved = hasUnresolved(state.receipts);
  const checkedDeadline = deadlineFromLastCheck(state.network, state.chain);
  const importBlocked = state.busy ? 'Wait for the current operation before importing another reference.' : unresolved ? 'Resolve the pending or unknown transaction before changing the pilot reference.' : '';
  const reviewPanel = (where: typeof activity) => state.review && activity === where ? <section className="cr-live-review" aria-labelledby="live-review-title">
    <h2 id="live-review-title" ref={reviewHeading} tabIndex={-1}>Review this one action</h2><ReviewSheet review={state.review} />
    <p className="cr-note">Read the immutable terms. At two units: seller 0.120000 USDC, buyer refunds 0.020000 USDC total, sponsor unused 0.010000 USDC. Gas is additional; no cancellation before deadline.</p>
    <label className="cr-live-check"><input type="checkbox" checked={accepted} onChange={event => setAccepted(event.target.checked)} />I reviewed the exact network, addresses, amounts, immutable terms and experimental risks for this action.</label>
    <div className="cr-live-buttons"><button className="cr-btn cr-btn-primary" disabled={!accepted || state.busy || state.embedded || (state.review.action !== 'deploy' && draftMismatch)} onClick={() => { setAccepted(false); setOperation('Follow the request in your wallet. Do not submit again while its outcome is unresolved.'); void controller.confirm(); window.requestAnimationFrame(() => feedbackRef.current?.focus()); }}>Confirm in wallet</button><button className="cr-btn" disabled={state.busy} onClick={() => { changed(); window.requestAnimationFrame(() => reviewOpener.current?.focus()); }}>Cancel review</button></div>
  </section> : null;
  return <section className="cr-live" aria-labelledby="live-title">
    <p className="cr-eyebrow">Experimental and unaudited · controlled wallets only</p>
    <h1 id="live-title">Check a tiny pilot.</h1>
    <div className="cr-live-warning">
      <p>Not a production checkout. <strong>{state.chain === 5042 ? 'Mainnet uses REAL USDC.' : 'Mainnet uses real USDC; testnet uses test tokens.'}</strong> Funds stay locked until the deadline. Withdrawal can fail. Delivery is not guaranteed.</p>
      <p><strong>Use a single app window.</strong> Resolve any pending or unknown outcome before another submission.</p>
    </div>
    {state.embedded && <p className="cr-live-warning" role="status"><strong>Open the deployed app directly.</strong> Wallet connection and all wallet actions are disabled inside every embedded frame. Sandbox remains usable here.</p>}

    {releaseError && <p className="cr-live-warning" role="status">{releaseError}</p>}
    <section className="cr-live-section cr-live-check-section" aria-labelledby="live-connect-title">
      <h2 id="live-connect-title">Check a network or existing pilot</h2>
      <p className="cr-note">Read-only. No new account permission or transaction is requested.</p>
      <div className="cr-live-read-fields">
        <label className="cr-live-field">Network<select value={state.chain ?? ''} disabled={state.busy || unresolved} onChange={event => { setAccepted(false); setHash(''); setActivity('check'); controller.selectChain(event.target.value ? Number(event.target.value) as NetworkId : undefined); }}><option value="">Choose a network</option><option value="5042002">Arc Testnet · test USDC · 5042002</option><option value="5042">Arc Mainnet · REAL USDC · 5042</option></select></label>
        <label className="cr-live-field">Read transport<select value={state.route} disabled={state.busy} onChange={event => { setAccepted(false); setActivity('check'); controller.selectRoute(event.target.value as 'public' | 'wallet'); }}><option value="public">Public Arc RPC</option><option value="wallet" disabled={!state.account || state.embedded}>Connected wallet RPC (explicit fallback)</option></select></label>
      </div>
      {unresolved && <p className="cr-note">The selected network stays in place until the pending or unknown action is resolved.</p>}
      <label className="cr-live-field">Deployment transaction hash (optional for network-only check)<input autoComplete="off" spellCheck={false} maxLength={66} value={hash} placeholder="0x… transaction hash, not an address" disabled={state.busy || unresolved} onChange={event => { setHash(event.target.value); changed(); controller.invalidate(); }} /></label>
      <button ref={verifyButton} className="cr-btn cr-btn-primary" disabled={!state.chain || state.busy} onClick={() => { setAccepted(false); setActivity('check'); setOperation('Verifying the requested network and deployment. No wallet transaction is being requested.'); void controller.refresh(hash); }}>Verify / refresh reads</button>
      {!state.chain && <p className="cr-note cr-live-disabled-reason">Choose a network or import a reference to enable verification.</p>}
      {state.network && <p className="cr-note">Network and canonical six-decimal token checked at block {state.network.block.toString()}. Chain time: {utc(state.network.timestamp)}.</p>}
    {!state.hasProvider && <p className="cr-note">No injected wallet detected. Public network and deployment checks remain available. No account access has been requested.</p>}
      {feedback('check')}
      <ReferenceImport blockedReason={importBlocked} onImport={value => { setActivity('check'); changed(); const reference = controller.importReference(value); if (reference) { setHash(reference.deploymentHash); window.requestAnimationFrame(() => verifyButton.current?.focus()); } }} />
    </section>
    <details className="cr-disclosure cr-live-limits"><summary>Pilot limits and withdrawal risks</summary>
      <p className="cr-note">USDC issuer freezes, proxy upgrades, network failures and contract risks can prevent withdrawal. No pre-deadline cancellation or delivery protection. Each action needs its own review and wallet confirmation.</p>
      <p className="cr-note">Concurrent tabs are unsupported and can lose pending-action protection. Do not open another Live window while an outcome is unresolved. Local storage checks are not an atomic cross-tab lock.</p>
      <p className="cr-note">Two units plus sponsor reserve lock 0.150000 USDC; all three lock 0.210000 USDC, plus gas. The 18-decimal native gas balance and 6-decimal ERC-20 balance are the same USDC. Never add them together; retain extra USDC for gas.</p>
    </details>
    <section className="cr-live-section" aria-labelledby="live-wallet-title">
      <h2 id="live-wallet-title">Connect only when you want to act</h2>
      <p className="cr-note">No automatic connection, account query, network switch or signature. If needed, change the network in your wallet yourself.</p>
      <div className="cr-live-buttons"><button className="cr-btn" disabled={state.embedded || !state.hasProvider || !state.chain || state.busy || !!state.account} onClick={() => { setActivity('connect'); setOperation('Waiting for wallet account permission. No transaction is being requested.'); void controller.connect(); }}>Connect wallet</button>{state.account && <button className="cr-btn" onClick={controller.disconnect}>Disconnect here</button>}</div>
      {state.account ? <p className="cr-live-address">Connected account: {state.account}</p> : <p className="cr-note">{state.embedded ? 'Wallet connection is disabled in an embedded frame.' : !state.hasProvider ? 'An injected wallet is required to connect. Read-only public checks still work.' : !state.chain ? 'Choose the intended network first.' : 'Connecting reveals the selected public account; it does not submit a transaction.'}</p>}
      {feedback('connect')}
    </section>
    <details className="cr-disclosure cr-live-deploy" open={deployOpen} onToggle={event => setDeployOpen(event.currentTarget.open)}>
      <summary>Deploy a new fixed pilot</summary>
      <section className="cr-live-section" aria-labelledby="live-deploy-title">
        <h2 id="live-deploy-title">Create a separate tiny round</h2>
        <dl className="cr-live-facts"><Row label="Seller cost">0.120000 USDC</Row><Row label="Deposit / unit">0.060000 USDC</Row><Row label="Subsidy / unit">0.010000 USDC</Row><Row label="Minimum / capacity">2 / 3 units</Row><Row label="Sponsor prefund">0.030000 USDC</Row></dl>
        <label className="cr-live-field">Seller public address<input autoComplete="off" spellCheck={false} value={seller} disabled={state.busy} onChange={event => { setSeller(event.target.value); changed(); }} /></label>
        <label className="cr-live-field">Sponsor public address<input autoComplete="off" spellCheck={false} value={sponsor} disabled={state.busy} onChange={event => { setSponsor(event.target.value); changed(); }} /></label>
        <button className="cr-btn" disabled={!state.account || state.busy || state.embedded} onClick={() => { if (state.account) { setSeller(state.account); setSponsor(state.account); changed(); } }}>Use my connected wallet for both roles</button>
        <p className="cr-note">A same-wallet pilot aggregates all role credits. It tests the mechanics, not independent participants or merchant trust.</p>
        <label className="cr-live-field">Explicit UTC deadline<input value={deadline} placeholder="YYYY-MM-DDTHH:mm:ssZ" aria-describedby="live-deadline-help" disabled={state.busy} onChange={event => { setDeadline(event.target.value); changed(); }} /></label>
        <div className="cr-live-buttons"><button className="cr-btn" type="button" aria-describedby="live-deadline-basis live-deadline-help" disabled={!checkedDeadline || state.busy || unresolved} onClick={() => { if (checkedDeadline) { setDeadline(checkedDeadline); changed(); } }}>Use last checked chain time +30 min</button></div>
        <p id="live-deadline-basis" className="cr-note">{checkedDeadline && state.network ? <>Based on {NETWORKS[state.network.chain].name} block {state.network.block.toString()}. Last checked chain time: {utc(state.network.timestamp)}.</> : !state.network || state.network.chain !== state.chain ? 'Verify the selected network first to use this helper.' : 'The last checked chain time is outside the supported UTC range.'}</p>
        <p id="live-deadline-help" className="cr-note">This does not refresh chain time. An old check can produce a deadline too soon. Verify again if needed; review and submission each require at least 10 minutes beyond fresh chain time. Claims begin only after finalization at or after the deadline.</p>
        <button className="cr-btn" disabled={walletBlocked} onClick={() => prepare('deploy')}>Review deployment</button>
        {walletBlocked && <p className="cr-note cr-live-disabled-reason">Connect a wallet on the selected network and resolve any outstanding action before a deployment review.</p>}
        {feedback('deploy')}
        {reviewPanel('deploy')}
      </section>
    </details>
    <details className="cr-disclosure cr-live-terms"><summary>Exact immutable pilot text, terms and build identity</summary>
      <p><strong>{PILOT_TITLE}</strong></p><p>{PILOT_DESCRIPTION}</p><p>{PILOT_TERMS}</p>
      <dl className="cr-live-facts"><Row label="Terms hash">{TERMS_HASH}</Row><Row label="Canonical token">{TOKEN}</Row><Row label="Compiler">{ARTIFACT.compiler.version}</Row><Row label="Source SHA-256">{ARTIFACT.sourceSHA256}</Row><Row label="Build settings">Solidity 0.8.28 · optimizer 200 · via IR · Paris EVM</Row></dl>
    </details>
    {snapshot && <section className="cr-live-section" aria-labelledby="live-campaign-title">
      <p className="cr-eyebrow">Verified code / terms / direct creation · not audited</p><h2 id="live-campaign-title">Verified tiny campaign</h2>
      <dl className="cr-live-facts"><Row label="Campaign / spender"><CampaignAddress address={snapshot.address} /></Row><Row label="Deployment transaction">{snapshot.deploymentHash}</Row><Row label="Seller">{snapshot.terms.seller}</Row><Row label="Sponsor">{snapshot.terms.sponsor}</Row><Row label="Deadline">{utc(snapshot.terms.deadline)}</Row><Row label="Units">{snapshot.unitCount.toString()} / 3</Row><Row label="Sponsor prefund">{snapshot.sponsorFunded ? 'Funded' : 'Not funded'}</Row><Row label="State">{campaignStateLabel(snapshot)}</Row><Row label="Lifetime buyer deposits received">{usdc(snapshot.lifetimeDeposits)} USDC</Row><Row label="Current outstanding obligations">{usdc(snapshot.outstanding)} USDC</Row><Row label="Total already claimed">{usdc(snapshot.totalClaimed)} USDC</Row>{snapshot.balance !== undefined && <Row label="Wallet USDC balance">{usdc(snapshot.balance)} USDC · includes gas funds</Row>}</dl>
      <ReferenceExport reference={formatCampaignReference({ chain: snapshot.chain, deploymentHash: snapshot.deploymentHash })} />
      {draftMismatch && <div className="cr-live-warning"><p>The lookup entry differs from this verified pilot. Verify checks the entry above. To act on the pilot shown here, restore its hash first.</p><button className="cr-btn" disabled={state.busy || unresolved} onClick={() => { setHash(snapshot.deploymentHash); changed(); }}>Use this pilot's hash</button></div>}
      <div className="cr-live-buttons"><button className="cr-btn" disabled={campaignBlocked} onClick={() => prepare('approveSponsor')}>Review 0.03 sponsor approval</button><button className="cr-btn" disabled={campaignBlocked} onClick={() => prepare('fund')}>Review sponsor funding</button></div>
      <label className="cr-live-field cr-live-quantity">Reservation quantity<select value={units} disabled={state.busy} onChange={event => { setUnits(event.target.value); changed(); }}>{[1, 2, 3].map(n => <option key={n} value={n}>{n} unit{n > 1 ? 's' : ''} · {usdc(BigInt(n) * PILOT.deposit)} USDC</option>)}</select></label>
      <div className="cr-live-buttons"><button className="cr-btn" disabled={campaignBlocked} onClick={() => prepare('approveReserve')}>Review exact reservation approval</button><button className="cr-btn" disabled={campaignBlocked} onClick={() => prepare('reserve')}>Review reservation</button><button className="cr-btn" disabled={campaignBlocked} onClick={() => prepare('finalize')}>Review finalization</button></div>
      <p className="cr-note">Every review rereads provenance, code, terms, account, chain and current state. The contract enforces prefunding, role, capacity and deadline restrictions. Finalization never happens early, even when full.</p>
      {snapshot.allocation && <section aria-label="Connected wallet allocation receipt"><h3>Your wallet receipt</h3><p className="cr-note">Original allocations remain visible after withdrawal. All roles are additive, and claims go only to this wallet.</p><dl className="cr-live-facts"><Row label="Original buyer refund allocation">{usdc(snapshot.allocation[0])} USDC</Row><Row label="Original seller allocation">{usdc(snapshot.allocation[1])} USDC</Row><Row label="Original sponsor allocation">{usdc(snapshot.allocation[2])} USDC</Row><Row label="Original total allocation">{usdc(snapshot.allocation[3])} USDC</Row><Row label="Already claimed by this wallet">{usdc(snapshot.claimed ?? 0n)} USDC</Row><Row label="Currently claimable">{usdc(snapshot.credit ?? 0n)} USDC</Row></dl>
        {snapshot.seats.map(seat => <p className="cr-note" key={seat.index.toString()}>Seat {(seat.index + 1n).toString()}: deposited 0.060000 USDC{seat.allocation ? ` · gross ${usdc(seat.allocation[0])} · charged ${usdc(seat.allocation[1])} · original refund ${usdc(seat.allocation[2])} USDC` : ' · allocation pending finalization'}.</p>)}
        <button className="cr-btn" disabled={campaignBlocked || !snapshot.credit} onClick={() => prepare('claim')}>Review claim</button></section>}
      {feedback('campaign')}
      {reviewPanel('campaign')}
    </section>}
    {state.receipts.length > 0 && <section className="cr-live-section" aria-labelledby="live-history-title"><h2 id="live-history-title">Transaction receipts</h2><p className="cr-note">No retry, follow-on transfer or reconnect is automatic. Keep hashes for your records. An unknown outcome must be resolved in wallet history before another submission.</p><ol className="cr-live-history">{state.receipts.map(receipt => <li key={receipt.id}><h3>{LABELS[receipt.action]} · {receipt.status}</h3><p className="cr-note">{NETWORKS[receipt.chain].name} · Account {receipt.account}</p><p>{receipt.message}</p>{receipt.amount > 0n && <p className="cr-note">Reviewed amount: {usdc(receipt.amount)} USDC.</p>}{receipt.hash && <p className="cr-live-address"><a target="_blank" rel="noopener noreferrer" href={`${NETWORKS[receipt.chain].blockExplorers.default.url}/tx/${receipt.hash}`}>{receipt.hash}</a></p>}{receipt.originalHash && receipt.originalHash !== receipt.hash && <p className="cr-live-address">Original hash: {receipt.originalHash}</p>}{receipt.status === 'unknown' && <><label className="cr-live-field">Transaction hash from your wallet history<input value={recovery[receipt.id] ?? ''} onChange={event => setRecovery({ ...recovery, [receipt.id]: event.target.value })} /></label><button className="cr-btn" disabled={state.busy} onClick={() => { setActivity('history'); controller.attachHash(receipt.id, recovery[receipt.id] ?? ''); }}>Attach hash without resubmitting</button></>}{canCheckReceipt(receipt) && <button className="cr-btn" disabled={state.busy} onClick={() => { setActivity('history'); setOperation('Checking the transaction receipt. This does not resubmit it.'); void controller.checkReceipt(receipt.id); }}>Check receipt</button>}</li>)}</ol>{feedback('history')}</section>}
    <p className="cr-note">Public references only are saved on this device. Reliable local storage is required before a wallet transaction is requested. No keys, credentials or private wallet information are requested or stored. A successful mocked test does not establish actual Arc USDC compatibility.</p>
  </section>;
}
