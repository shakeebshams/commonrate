import { useEffect, useRef, useState } from 'react';

type ImportProps = { blockedReason: string; onImport: (value: string) => void };
export function ReferenceImport({ blockedReason, onImport }: ImportProps) {
  const [value, setValue] = useState('');
  return <details className="cr-disclosure cr-live-import">
    <summary>Import a shared pilot reference</summary>
    <p className="cr-note" id="reference-import-note">A reference contains only a network and deployment hash. Importing it makes no request and proves nothing about the contract. Verify it separately before using the pilot.</p>
    <form onSubmit={event => { event.preventDefault(); onImport(value); }}>
      <label className="cr-live-field">Pilot reference<input value={value} maxLength={256} autoComplete="off" spellCheck={false} disabled={!!blockedReason} aria-describedby="reference-import-note" placeholder="commonrate:1:5042002:0x…" onChange={event => setValue(event.target.value)} /></label>
      <button type="submit" className="cr-btn" disabled={!!blockedReason || !value}>Import reference only</button>
    </form>
    {blockedReason && <p className="cr-note">{blockedReason}</p>}
  </details>;
}

export function ReferenceExport({ reference }: { reference: string }) {
  const [result, setResult] = useState({ reference: '', message: '' });
  const lifecycle = useRef({ active: true, sequence: 0 });
  useEffect(() => {
    const current = lifecycle.current;
    current.active = true;
    return () => { current.active = false; current.sequence++; };
  }, []);
  const copy = async () => {
    const current = lifecycle.current;
    const sequence = ++current.sequence;
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(reference);
      if (current.active && current.sequence === sequence) setResult({ reference, message: 'Reference copied. The recipient must verify it independently.' });
    } catch {
      if (current.active && current.sequence === sequence) setResult({ reference, message: 'Copy was unavailable. Select the reference and copy it manually.' });
    }
  };
  return <details className="cr-disclosure cr-live-share">
    <summary>Share this verified pilot reference</summary>
    <p className="cr-note">This identifies the network and deployment checked above, not a trusted provider or a delivery guarantee. It grants no access to this app; the app’s sharing settings still apply.</p>
    <label className="cr-live-field">Copyable reference<textarea value={reference} readOnly rows={3} spellCheck={false} onFocus={event => event.currentTarget.select()} /></label>
    <button className="cr-btn" onClick={() => { void copy(); }}>Copy reference</button>
    <p className="cr-note" role="status">{result.reference === reference ? result.message : ''}</p>
  </details>;
}
