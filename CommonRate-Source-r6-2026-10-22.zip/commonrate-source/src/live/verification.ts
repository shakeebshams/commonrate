import { decodeAbiParameters, encodeDeployData, keccak256, stringToHex, type Abi, type Address, type Hex } from 'viem';
import artifactJSON from '../contracts/CommonRate.artifact.json';
import { RELEASE_ARTIFACT_JSON_KECCAK256, RELEASE_CREATION_KECCAK256, RELEASE_RUNTIME_KECCAK256, RELEASE_SOURCE_SHA256 } from './release';
import { constructorArgs, PILOT, PILOT_DESCRIPTION, PILOT_TITLE, publicAddress, requireCondition, sameAddress, TERMS_HASH, TOKEN, validateDeadline, type NetworkId, type PilotTerms } from './pilot';

export type Artifact = { abi: Abi; bytecode: Hex; deployedBytecode: Hex; immutableReferences: Record<string, { start: number; length: number }[]>; sourceSHA256: string; compiler: { version: string } };
export const ARTIFACT = artifactJSON as Artifact;
export function assertRelease(artifact = ARTIFACT) {
  requireCondition(RELEASE_SOURCE_SHA256 && RELEASE_CREATION_KECCAK256 && RELEASE_RUNTIME_KECCAK256, 'Live deployment is locked: the final artifact has not yet passed independent reproduction.');
  requireCondition(keccak256(stringToHex(JSON.stringify(artifact))) === RELEASE_ARTIFACT_JSON_KECCAK256 && artifact.sourceSHA256 === RELEASE_SOURCE_SHA256 && keccak256(artifact.bytecode) === RELEASE_CREATION_KECCAK256 && keccak256(artifact.deployedBytecode) === RELEASE_RUNTIME_KECCAK256, 'Artifact identity does not match the reviewed release. Wallet actions are disabled.');
}
export function validateRuntime(actual: Hex, artifact: Pick<Artifact, 'deployedBytecode' | 'immutableReferences'>) {
  const expected = artifact.deployedBytecode.toLowerCase(); const code = actual.toLowerCase();
  requireCondition(/^0x(?:[a-f0-9]{2})+$/.test(code) && /^0x(?:[a-f0-9]{2})+$/.test(expected) && code.length === expected.length, 'Runtime bytecode length or encoding differs from the artifact.');
  const length = (code.length - 2) / 2; const mask = new Uint8Array(length);
  const groups = Object.entries(artifact.immutableReferences);
  requireCondition(groups.length > 0, 'Artifact immutable references are missing.');
  for (const [id, refs] of groups) {
    requireCondition(/^\d+$/.test(id) && refs.length > 0, 'Malformed immutable group.'); let groupValue: string | undefined;
    for (const ref of refs) {
      requireCondition(Number.isSafeInteger(ref.start) && ref.start >= 0 && ref.length === 32 && ref.start + ref.length <= length, 'Invalid immutable range.');
      const value = code.slice(2 + ref.start * 2, 2 + (ref.start + ref.length) * 2);
      requireCondition(groupValue === undefined || groupValue === value, 'Inconsistent occurrences in one immutable group.'); groupValue = value;
      for (let i = ref.start; i < ref.start + ref.length; i++) { requireCondition(!mask[i], 'Overlapping immutable ranges.'); mask[i] = 1; }
    }
  }
  for (let i = 0; i < length; i++) if (!mask[i]) requireCondition(code.slice(2 + i * 2, 4 + i * 2) === expected.slice(2 + i * 2, 4 + i * 2), 'Runtime differs outside an immutable slot.');
}
export type CreationTransaction = { hash: Hex; to: Address | null; from: Address; value: bigint; input: Hex; chainId?: number; blockHash: Hex | null };
export type CreationReceipt = { transactionHash: Hex; status: 'success' | 'reverted'; contractAddress: Address | null | undefined; blockNumber: bigint; blockHash: Hex; to: Address | null };
export function validateProvenance(tx: CreationTransaction, receipt: CreationReceipt, chain: NetworkId, deploymentTimestamp: bigint, artifact: Artifact = ARTIFACT) {
  requireCondition(tx.to === null && receipt.to === null && tx.value === 0n, 'Only direct zero-value contract creations are supported.');
  requireCondition(tx.chainId === chain && tx.hash.toLowerCase() === receipt.transactionHash.toLowerCase() && tx.blockHash === receipt.blockHash, 'Deployment transaction, receipt, block or chain mismatch.');
  requireCondition(receipt.status === 'success' && receipt.contractAddress, 'Deployment has no successful creation receipt.');
  const address = publicAddress(receipt.contractAddress); publicAddress(tx.from);
  const constructor = artifact.abi.find(entry => entry.type === 'constructor');
  requireCondition(constructor?.type === 'constructor', 'Artifact constructor ABI is missing.');
  requireCondition(tx.input.toLowerCase().startsWith(artifact.bytecode.toLowerCase()), 'Deployment was not created with the reviewed creation bytecode.');
  const suffix: Hex = `0x${tx.input.slice(artifact.bytecode.length)}`;
  const decoded = decodeAbiParameters(constructor.inputs, suffix);
  requireCondition(decoded.length === 12 && typeof decoded[8] === 'bigint', 'Unexpected constructor argument shape.');
  const terms: PilotTerms = { seller: publicAddress(decoded[1]), sponsor: publicAddress(decoded[2]), deadline: decoded[8] };
  validateDeadline(terms, deploymentTimestamp);
  const approvedInput = encodeDeployData({ abi: artifact.abi, bytecode: artifact.bytecode, args: constructorArgs(terms) });
  requireCondition(tx.input.toLowerCase() === approvedInput.toLowerCase(), 'Constructor input does not exactly encode the disclosed tiny pilot.');
  return { address, terms };
}
export type TermReads = { token: unknown; seller: unknown; sponsorAddress: unknown; cost: unknown; depositPerUnit: unknown; subsidyPerUnit: unknown; capacity: unknown; minUnits: unknown; deadline: unknown; sponsorReserve: unknown; title: unknown; description: unknown; termsHash: unknown };
export function validateTermReads(reads: TermReads, terms: PilotTerms) {
  for (const [key, expected] of Object.entries({ token: TOKEN, seller: terms.seller, sponsorAddress: terms.sponsor })) requireCondition(typeof reads[key as keyof TermReads] === 'string' && sameAddress(reads[key as keyof TermReads] as string, expected), `Unexpected ${key}.`);
  const expected = { cost: PILOT.cost, depositPerUnit: PILOT.deposit, subsidyPerUnit: PILOT.subsidy, capacity: PILOT.capacity, minUnits: PILOT.minimum, deadline: terms.deadline, sponsorReserve: PILOT.reserve, title: PILOT_TITLE, description: PILOT_DESCRIPTION, termsHash: TERMS_HASH };
  for (const key of Object.keys(expected) as (keyof typeof expected)[]) requireCondition(reads[key] === expected[key], `Unexpected campaign ${key}.`);
}
export const TERM_GETTERS = ['token', 'seller', 'sponsorAddress', 'cost', 'depositPerUnit', 'subsidyPerUnit', 'capacity', 'minUnits', 'deadline', 'sponsorReserve', 'title', 'description', 'termsHash'] as const;
