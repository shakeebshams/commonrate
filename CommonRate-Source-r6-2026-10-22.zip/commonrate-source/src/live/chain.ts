import { createClient, custom, encodeDeployData, erc20Abi, http, type Address, type EIP1193Provider, type Hex, type PublicActions, type WalletActions, type Transport, type JsonRpcAccount } from 'viem';
import { estimateGas, getBlock, getChainId, getCode, getTransaction, getTransactionCount, getTransactionReceipt, readContract, simulateContract, waitForTransactionReceipt, deployContract, writeContract } from 'viem/actions';
import { ARTIFACT, assertRelease, TERM_GETTERS, validateProvenance, validateRuntime, validateTermReads, type TermReads } from './verification';
import { constructorArgs, NETWORKS, PILOT, requireCondition, sameAddress, TOKEN, type NetworkId, type PilotTerms } from './pilot';

export type ReadRoute = 'public' | 'wallet';
type PilotChain = (typeof NETWORKS)[NetworkId];
type ReadActions = Pick<PublicActions<Transport, PilotChain, undefined>, 'estimateGas' | 'getBlock' | 'getChainId' | 'getCode' | 'getTransaction' | 'getTransactionCount' | 'getTransactionReceipt' | 'readContract' | 'simulateContract' | 'waitForTransactionReceipt'>;
type WriteActions = Pick<WalletActions<PilotChain, JsonRpcAccount>, 'deployContract' | 'writeContract'>;
export function readClient(chain: NetworkId, route: ReadRoute, provider?: EIP1193Provider) {
  requireCondition(route !== 'wallet' || provider, 'Connect a wallet before explicitly choosing its RPC for reads.');
  return createClient({ key: 'public', name: 'Public Client', type: 'publicClient', chain: NETWORKS[chain], transport: route === 'wallet' && provider ? custom(provider, { retryCount: 0 }) : http(NETWORKS[chain].rpcUrls.default.http[0], { retryCount: 0, timeout: 15000 }) }).extend((client): ReadActions => ({
    estimateGas: args => estimateGas(client, args),
    getBlock: args => getBlock(client, args),
    getChainId: () => getChainId(client),
    getCode: args => getCode(client, args),
    getTransaction: args => getTransaction(client, args),
    getTransactionCount: args => getTransactionCount(client, args),
    getTransactionReceipt: args => getTransactionReceipt(client, args),
    readContract: args => readContract(client, args),
    simulateContract: args => simulateContract(client, args),
    waitForTransactionReceipt: args => waitForTransactionReceipt(client, args),
  }));
}
export type Reader = ReturnType<typeof readClient>;
export function walletClient(chain: NetworkId, account: Address, provider: EIP1193Provider) {
  // Keep the separately reviewed one-submission-method guard. viem's fallback
  // wallet_sendTransaction must never reach the provider after an ambiguous error.
  return createClient({ key: 'wallet', name: 'Wallet Client', type: 'walletClient', chain: NETWORKS[chain], account, transport: custom(provider, {
    retryCount: 0, methods: { include: ['eth_chainId', 'eth_sendTransaction'] },
  }) }).extend((client): WriteActions => ({
  deployContract: args => deployContract(client, args),
  writeContract: args => writeContract(client, args),
})); }
export type NetworkCheck = { chain: NetworkId; block: bigint; timestamp: bigint };
export async function verifyNetwork(reader: Reader, chain: NetworkId): Promise<NetworkCheck> {
  requireCondition(await reader.getChainId() === chain, 'RPC is on the wrong chain.');
  const block = await reader.getBlock(); requireCondition(block.number !== null, 'No current block is available.');
  const [code, decimals] = await Promise.all([reader.getCode({ address: TOKEN, blockNumber: block.number }), reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'decimals', blockNumber: block.number })]);
  requireCondition(code && code !== '0x', 'Canonical USDC has no bytecode on this chain.'); requireCondition(decimals === 6, 'Canonical ERC-20 USDC did not report 6 decimals.');
  return { chain, block: block.number, timestamp: block.timestamp };
}
function uint(value: unknown, name: string): bigint { requireCondition(typeof value === 'bigint' && value >= 0n, `Invalid ${name} response.`); return value; }
function boolean(value: unknown, name: string): boolean { requireCondition(typeof value === 'boolean', `Invalid ${name} response.`); return value; }
function uintTuple(value: unknown, length: number, name: string): bigint[] { requireCondition(Array.isArray(value) && value.length === length, `Invalid ${name} response.`); return value.map(x => uint(x, name)); }
export type CampaignSnapshot = NetworkCheck & {
  address: Address; deploymentHash: Hex; terms: PilotTerms; unitCount: bigint; sponsorFunded: boolean; finalized: boolean; succeeded: boolean;
  outstanding: bigint; lifetimeDeposits: bigint; totalClaimed: bigint; account?: Address; balance?: bigint; allowance?: bigint; credit?: bigint; claimed?: bigint;
  allocation?: bigint[]; seats: { index: bigint; allocation?: bigint[] }[];
};
export async function verifyCampaign(reader: Reader, chain: NetworkId, deploymentHash: Hex, account?: Address): Promise<CampaignSnapshot> {
  assertRelease(); const net = await verifyNetwork(reader, chain);
  const [tx, receipt] = await Promise.all([reader.getTransaction({ hash: deploymentHash }), reader.getTransactionReceipt({ hash: deploymentHash })]);
  requireCondition(receipt.transactionHash.toLowerCase() === deploymentHash.toLowerCase(), 'Unexpected deployment receipt hash.');
  const deploymentBlock = await reader.getBlock({ blockNumber: receipt.blockNumber });
  requireCondition(deploymentBlock.hash === receipt.blockHash && receipt.blockNumber <= net.block, 'Deployment receipt is not in the selected canonical chain.');
  const { address, terms } = validateProvenance(tx, receipt, chain, deploymentBlock.timestamp);
  const code = await reader.getCode({ address, blockNumber: net.block }); requireCondition(code, 'Campaign bytecode is unavailable.'); validateRuntime(code, ARTIFACT);
  const read = (functionName: string, args: readonly unknown[] = []) => reader.readContract({ address, abi: ARTIFACT.abi, functionName, args, blockNumber: net.block });
  const values = await Promise.all(TERM_GETTERS.map(name => read(name))); const termsRead = Object.fromEntries(TERM_GETTERS.map((key, i) => [key, values[i]])) as TermReads; validateTermReads(termsRead, terms);
  const [count, funded, finalizedValue, success, outstanding, lifetime, totalClaimed] = await Promise.all(['unitCount', 'sponsorFunded', 'finalized', 'succeeded', 'accountedLiabilities', 'totalDepositsReceived', 'totalClaimed'].map(name => read(name)));
  const unitCount = uint(count, 'unit count'); requireCondition(unitCount <= PILOT.capacity, 'Campaign count exceeds the tiny pilot capacity.');
  const snapshot: CampaignSnapshot = { ...net, address, deploymentHash, terms, unitCount, sponsorFunded: boolean(funded, 'sponsor funded'), finalized: boolean(finalizedValue, 'finalized'), succeeded: boolean(success, 'succeeded'), outstanding: uint(outstanding, 'outstanding'), lifetimeDeposits: uint(lifetime, 'lifetime deposits'), totalClaimed: uint(totalClaimed, 'claimed'), seats: [] };
  if (account) {
    const [balance, allowance, credit, claimed, allocation, seats] = await Promise.all([
      reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'balanceOf', args: [account], blockNumber: net.block }),
      reader.readContract({ address: TOKEN, abi: erc20Abi, functionName: 'allowance', args: [account, address], blockNumber: net.block }),
      read('credits', [account]), read('claimedByWallet', [account]), read('walletAllocation', [account]), read('seatsOf', [account]),
    ]);
    requireCondition(Array.isArray(seats) && seats.length <= 3, 'Invalid wallet seat list.');
    const indices = seats.map(x => uint(x, 'seat index')); requireCondition(new Set(indices).size === indices.length && indices.every(x => x < unitCount), 'Invalid wallet seat indices.');
    Object.assign(snapshot, { account, balance, allowance, credit: uint(credit, 'credit'), claimed: uint(claimed, 'claimed'), allocation: uintTuple(allocation, 6, 'wallet allocation') });
    snapshot.seats = await Promise.all(indices.map(async index => ({ index, ...(snapshot.finalized ? { allocation: uintTuple(await read('seatAllocation', [index]), 3, 'seat allocation') } : {}) })));
    requireCondition(snapshot.allocation?.[4] === snapshot.claimed && snapshot.allocation?.[5] === snapshot.credit, 'Wallet allocation and credit reads disagree.');
  }
  return snapshot;
}
export function snapshotFingerprint(snapshot: CampaignSnapshot) {
  return JSON.stringify({ chain: snapshot.chain, address: snapshot.address.toLowerCase(), terms: snapshot.terms, unitCount: snapshot.unitCount, sponsorFunded: snapshot.sponsorFunded, finalized: snapshot.finalized, succeeded: snapshot.succeeded, account: snapshot.account?.toLowerCase(), credit: snapshot.credit, allowance: snapshot.allowance, claimed: snapshot.claimed }, (_key, value: unknown) => typeof value === 'bigint' ? value.toString() : value);
}
export function callMatches(actual: { from: Address; to: Address | null; input: Hex; value: bigint; chainId?: number; nonce: number }, expected: { account: Address; to: Address | null; data: Hex; chain: NetworkId; nonce: number }) {
  return sameAddress(actual.from, expected.account) && actual.chainId === expected.chain && actual.nonce === expected.nonce && actual.value === 0n && (actual.to === null ? expected.to === null : expected.to !== null && sameAddress(actual.to, expected.to)) && actual.input.toLowerCase() === expected.data.toLowerCase();
}
export function deploymentData(terms: PilotTerms) { return encodeDeployData({ abi: ARTIFACT.abi, bytecode: ARTIFACT.bytecode, args: constructorArgs(terms) }); }

export function replacementLineageMatches(original: Parameters<typeof callMatches>[0], replacement: Parameters<typeof callMatches>[0], expected: Parameters<typeof callMatches>[1]) {
  return callMatches(original, expected) && sameAddress(replacement.from, expected.account) && replacement.chainId === expected.chain && replacement.nonce === expected.nonce;
}
