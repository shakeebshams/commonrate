import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import type { SimState } from './simulation/types';
import type { ScenarioId } from './simulation/engine';
import { buildScenarioState, participantAddr, SCENARIOS, simulateClaim } from './simulation/engine';
import { computeGates } from './simulation/math';
import { formatAmount, openDemo, quoteSeats, receiptFor, statusText } from './simulation/presentation';
import MoneyMap from './components/MoneyMap';
import PriceCurve from './components/PriceCurve';
import SandboxControls, { completedActionAnnouncement, type CompletedSandboxAction } from './components/SandboxControls';
import ScenarioPicker from './components/ScenarioPicker';
import RulesDrawer from './components/RulesDrawer';
import LiveBoundary from './components/LiveBoundary';
import ReservationReceipt, { receiptEmphasis } from './components/ReservationReceipt';

const LivePilot = lazy(() => import('./live/LivePilot'));

type Mode = 'sandbox' | 'live';

export default function App() {
  const [mode, setMode] = useState<Mode>('sandbox');
  const [state, setState] = useState<SimState>(() => openDemo());
  const [scenarioId, setScenarioId] = useState<ScenarioId | null>(null);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [sandboxView, setSandboxView] = useState<'booking' | 'workspace'>('booking');
  const [announcement, setAnnouncement] = useState('');
  const workspaceHeading = useRef<HTMLHeadingElement>(null);
  const workspaceOpener = useRef<HTMLButtonElement>(null);
  const receiptHeading = useRef<HTMLHeadingElement>(null);
  const announcedState = useRef(state);
  const completedAction = useRef<CompletedSandboxAction | null>(null);
  const mainRef = useRef<HTMLElement>(null);
  const rulesOpener = useRef<HTMLButtonElement>(null);
  const receipt = receiptFor(state, participantAddr(0));
  const { terms, unitCount, finalized, finalizeResult } = state;
  const gates = computeGates(terms, unitCount, state.sponsorFunded, state.deadlinePassed);
  const canSucceed = gates.gateMinUnits && gates.gateEligibleFunding && gates.gateSponsorFunded;
  const update = (next: SimState, message?: string) => { completedAction.current = message ? { state: next, message } : null; setState(next); setScenarioId(null); };
  const choose = (id: ScenarioId) => { completedAction.current = null; setScenarioId(id); setState(buildScenarioState(SCENARIOS.find(s => s.id === id)!)); };
  const openControls = () => {
    setSandboxView('workspace');
    window.requestAnimationFrame(() => workspaceHeading.current?.focus());
  };
  const closeControls = () => {
    setSandboxView('booking');
    window.requestAnimationFrame(() => workspaceOpener.current?.focus());
  };
  const emphasis = receiptEmphasis(state, receipt);
  useEffect(() => {
    if (announcedState.current === state) return;
    announcedState.current = state;
    const actionMessage = completedActionAnnouncement(completedAction.current, state);
    completedAction.current = null;
    setAnnouncement(actionMessage ?? `${unitCount} seats. ${emphasis.state}. ${emphasis.label}${emphasis.amount === null ? '' : `: ${formatAmount(emphasis.amount)} USDC`}.`);
  }, [state, unitCount, emphasis.state, emphasis.label, emphasis.amount]);
  const switchMode = (next: Mode) => {
    setRulesOpen(false); setMode(next);
    window.requestAnimationFrame(() => { mainRef.current?.focus({ preventScroll: true }); window.scrollTo({ top: 0, behavior: 'auto' }); });
  };
  const currentSeats = quoteSeats(terms, unitCount, state.sponsorFunded);
  const range = (low: bigint, high: bigint) => low === high ? formatAmount(low) : `${formatAmount(low)}–${formatAmount(high)}`;
  const perSeatGross = currentSeats?.length && canSucceed ? range(currentSeats[currentSeats.length - 1].gross, currentSeats[0].gross) : null;
  const perSeatCharge = currentSeats?.length && canSucceed ? range(currentSeats[currentSeats.length - 1].charge, currentSeats[0].charge) : null;


  return <>
    <div className="cr-preview-strip"><span className="cr-preview-dot" aria-hidden="true" /> {mode === 'sandbox' ? 'Sandbox preview. No real money, wallet or booking.' : 'Experimental Live pilot. Mainnet uses real USDC; testnet uses test tokens.'}</div>
    <header className="cr-header"><div className="cr-header-inner">
      <a className="cr-brand" href="#main"><span className="cr-brand-mark" aria-hidden="true"><i /><i /><i /></span>CommonRate</a>
      <div className="cr-header-actions">
        {mode === 'sandbox' && <button ref={rulesOpener} className="cr-text-button" onClick={() => setRulesOpen(true)} aria-haspopup="dialog">The rules</button>}
        {mode === 'live' && <button className="cr-text-button" onClick={() => switchMode('sandbox')}>Back to Sandbox</button>}
        <span className="cr-header-demo">{mode === 'sandbox' ? 'Simulated example' : 'User-operated pilot'}</span>
      </div>
    </div></header>
    <main ref={mainRef} id="main" className="cr-main" tabIndex={-1}>
      {mode === 'live' ? <><LiveBoundary onReturn={() => switchMode('sandbox')}><Suspense fallback={<p className="cr-note" role="status">Loading the separate experimental pilot. No wallet connection has been requested.</p>}><LivePilot /></Suspense></LiveBoundary></> : <>
        <p className="cr-sr-only" role="status" aria-live="polite" aria-atomic="true">{announcement}</p>
        {sandboxView === 'workspace' ? <section className="cr-workspace" aria-labelledby="workspace-title">
          <div className="cr-workspace-header"><h1 ref={workspaceHeading} id="workspace-title" tabIndex={-1}>Payment outcomes</h1><button className="cr-text-button" onClick={closeControls}>Back to the booking sheet</button></div>
          <div className="cr-workspace-grid">
            <ReservationReceipt state={state} receipt={receipt} compact receiptHeadingRef={receiptHeading} outcomeControl={<ScenarioPicker activeId={scenarioId} onSelect={choose} />} onClaim={() => update(simulateClaim(state, participantAddr(0)))} />
            <div className="cr-workspace-controls"><SandboxControls state={state} onStateChange={update} scenarioId={scenarioId} onSelectScenario={choose} onReset={() => update(openDemo())} onViewReceipt={() => receiptHeading.current?.focus()} /></div>
          </div>
        </section> : <section className="cr-booking-grid" aria-labelledby="round-title">
          <div className="cr-booking-story">
            <h1 id="round-title">Expert session, shared.</h1>
            <p className="cr-intro"><strong>{formatAmount(terms.depositPerUnit)} USDC</strong> reserves one paid seat. If the round succeeds, more seats mean a lower final cost.</p>
            <p className="cr-service-line">Agree the session with your provider outside CommonRate. No real provider or date is booked.</p>
            <section className="cr-round-status" aria-labelledby="status-heading">
              <div className="cr-section-head"><h2 id="status-heading"><span className="cr-count">{unitCount}</span> of {String(terms.capacity)} seats reserved</h2><span className="cr-min-label">Minimum {String(terms.minUnits)}</span></div>
              <div className="cr-seat-track" aria-hidden="true">{Array.from({ length: Number(terms.capacity) }, (_, index) => <span key={index} className={index < unitCount ? 'is-reserved' : ''} />)}</div>
              <p className={`cr-status-text${state.phase === 'Failed' ? ' is-failed' : ''}`} role="status">{statusText(state)}</p>
            </section>

          </div>
          <ReservationReceipt state={state} receipt={receipt} onClaim={() => update(simulateClaim(state, participantAddr(0)))} onExplore={openControls} exploreRef={workspaceOpener} />
          <div className="cr-booking-details">
            <section className="cr-sharing-ledger" aria-labelledby="share-title"><h2 id="share-title">How your share is set</h2>
              <dl className="cr-ledger"><div><dt>Fixed session fee</dt><dd>{formatAmount(terms.cost)} USDC</dd></div><div><dt>Shared across {unitCount} reserved seats</dt><dd>{perSeatGross === null ? 'No successful quote' : `${perSeatGross} USDC / seat`}</dd></div><div><dt>Sponsor support on success</dt><dd>−{formatAmount(terms.subsidyPerUnit)} USDC / seat</dd></div><div className="cr-ledger-emphasis"><dt>{finalized ? 'Final cost per seat' : 'Estimated cost per seat'}</dt><dd>{perSeatCharge === null ? finalized && finalizeResult?.branch === 'failure' ? '0 USDC' : 'Not available' : `${perSeatCharge} USDC`}</dd></div></dl>
              {!canSucceed && <p className="cr-note">The current state does not meet the funding conditions. No successful price is quoted.</p>}
            </section>
            <dl className="cr-facts"><div><dt>Fixed service cost</dt><dd>{formatAmount(terms.cost)} USDC</dd></div><div><dt>Deadline</dt><dd>1 Dec 2026 · 00:00 UTC <small>Illustrative, not a countdown</small></dd></div><div><dt>Sponsor reserve</dt><dd>{formatAmount(state.actualReserve)} / {formatAmount(terms.sponsorReserve)} USDC <small>Actually deposited / required budget</small></dd></div></dl>
            <div className="cr-plain-note"><p><strong>Below {String(terms.minUnits)} seats?</strong> Buyer deposits become available to claim after the deadline and settlement. Sponsor funding reserved for empty seats cannot fill a funding gap.</p><p>This handles the payment rules, not delivery. Use it only with a provider you trust. Deposits cannot be withdrawn early. Funding-round refunds do not cover later cancellation, nonattendance or nondelivery.</p></div>
          </div>
        </section>}
        <details className="cr-disclosure cr-price-disclosure"><summary>Compare exact prices at different seat counts</summary><PriceCurve terms={terms} highlightN={unitCount} sponsorFunded={state.sponsorFunded} /></details>

        <details className="cr-disclosure cr-money-disclosure"><summary>Inspect the allocation and exact seat table</summary><MoneyMap state={state} /></details>
      </>}
    </main>
    <footer className="cr-footer"><span>CommonRate · a conditional group-payment prototype</span><span>Arc Studio foundation · manually refined preview</span><button className="cr-text-button" onClick={() => switchMode(mode === 'live' ? 'sandbox' : 'live')}>{mode === 'live' ? 'Return to Sandbox' : 'Review the experimental Live pilot'}</button></footer>
    <RulesDrawer open={rulesOpen} onClose={() => setRulesOpen(false)} openerRef={rulesOpener} />
  </>;
}
