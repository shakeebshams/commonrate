/** Manual UI selectors. One simulation is the source of every displayed balance. */
import type { CampaignTerms, SeatAllocation, SimState } from './types';
import { makeInitialState, participantAddr, reserve } from './engine';
import { computeFailureSeats, computeGates, computeSuccessSeats, formatMicro } from './math';

export function formatAmount(value: bigint): string {
  return formatMicro(value).replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');
}

export function openDemo(unitCount = 10): SimState {
  let state = makeInitialState();
  for (let index = 0; index < unitCount; index++) {
    state = reserve(state, 1, participantAddr(index));
  }
  return state;
}

export function quoteSeats(terms: CampaignTerms, count: number, funded: boolean): SeatAllocation[] | null {
  if (!Number.isSafeInteger(count) || count <= 0 || BigInt(count) > terms.capacity) return null;
  const gates = computeGates(terms, count, funded, true);
  if (!gates.gateSponsorFunded) return null;
  return gates.gateMinUnits && gates.gateEligibleFunding
    ? computeSuccessSeats(terms, count)
    : computeFailureSeats(terms, count);
}

export function receiptFor(state: SimState, wallet: string) {
  const indices = state.seatOwners.flatMap((owner, index) => owner === wallet ? [index] : []);
  const seats = state.finalizeResult?.seats ?? quoteSeats(state.terms, state.unitCount, state.sponsorFunded);
  const deposit = state.terms.depositPerUnit * BigInt(indices.length);
  const charge = seats ? indices.reduce((sum, index) => sum + seats[index].charge, 0n) : null;
  const refund = seats ? indices.reduce((sum, index) => sum + seats[index].refund, 0n) : null;
  const allocated = state.finalizeResult?.walletCredits[wallet] ?? 0n;
  const claimed = state.claimed[wallet] ?? 0n;
  return { indices, deposit, charge, refund, allocated, claimed, outstanding: allocated - claimed };
}

export type SampleReceipt = ReturnType<typeof receiptFor>;

export function statusText(state: SimState): string {
  if (state.phase === 'AwaitingSponsor') return 'Waiting for sponsor funding';
  if (state.phase === 'ReadyFinalize') return 'Deadline passed. Ready to settle.';
  if (state.phase === 'Succeeded') return 'Round settled. Credits ready to claim.';
  if (state.phase === 'Failed') return state.unitCount === 0 ? 'Round closed without reservations.' : 'Minimum not reached. Deposits available to claim.';
  if (state.phase === 'FullAwaitDeadline') return 'All seats reserved. Waiting for the deadline.';
  return BigInt(state.unitCount) >= state.terms.minUnits ? 'Minimum reached. Reservations are still open.' : `${Number(state.terms.minUnits) - state.unitCount} more ${Number(state.terms.minUnits) - state.unitCount === 1 ? 'seat' : 'seats'} to reach the minimum.`;
}
