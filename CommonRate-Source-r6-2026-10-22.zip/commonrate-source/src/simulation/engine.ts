// Simulation engine: all state transitions matching CommonRate.sol logic.
// No floating point. No real wallet calls. Pure deterministic JS.

import type {
  SimState,
  CampaignTerms,
  FinalizeResult,
  MicroUSDC,
  WalletReceipt,
} from './types';
import {
  computeSuccessSeats,
  computeFailureSeats,
  computeGates,
  checkConservation,
} from './math';

// ── Canonical sandbox campaign ────────────────────────────────────────────────
export const SANDBOX_TERMS: CampaignTerms = {
  cost:           600_000_000n, // 600 USDC
  depositPerUnit:  60_000_000n, // 60 USDC max per paid unit
  subsidyPerUnit:  15_000_000n, // 15 USDC sponsor subsidy per successful unit
  sponsorReserve: 180_000_000n, // S = 15 * 12
  capacity:       12n,
  minUnits:        8n,
  // Fixed illustrative UTC deadline — not a real countdown
  deadlineLabel:  '2026-12-01 00:00 UTC (illustrative)',
  title:          'Illustrative Expert Session',
  description:
    'One agreed expert-session fee shared by a known group. No real provider or availability is claimed. ' +
    'Paid units are NOT unique people — one wallet may hold multiple.',
};

export const SANDBOX_SELLER  = 'seller.workshop';
export const SANDBOX_SPONSOR = 'sponsor.workshop';

// Deterministic participant addresses — no Math.random
export function participantAddr(i: number): string {
  return `participant.${i.toString().padStart(2, '0')}`;
}

// ── Initial state factory ─────────────────────────────────────────────────────
// B=0: always Open (no sponsor needed).
// B>0, sponsorPrefunded=true: Open with actualReserve set.
// B>0, sponsorPrefunded=false: AwaitingSponsor.
export function makeInitialState(
  terms: CampaignTerms = SANDBOX_TERMS,
  sponsorPrefunded = true
): SimState {
  const needsSponsor = terms.subsidyPerUnit > 0n;
  const funded = needsSponsor ? sponsorPrefunded : false; // B=0 → no sponsor
  return {
    terms,
    phase: needsSponsor && !funded ? 'AwaitingSponsor' : 'Open',
    sponsorFunded: funded,
    actualReserve: funded ? terms.sponsorReserve : 0n,
    unitCount: 0,
    seatOwners: [],
    deadlinePassed: false,
    finalized: false,
    finalizeResult: null,
    claimed: {},
    totalOutstanding: 0n,
    totalClaimed: 0n,
    donationBalance: 0n,
  };
}

// ── State transitions (return new state, never mutate) ────────────────────────

export function fundSponsor(state: SimState): SimState {
  if (state.sponsorFunded) throw new Error('Sponsor already funded');
  if (state.terms.subsidyPerUnit === 0n) throw new Error('No sponsor required (B=0)');
  if (state.deadlinePassed) throw new Error('Deadline has passed');
  return {
    ...state,
    sponsorFunded: true,
    actualReserve: state.terms.sponsorReserve,
    phase: 'Open',
  };
}

export function reserve(state: SimState, units: number, walletAddr: string): SimState {
  // Validate units before any state access
  if (!Number.isSafeInteger(units) || units !== Math.floor(units)) {
    throw new Error('Units must be a whole number');
  }
  if (units <= 0) throw new Error('Must reserve at least 1 unit');

  if (state.deadlinePassed) throw new Error('Deadline has passed');
  if (state.terms.subsidyPerUnit > 0n && !state.sponsorFunded)
    throw new Error('Sponsor must fund before reservations open');

  const remaining = Number(state.terms.capacity) - state.unitCount;
  if (units > remaining) throw new Error(`Only ${remaining} unit(s) remaining`);

  const newOwners = [...state.seatOwners];
  for (let i = 0; i < units; i++) newOwners.push(walletAddr);

  const newCount = state.unitCount + units;
  const newPhase =
    newCount >= Number(state.terms.capacity) ? 'FullAwaitDeadline' : 'Open';

  return {
    ...state,
    unitCount: newCount,
    seatOwners: newOwners,
    phase: newPhase,
  };
}

export function passDeadline(state: SimState): SimState {
  if (state.finalized) return state;
  return {
    ...state,
    deadlinePassed: true,
    phase: 'ReadyFinalize',
  };
}

export function finalize(state: SimState): SimState {
  if (!state.deadlinePassed) throw new Error('Deadline not yet passed');
  if (state.finalized) throw new Error('Already finalized');

  const { terms } = state;
  const N = state.unitCount;
  const gates = computeGates(terms, N, state.sponsorFunded, state.deadlinePassed);
  const success =
    gates.gateMinUnits &&
    gates.gateEligibleFunding &&
    gates.gateSponsorFunded &&
    gates.gateDeadline;

  const seats = success
    ? computeSuccessSeats(terms, N)
    : computeFailureSeats(terms, N);

  // Build per-wallet credits using += (roles may overlap, never overwrite)
  const walletCredits: Record<string, MicroUSDC> = {};
  const add = (addr: string, amt: MicroUSDC) => {
    walletCredits[addr] = (walletCredits[addr] ?? 0n) + amt;
  };

  let totalCredit = 0n;

  if (success) {
    for (let i = 0; i < N; i++) {
      add(state.seatOwners[i], seats[i].refund);
      totalCredit += seats[i].refund;
    }
    add(SANDBOX_SELLER, terms.cost);
    totalCredit += terms.cost;
    if (terms.subsidyPerUnit > 0n) {
      const sponsorBack = terms.sponsorReserve - BigInt(N) * terms.subsidyPerUnit;
      add(SANDBOX_SPONSOR, sponsorBack);
      totalCredit += sponsorBack;
    }
  } else {
    for (let i = 0; i < N; i++) {
      add(state.seatOwners[i], terms.depositPerUnit);
      totalCredit += terms.depositPerUnit;
    }
    if (state.actualReserve > 0n) {
      add(SANDBOX_SPONSOR, state.actualReserve);
      totalCredit += state.actualReserve;
    }
  }

  const liabilities = BigInt(N) * terms.depositPerUnit + state.actualReserve;
  const conserved = checkConservation(totalCredit, N, terms.depositPerUnit, state.actualReserve);
  if (!conserved) throw new Error(`Conservation violation: totalCredit=${totalCredit} liabilities=${liabilities}`);

  const result: FinalizeResult = {
    branch: success ? 'success' : 'failure',
    N,
    seats,
    sellerCredit: success ? terms.cost : 0n,
    sponsorCredit: success
      ? terms.subsidyPerUnit > 0n
        ? terms.sponsorReserve - BigInt(N) * terms.subsidyPerUnit
        : 0n
      : state.actualReserve,
    walletCredits,
    totalCredit,
    liabilities,
    ...gates,
  };

  return {
    ...state,
    finalized: true,
    finalizeResult: result,
    phase: success ? 'Succeeded' : 'Failed',
    totalOutstanding: totalCredit,
  };
}

export function simulateClaim(state: SimState, walletAddr: string): SimState {
  if (!state.finalized || !state.finalizeResult)
    throw new Error('Not yet finalized');
  const credit = state.finalizeResult.walletCredits[walletAddr] ?? 0n;
  const alreadyClaimed = state.claimed[walletAddr] ?? 0n;
  const claimable = credit - alreadyClaimed;
  if (claimable <= 0n) throw new Error('Nothing to claim for this wallet');

  return {
    ...state,
    claimed: { ...state.claimed, [walletAddr]: credit },
    totalOutstanding: state.totalOutstanding - claimable,
    totalClaimed: state.totalClaimed + claimable,
  };
}

// ── Scenario presets ──────────────────────────────────────────────────────────
export type ScenarioId =
  | 'n10'   // N=10 initial
  | 'n8'    // N=8 just enough
  | 'n9'    // N=9 rounding
  | 'n12'   // N=12 full round
  | 'n7'    // N=7 failure
  | 'n0'    // N=0 funded (no buyers)
  | 'await' // awaiting sponsor
  ;

export interface Scenario {
  id: ScenarioId;
  label: string;
  description: string;
  N: number;
  sponsorFunded: boolean;
  deadlinePassed: boolean;
  finalized: boolean;
}

export const SCENARIOS: Scenario[] = [
  {
    id: 'n10',
    label: 'N = 10 · More together',
    description: '10 paid units. Each charged 45 USDC / refund 15 USDC. Seller gets 600.',
    N: 10, sponsorFunded: true, deadlinePassed: true, finalized: true,
  },
  {
    id: 'n8',
    label: 'N = 8 · Just enough',
    description: 'Minimum met exactly. Each unit charged full 60 USDC deposit. No refund.',
    N: 8, sponsorFunded: true, deadlinePassed: true, finalized: true,
  },
  {
    id: 'n9',
    label: 'N = 9 · Rounding demo',
    description: 'First 6 units charged 51.666667, last 3 charged 51.666666 USDC.',
    N: 9, sponsorFunded: true, deadlinePassed: true, finalized: true,
  },
  {
    id: 'n12',
    label: 'N = 12 · Full round',
    description: 'All 12 seats. Unit charge 35 USDC / refund 25 USDC. Sponsor fully used.',
    N: 12, sponsorFunded: true, deadlinePassed: true, finalized: true,
  },
  {
    id: 'n7',
    label: 'N = 7 · Falls short',
    description: '600 USDC held but only 525 eligible. Minimum missed. All deposits refundable.',
    N: 7, sponsorFunded: true, deadlinePassed: true, finalized: true,
  },
  {
    id: 'n0',
    label: 'N = 0 · No buyers',
    description: 'Sponsor funded, deadline passed, zero units reserved. Failure. Sponsor reclaims 180 USDC.',
    N: 0, sponsorFunded: true, deadlinePassed: true, finalized: true,
  },
  {
    id: 'await',
    label: 'Awaiting sponsor',
    description: 'B > 0 but sponsor has not funded yet. No reservations possible.',
    N: 0, sponsorFunded: false, deadlinePassed: false, finalized: false,
  },
];

// Deterministic seat distribution across 4 participant addresses
export function buildScenarioState(scenario: Scenario): SimState {
  let state = makeInitialState(SANDBOX_TERMS, scenario.sponsorFunded);

  if (scenario.N > 0 && (scenario.sponsorFunded || SANDBOX_TERMS.subsidyPerUnit === 0n)) {
    const seatsEach = Math.floor(scenario.N / 4);
    const rem = scenario.N % 4;
    let seated = 0;
    for (let p = 0; p < 4 && seated < scenario.N; p++) {
      const take = p < rem ? seatsEach + 1 : seatsEach;
      if (take > 0) {
        state = reserve(state, take, participantAddr(p));
        seated += take;
      }
    }
  }

  if (scenario.deadlinePassed) {
    state = passDeadline(state);
  }

  if (scenario.finalized) {
    state = finalize(state);
  }

  return state;
}

// ── Wallet receipts ───────────────────────────────────────────────────────────
export function buildWalletReceipts(state: SimState): WalletReceipt[] {
  const receipts: Map<string, WalletReceipt> = new Map();

  const ensure = (addr: string): WalletReceipt => {
    if (!receipts.has(addr)) {
      receipts.set(addr, {
        address: addr,
        role: [],
        seatIndices: [],
        deposited: 0n,
        allocated: 0n,
        claimed: 0n,
        claimable: 0n,
      });
    }
    return receipts.get(addr)!;
  };

  // Buyer seats
  for (let i = 0; i < state.unitCount; i++) {
    const addr = state.seatOwners[i];
    const r = ensure(addr);
    if (!r.role.includes('buyer')) r.role.push('buyer');
    r.seatIndices.push(i);
    r.deposited += state.terms.depositPerUnit;
  }

  // Seller: always visible once finalized (even if credit is 0 on failure)
  if (state.finalized) {
    const r = ensure(SANDBOX_SELLER);
    if (!r.role.includes('seller')) r.role.push('seller');
  }

  // Sponsor: deposit is actualReserve (not 0 when B=0)
  if (state.sponsorFunded) {
    const r = ensure(SANDBOX_SPONSOR);
    if (!r.role.includes('sponsor')) r.role.push('sponsor');
    r.deposited += state.actualReserve; // sponsor deposited actualReserve
  }

  // Populate allocated / claimable / claimed from finalize result
  if (state.finalizeResult) {
    for (const [addr, credit] of Object.entries(state.finalizeResult.walletCredits)) {
      const r = ensure(addr);
      r.allocated = credit;
      r.claimed = state.claimed[addr] ?? 0n;
      r.claimable = r.allocated - r.claimed;
    }
  }

  return Array.from(receipts.values()).filter(
    r => r.seatIndices.length > 0 ||
         r.role.includes('seller') ||
         r.role.includes('sponsor')
  );
}
