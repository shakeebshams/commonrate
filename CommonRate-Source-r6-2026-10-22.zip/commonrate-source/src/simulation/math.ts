// Pure integer arithmetic matching CommonRate.sol exactly.
// All values are BigInt micro-USDC (6 decimals). No floating point.

import type { MicroUSDC, SeatAllocation, CampaignTerms } from './types';

export const MICRO = 1_000_000n; // 1 USDC in micro-units

/** Format micro-USDC as a human-readable string: "45.000000 USDC" */
export function formatMicro(v: MicroUSDC, decimals = 6): string {
  const abs = v < 0n ? -v : v;
  const intPart = abs / MICRO;
  const fracPart = abs % MICRO;
  const frac = fracPart.toString().padStart(6, '0').slice(0, decimals);
  const sign = v < 0n ? '-' : '';
  if (decimals === 0) return `${sign}${intPart}`;
  return `${sign}${intPart}.${frac}`;
}

/** Format as compact USD display: "$45.00" */
export function formatUSD(v: MicroUSDC): string {
  const abs = v < 0n ? -v : v;
  const cents = (abs + 5_000n) / 10_000n;
  const whole = (cents / 100n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const fraction = (cents % 100n).toString().padStart(2, '0');
  return `${v < 0n ? '-' : ''}$${whole}.${fraction}`;
}

/** Format as short display: "45.000000" (no symbol) */
export function formatMicroShort(v: MicroUSDC): string {
  return formatMicro(v, 6);
}

/**
 * Compute per-seat allocation for seat index i given q and r.
 * Matches _seatAllocSuccess() in CommonRate.sol exactly.
 */
export function seatAllocSuccess(
  q: MicroUSDC,
  r: bigint,
  i: number,
  B: MicroUSDC,
  A: MicroUSDC
): SeatAllocation {
  const gross = q + (BigInt(i) < r ? 1n : 0n);
  const charge = gross - B;
  const refund = A - charge;
  return { index: i, gross, charge, refund };
}

/**
 * Compute all seat allocations for a success outcome with N paid units.
 */
export function computeSuccessSeats(
  terms: CampaignTerms,
  N: number
): SeatAllocation[] {
  if (N === 0) return [];
  const Nb = BigInt(N);
  const q = terms.cost / Nb;
  const r = terms.cost % Nb;
  const seats: SeatAllocation[] = [];
  for (let i = 0; i < N; i++) {
    seats.push(seatAllocSuccess(q, r, i, terms.subsidyPerUnit, terms.depositPerUnit));
  }
  return seats;
}

/**
 * Compute all seat allocations for a failure outcome with N reserved seats.
 * Each seat: gross=0, charge=0, refund=A.
 */
export function computeFailureSeats(
  terms: CampaignTerms,
  N: number
): SeatAllocation[] {
  const seats: SeatAllocation[] = [];
  for (let i = 0; i < N; i++) {
    seats.push({ index: i, gross: 0n, charge: 0n, refund: terms.depositPerUnit });
  }
  return seats;
}

/**
 * Check all success gates independently.
 */
export function computeGates(
  terms: CampaignTerms,
  N: number,
  sponsorFunded: boolean,
  deadlinePassed: boolean
) {
  const Nb = BigInt(N);
  const gateMinUnits = Nb >= terms.minUnits;
  const gateEligibleFunding =
    N > 0 && (terms.depositPerUnit + terms.subsidyPerUnit) * Nb >= terms.cost;
  const gateSponsorFunded = terms.subsidyPerUnit === 0n || sponsorFunded;
  const gateDeadline = deadlinePassed;
  return { gateMinUnits, gateEligibleFunding, gateSponsorFunded, gateDeadline };
}

/**
 * Conservation check: totalCredit must equal N*A + actualReserve.
 */
export function checkConservation(
  totalCredit: MicroUSDC,
  N: number,
  depositPerUnit: MicroUSDC,
  actualReserve: MicroUSDC
): boolean {
  const liabilities = BigInt(N) * depositPerUnit + actualReserve;
  return totalCredit === liabilities;
}

/**
 * Preview allocation for a hypothetical N. Matches previewAllocation() in contract.
 * Returns null if N===0 (unavailable) or N>K.
 * Returns { isPredictedFailure: true } for 0 < N < minUnits.
 */
export interface PreviewResult {
  N: number;
  isPredictedFailure: boolean;
  quotient: MicroUSDC;
  remainder: bigint;
  chargeAtQuotient: MicroUSDC;
  chargeAtRemainder: MicroUSDC;
  refundAtQuotient: MicroUSDC;
  refundAtRemainder: MicroUSDC;
  sellerCredit: MicroUSDC;
  sponsorCredit: MicroUSDC;
  totalBuyerRefund: MicroUSDC;
  seats: SeatAllocation[];
}

export function previewAllocation(
  terms: CampaignTerms,
  N: number,
  sponsorFunded: boolean,
  actualReserve: MicroUSDC
): PreviewResult | null {
  // N=0: no quote (would divide by zero)
  if (N === 0) return null;
  if (N > Number(terms.capacity)) return null;

  const Nb = BigInt(N);
  const isPredictedFailure = Nb < terms.minUnits;

  if (isPredictedFailure) {
    // Failure range: full A refund per seat, no division. Sponsor returns actualReserve.
    return {
      N,
      isPredictedFailure: true,
      quotient: 0n,
      remainder: 0n,
      chargeAtQuotient: 0n,
      chargeAtRemainder: 0n,
      refundAtQuotient: terms.depositPerUnit,
      refundAtRemainder: 0n,
      sellerCredit: 0n,
      sponsorCredit: actualReserve,
      totalBuyerRefund: terms.depositPerUnit * Nb,
      seats: computeFailureSeats(terms, N),
    };
  }

  // Success range: require sponsor funded when B > 0
  if (terms.subsidyPerUnit > 0n && !sponsorFunded) return null;

  const q = terms.cost / Nb;
  const r = terms.cost % Nb;
  const seats = computeSuccessSeats(terms, N);
  const totalBuyerRefund = seats.reduce((s, seat) => s + seat.refund, 0n);
  const sellerCredit = terms.cost;
  const sponsorCredit =
    terms.subsidyPerUnit > 0n
      ? terms.sponsorReserve - Nb * terms.subsidyPerUnit
      : 0n;

  return {
    N,
    isPredictedFailure: false,
    quotient: q,
    remainder: r,
    chargeAtQuotient: q - terms.subsidyPerUnit,
    chargeAtRemainder: r > 0n ? q + 1n - terms.subsidyPerUnit : 0n,
    refundAtQuotient: terms.depositPerUnit - (q - terms.subsidyPerUnit),
    refundAtRemainder: r > 0n ? terms.depositPerUnit - (q + 1n - terms.subsidyPerUnit) : 0n,
    sellerCredit,
    sponsorCredit,
    totalBuyerRefund,
    seats,
  };
}
