// All monetary values are BigInt micro-USDC (6 decimals).
// 1 USDC = 1_000_000n micro-USDC.

export type MicroUSDC = bigint;

export interface CampaignTerms {
  cost: MicroUSDC;           // C
  depositPerUnit: MicroUSDC; // A
  subsidyPerUnit: MicroUSDC; // B
  sponsorReserve: MicroUSDC; // S = B * capacity
  capacity: bigint;          // K
  minUnits: bigint;          // m
  deadlineLabel: string;     // display-only
  title: string;
  description: string;
}

export interface SeatAllocation {
  index: number;
  gross: MicroUSDC;
  charge: MicroUSDC;
  refund: MicroUSDC;
}

export type FinalizeBranch = 'success' | 'failure';

export interface FinalizeResult {
  branch: FinalizeBranch;
  N: number;
  seats: SeatAllocation[];
  sellerCredit: MicroUSDC;
  sponsorCredit: MicroUSDC;
  // Per-wallet credits (address string → amount)
  walletCredits: Record<string, MicroUSDC>;
  // Conservation check
  totalCredit: MicroUSDC;
  liabilities: MicroUSDC;
  // Gate checks
  gateMinUnits: boolean;
  gateEligibleFunding: boolean;
  gateSponsorFunded: boolean;
  gateDeadline: boolean;
}

export type SimPhase =
  | 'AwaitingSponsor'
  | 'Open'
  | 'FullAwaitDeadline'
  | 'ReadyFinalize'
  | 'Succeeded'
  | 'Failed';

export interface WalletReceipt {
  address: string;
  role: ('buyer' | 'seller' | 'sponsor')[];
  seatIndices: number[];
  deposited: MicroUSDC;   // A * seats (buyer role)
  allocated: MicroUSDC;   // credit written at finalize
  claimed: MicroUSDC;     // simulated claimed amount
  claimable: MicroUSDC;   // allocated - claimed
}

export interface SimState {
  terms: CampaignTerms;
  phase: SimPhase;
  sponsorFunded: boolean;
  actualReserve: MicroUSDC;
  unitCount: number;
  seatOwners: string[];          // index → wallet address
  deadlinePassed: boolean;
  finalized: boolean;
  finalizeResult: FinalizeResult | null;
  // Per-address claimed amounts (post-finalize)
  claimed: Record<string, MicroUSDC>;
  totalOutstanding: MicroUSDC;
  totalClaimed: MicroUSDC;
  // Donation scenario
  donationBalance: MicroUSDC;    // extra balance beyond liabilities
}
