/** Arc Studio foundation, manually refined. See MANUAL_REFINEMENT.md. */
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

// Sandbox-default entry point. No wallet providers, automatic reconnect,
// diagnostic forwarding, network instrumentation, or signing hooks are mounted.
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
