# Verification boundaries

Prepared for **private source delivery r6 on 22 October 2026**. This is a documentation-only successor to r5, adding subsequently observed Studio synchronization, test and embedded-preview evidence. Every application, test, contract, dependency, configuration, license and optional-tool file is unchanged from r5. The runtime still includes the narrowly scoped cancellation guard at the final wallet-provider submission boundary, clearer outside-provider sentence and four regression files introduced in r5. It is not a public release, a professional security audit or a production-readiness certification.

## Delivery note

A known account/chain change, disconnect or controller disposal before `eth_sendTransaction` reaches the provider now prevents forwarding the request. There is no intervening asynchronous yield between the final context check and forwarding. Once forwarding has occurred, a later context change does not establish cancellation: ambiguous outcomes remain unresolved and locked against another submission.

The guard intentionally does not clear a saved recovery reference when the controller has already been disposed or cleanup storage writes fail. A reopened panel may therefore conservatively remain locked even after a locally cancelled request. Do not clear storage, open a second Live window or resubmit to bypass that protection. The review uses inert providers and mocked reads, not a real wallet or Mainnet.

## Source and delivery identity

- Runtime, tests, dependency manifests and locks, build configuration, Solidity source, pinned artifact, license texts and vendored Forge Standard Library match the current integrated application. The canonical application commit is `ee79873b251caf92189a63a466ef16113b27a539`.
- `README.md` has only explicit bundle-specific documentation adaptations: point to delivered build/verification documents and distinguish earlier evidence from the newly verified, scoped Studio synchronization/checks and embedded-preview observations. `docs/BUILD.md` and this document are delivery-only documents. No runtime or test implementation is adapted for the bundle.
- The production controller introduced in r5 has SHA-256 `a3ade794abb42013858e744a73592240f55fe22e014268826668782bc561aca1`. The other production change since r4 is the outside-provider sentence in `src/App.tsx`. Four new files under `tests/submission-*.test.*` cover copy, submission-dispatch cancellation, failure paths and verification boundaries.
- The original contract, original and supplemental contract suites, pinned ABI/creation/runtime artifact, application dependency manifests/lockfile and compilation configuration are unchanged from r4. The complete approved optional v4 sidecar remains unchanged and separate from the application dependencies.
- Private reports, planning material, raw workspace logs, credentials, hosting metadata, `.git`, `.openai`, installed dependencies, build outputs and caches are excluded. The optional sidecar's previously approved, sanitized historical examples are the explicit exception to the exclusion of raw reports.
- Third-party notices and exact license texts are retained, including both Forge license alternatives. No project-wide license has been selected for CommonRate's own code; existing source-file SPDX headers remain unchanged.

## Current application evidence

- **Integrated application check:** 372 app tests and 2,765 assertions passed, followed by nonincremental TypeScript checking, non-fixing type-aware source lint and a production build against frozen dependencies. These are mocked/interface/source checks, not actual-wallet verification.
- **Independent cancellation review:** 54 separately authored cases and 471 assertions passed against the exact controller hash above. They exercise pre-dispatch interruptions, exact uninterrupted forwarding, post-dispatch ambiguity, failed cleanup persistence, wrong-chain and forged-error behavior, and no-yield ordering. Three intentionally defective negative controls were detected. These counts are separate from the 372 shipped app tests; the private reviewer harness and raw reports are not bundled.
- **r5 extraction replay:** packaging repeated the ordinary `bun run check` from a clean extracted copy, again passing 372 tests/2,765 assertions, typecheck, non-fixing source lint and build. It used a physical copy of the existing frozen dependency installation, not a symlink and not a fresh registry install. All nine resulting production files matched the canonical build byte-for-byte. All delivered source files, the manifest and checksums stayed unchanged after the replay. The optional sidecar and Solidity suites were not rerun as part of this extraction replay.
- **Fresh optional React replay:** a separate fresh v4 run against the integrated candidate passed 43 mocked interactions, with all 12 current source-input hashes verified. The 12 output-containment regressions and nine network-denial canaries also passed; the interaction run recorded zero runtime network attempts. Raw current reports remain private and are not bundled. This is React test-renderer evidence, not DOM/browser, CSS/layout, real focus, wallet-extension or actual-provider evidence.

The guard observes emitted provider events and local invalidations; it does not prove safety when a provider silently changes context without an observable event. Existing protections for storage readback, foreign unresolved records, transaction matching, provenance, contract code, allowance, bounded approvals and no automatic transport fallback are retained. Live remains experimental and single-window; shared-storage checks are not an atomic cross-tab lock.

## Unchanged historical evidence

- **Original contract suite:** earlier verification passed all 26 mocked-token tests, including a bounded property test with 512 fuzz runs. The unchanged `bun run contracts:test` selects only that suite. Earlier independent compilation reproduced the exact pinned ABI and creation/runtime bytecode.
- **Separate supplemental suite:** earlier independent verification passed 16 tests and a combined run passed all 42 contract tests. Its 120 four-wallet claim-order scenarios and 32 fixed two-round schedules are finite mock coverage, not arbitrary schedules or real transactions. See [supplemental scope](SUPPLEMENTAL_CONTRACT_TESTS.md). These contract and artifact results remain applicable to byte-identical inputs; **r5 packaging did not rerun them**.
- **Preserved sidecar examples:** all 22 approved v4 files are byte-for-byte unchanged from the archive with SHA-256 `4d248c34143884084f11421ba1ca55df0dd14705b0ebca6362a1f75d5667444a`. Its own package version is 1.3.0. The bundled examples identify checkpoint09, not this candidate. Ten of their 12 source-input hashes match the unchanged r5/r6 runtime; `src/live/controller.ts` and `src/live/live.css` differ. Their intentionally failing controls are sensitivity evidence, not current-source failures. CSS is replaced with empty content by the renderer, so neither the historical examples nor the fresh replay verifies styling. The manifest records both historical differences and the separate fresh replay scope without modifying the examples.
- **Earlier hosted interface observations:** prior desktop, narrow-window and browser-zoom checks included Rules-dialog focus containment, retained simulation state, exact result/selector co-visibility at 500px and 333px reflow, preset reset, reservation acknowledgment/receipt jump, stale-context cleanup, title/favicon and controlled same-document Back/Forward behavior. Those earlier observations predate this submission pass and remain historical. The later embedded Studio observations below are separate evidence. No physical-phone/touch, assistive-technology or real-wallet test is claimed.

## Studio and private native Site status

At the time r5 was sealed, Studio synchronization/testing of the submission changes was unverified. That remains the historical status of r5, not the current status below; the r5 ZIP and earlier records are unchanged.

The six reviewed application/test files were subsequently synchronized into the original signed-in Arc Studio project through its manual terminal, and the exact existing `public/THIRD_PARTY_NOTICES.txt` was added. On **22 October 2026, 16:58–17:07 UTC**, actual Studio command output established:

- `bun run check` exited 0: **372 passed, 0 failed, 2,765 expectations across 22 files**. Nonincremental TypeScript passed; type-aware oxlint reported **0 warnings and 0 errors**; Vite production build passed.
- `bun run contracts:test` exited 0: **26 passed, 0 failed, 0 skipped**, including **512 conservation fuzz runs**. This is the original suite, not a fresh supplemental 16-test or combined 42-test run and not a new compiler-artifact reproduction.
- Studio reported **Bun 1.3.14** and **Node 24.21.0**.
- Final allowlisted parity was **72/72 application/configuration inputs** and **9/9 production assets** byte-identical to native runtime11. The initial scoped manifest27 recorded a missing third-party notice; the immutable final manifest28 recorded parity after the exact notice was added. These scoped manifests are **not full source exports**. The last full working-tree export remains **export26**; no new source download or full export was made.

The original project's evidence records are `docs/manual-release-12-check.txt`, `docs/manual-release-12-contracts.txt`, `docs/manual-release-12-build.txt`, `docs/manual-working-tree-manifest-27.json` and `docs/manual-working-tree-manifest-28.json`. They are source-project records, not files bundled into this private delivery. Raw private logs remain excluded.

The matching private native Site deployment succeeded at **2026-10-22 15:48:34 UTC**, for source commit `ee79873b251caf92189a63a466ef16113b27a539`; deployment, runtime11 and application code are unchanged for r6. The native private URL remains login-gated. Private deployment is not public publication or real-wallet/Mainnet proof.

## Current embedded Studio browser observations

Actual embedded-preview checks on **22 October 2026, 17:10–17:13 UTC** established this limited scope:

- **Rules dialog:** Tab and Shift+Tab stayed inside the open dialog; Escape closed it and returned focus.
- **Default round:** a 10-seat round with one owned seat advanced to its illustrative deadline and settled to **45 USDC cost / 15 USDC claim**. Marking the simulated claim and returning to booking retained the original refund receipt. This did not move real funds.
- **375px viewport:** viewport and document widths both measured 375px. The new outside-provider disclaimer and failed 7-seat preset with two owned seats and a **120 USDC refund** displayed cleanly. This is an emulated narrow viewport, not a physical-phone/touch test.
- **Experimental Live boundary:** the embedded-frame restriction ultimately displayed and **Connect wallet was disabled**, with no network selected, account permission or transaction. There was one first lazy-load preview reload and a Vite reconnect; the cause was not established. A subsequent Live opening reached a stable disabled state. The initial reload is recorded, not presented as a clean uninterrupted first-load pass.
- **Persistence limit:** switching Studio viewport remounted the iframe and reset Sandbox. The observed within-session receipt retention is not evidence of simulation persistence across iframe remounts or reloads.

Only the embedded Studio preview was exercised. A standalone Studio preview was not available for this check, and the login-gated native URL was not a substitute for standalone wallet QA. No actual standalone Live/wallet behavior, real signing, deployment or financial action is established. The later public read-only network check below is separate from those embedded UI observations and did not enable a wallet.

## Public network read and remaining wallet-fee gate

After checking the configured values against current official Arc/Circle references, the app's public read-only network check was used in embedded Studio at **2026-10-22 17:15:58 UTC**. Arc Mainnet / Public Arc RPC was selected with the deployment hash blank, no injected wallet and no account access. The UI reported successful chain, canonical token code, six-decimal and chain-time reads at **block 27,317,207**, with chain time **2026-10-22 17:15:57 UTC**. No campaign was verified.

A second public check of **Arc Testnet** succeeded at **2026-10-22 17:16:34 UTC**, at **block 68,553,765**, with chain time **2026-10-22 17:16:33 UTC**. Switching networks first cleared the prior Mainnet verified result. This check also used Public Arc RPC, a blank deployment hash and no wallet.

These are genuine public network metadata reads, not mocked RPC results. They are not CommonRate deployment/campaign verification, transactions, USDC movement, wallet compatibility or contest eligibility proof. Earlier no-network statements remain true only for their explicitly offline test runs, not for these later read-only checks.

The checked application configuration matches these official references as observed on 22 October 2026:

- Arc Mainnet chain **5042**, RPC `https://rpc.mainnet.arc.io`; Arc Testnet chain **5042002**, RPC `https://rpc.testnet.arc.io`. [Arc connection reference](https://docs.arc.io/arc/references/connect-to-arc).
- Canonical USDC ERC-20 interface **`0x3600000000000000000000000000000000000000`**, **6 decimals**, on both networks. Native gas USDC uses **18 decimals**; these interfaces access the same underlying balance and must not be added together. [Arc contract addresses](https://docs.arc.io/arc/references/contract-addresses) and [Circle USDC contract addresses](https://developers.circle.com/stablecoins/usdc-contract-addresses).
- **Wallet-fee validation remains a gate.** The app delegates fee selection to the wallet. Arc's current guidance documents a `maxFeePerGas` minimum of **20 Gwei** and advises obtaining current fee data. No actual wallet fee path was exercised here. This is a validation requirement, not an instruction to submit with a fixed fee, a total-cost quote or a guarantee of successful inclusion. [Arc gas and fees](https://docs.arc.io/arc/references/gas-and-fees).

No application/configuration change was made for this evidence update. Actual wallet operation and fee handling, Mainnet campaign transactions and contest eligibility remain unverified.

## Integrity verification

`MANIFEST.json` identifies every delivered content file and explains provenance, optional-tool history and validation scope. `SHA256SUMS.txt` covers all delivered files except itself, including the manifest. The ZIP was generated twice with identical bytes, checked for safe paths, duplicate entries, symlinks, CRC errors and excluded material, then safely extracted for complete checksum and byte-parity verification. Only `README.md`, `docs/BUILD.md`, `docs/VERIFICATION.md`, `MANIFEST.json` and `SHA256SUMS.txt` changed from r5. The other 168 files, including all 22 optional v4 files, are byte-identical. The r6 packaging pass validates this documentation-only delta, deterministic archive and extracted integrity; it does not claim a new application, Solidity, sidecar or browser execution. Studio command/UI results above are separately observed evidence, and the r5 extraction replay remains historical. These records detect changes relative to this package; they are not a cryptographic signature, security audit or proof of an onchain deployment.

## Remaining boundaries

- No actual wallet connection, signature, approval, deployment, funding, reservation, finalization, withdrawal or other chain write is part of the reported tests. No real token movement, booked provider, customers or revenue is claimed.
- Mocked tests and artifact identity do not establish current Arc network/token compatibility, wallet behavior, finality, service delivery, economic suitability or freedom from vulnerabilities. The documented public Mainnet metadata read does not establish campaign/transaction proof or contest eligibility; those remain pending, as does actual wallet fee-path validation.
- A successful funding round is not service-delivery escrow. The group must agree the real session and later cancellation/nondelivery arrangements with the provider outside CommonRate.
- The optional sidecar's network tripwires and output protections are test guards for trusted source, not an operating-system security sandbox or a guarantee against hostile code/filesystem races.
- A fresh r5 or r6 registry dependency installation is not claimed. The prior fresh optional-tool npm install belongs to r4; its unchanged dependency graph is not evidence of a new r5/r6 install.
- Public release, submission of materials to third parties, a project-wide licensing decision and any real-money trial remain separate decisions. Included deployment helpers are source, not authorization or instructions to execute them.

For local commands, see [BUILD.md](BUILD.md). For accounting and wallet risks, see the [README](../README.md).
