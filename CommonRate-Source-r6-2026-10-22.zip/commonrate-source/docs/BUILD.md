# Build and verify locally

This is a private source delivery for an experimental CommonRate prototype. It is not a public release or a production-readiness certification. Start in Sandbox; no account, wallet, signing key or deployment is required to build or test it.

## Pinned inputs

- Bun **1.3.14**, recorded in `.bun-version`.
- Foundry **v1.7.1**, recorded in `.foundry-version`.
- Solidity **0.8.28**, Paris EVM, optimizer **200** runs and **via IR**, recorded in `foundry.toml` and the pinned artifact.
- `bun.lock` is the supplied dependency lockfile. Preserve it and use the frozen install below. Do not substitute npm, refresh dependencies or trim unused starter packages when reproducing these results.
- The exact CommonRate ABI and creation/runtime bytecode template are in `src/contracts/CommonRate.artifact.json`; the application checks its pinned identity.

Install Bun and Foundry from their official distributions if needed. Dependency installation and the first Solidity compiler setup may require internet access. This source delivery deliberately does not contain `node_modules`, tool binaries or compiler caches, so it is not an offline installation kit.

## Commands

Run these commands from the extracted source root:

```sh
bun install --frozen-lockfile
bun run check
bun run contracts:build
bun run contracts:test
```

`check` runs the app tests, nonincremental TypeScript check, non-fixing source lint and production build. The integrated submission candidate passed **372 app tests with 2,765 assertions**. The earlier r5 packaging verification repeated the complete `check` command from a separate clean extraction using a physical copy of the existing frozen dependency installation. This was not a fresh registry install; it did not modify the canonical dependency directory. The original Studio project also passed `bun run check` on 22 October 2026 with Bun 1.3.14 and Node 24.21.0. This r6 successor changes only documentation/integrity records and does not claim a new packaging test execution or dependency install. See [verification boundaries](VERIFICATION.md).

`contracts:test` selects only `contracts/test/CommonRate.t.sol`: the **original 26 contract tests**, including the original property test with **512 fuzz runs**. It does not run the optional supplemental file.

To run the separately reviewed **16 supplemental contract tests**:

```sh
forge test --match-path contracts/test/CommonRateStateful.t.sol --fuzz-runs 512 -vv
```

Those added tests use deterministic finite schedules; specifying 512 fuzz runs does not turn them into 512 independent randomized trials. Earlier verification also independently ran the original and supplemental suites together, passing **42 contract tests** in total. The original Studio project subsequently reran the normal `bun run contracts:test` command on 22 October 2026: 26 passed, 0 failed, 0 skipped, including 512 conservation fuzz runs. This was not a new 42-test combined run or artifact reproduction. Contract source, artifact, tests and compilation inputs remain unchanged; neither r5 nor r6 packaging reran Solidity tests or artifact reproduction. These are contract test counts, separate from the 372 app tests. See [supplemental scope and limitations](SUPPLEMENTAL_CONTRACT_TESTS.md).

Build products are written to `dist/`, `contracts/out/` and `contracts/cache/`; they are not part of the source delivery. None of these commands runs the separate optional React interaction sidecar described below.

For local exploration:

```sh
bun run dev
```

Open the URL Vite reports. The retained development-server configuration allows hosts and CORS broadly and is intended only for trusted local use. Do not expose this development server to an untrusted network or use it as a production host. This package does not change those inherited network settings.

## Configuration and deployment boundaries

The TypeScript configuration preserves two compatibility mappings for absolute import keys emitted by the published Circle package declaration files. They point to relative packages under `node_modules`. The keys identify an upstream package build location, not a directory to create on your machine or a private file supplied with this project. Removing these mappings would change a tested build input.

The included CREATE2 factory and deployment script are preserved source, not suggested setup steps. Do not run deployment helpers, add broadcast flags, supply credentials or execute real wallet actions as part of verification. The Live pilot is separately selected and experimental; see the main README before any actual use.

## Optional offline React interaction tests

The separately reviewed tool is under `tools/optional/commonrate-offline-react-audit/`. Its complete approved source, own `package.json` and `package-lock.json` are preserved independently of the app. It does not change the app's package manifest or Bun lockfile. No installed dependencies or duplicate app runtime are included with the tool.

Read the [sidecar README](../tools/optional/commonrate-offline-react-audit/README.md) before use. It requires Node 20 or newer and an existing app dependency installation containing compatible React, React DOM, esbuild and viem. The sidecar pins React, React DOM and react-test-renderer to 18.3.1 and rejects a caller React-version mismatch rather than upgrading dependencies. The recorded run used Node 24.19.0 and esbuild 0.25.12.

After the ordinary app dependency install, this example installs only the optional tool's locked dependencies and writes reports to a fresh temporary directory outside the project:

```sh
# Start at the extracted source root.
PROJECT="$(pwd -P)"
REPORTS_PARENT="$(mktemp -d "${TMPDIR:-/tmp}/commonrate-react-reports.XXXXXX")"
(
  cd "$PROJECT/tools/optional/commonrate-offline-react-audit"
  npm ci --ignore-scripts --no-audit --no-fund --registry=https://registry.npmjs.org
  npm test
  node run.mjs \
    --source-dir "$PROJECT/src" \
    --dependencies-dir "$PROJECT/node_modules" \
    --out "$REPORTS_PARENT/current-source" \
    --label private-source-check
)
```

The optional tool's `npm test` runs **12 output-containment regressions** and a network-guard canary. Its project runner separately executes **43 mocked React interaction cases**. The recorded runtime guard check passed nine network-denial canaries without making a network request. These counts are not part of the 372 app tests or either contract suite. The runner requires a new output leaf and will not reuse an existing report directory.

The included `example-evidence/` files are **recorded mock results from the reviewed checkpoint09 development run**, not results from your machine or evidence of a real provider, wallet or transaction. Ten of their 12 recorded input hashes match this delivery: `src/live/controller.ts` changed for the submission cancellation guard and `src/live/live.css` changed for placeholder contrast. The historical examples are unchanged and are not current-source results. A separate fresh run against the integrated submission candidate passed all 43 cases and verified all 12 current input hashes; the 12 output-containment regressions and nine network-denial canaries also passed. Its raw private reports are not bundled. The tool loads CSS as empty and does not test visual styling or the separate Sandbox claim-feedback correction. Run the tool against this extracted source to create your own fresh current-source hash record. Intentional negative controls are separately labeled; their expected failures are not failures of the current recorded 43-case run. The approved historical examples and their checkpoint comparison remain unchanged; they must not be relabeled as current evidence. A new run produces its own source-hash evidence in the selected report directory. Network tripwires are test guards for trusted source, not an operating-system security sandbox; this tool is not a way to safely execute arbitrary untrusted code. React test rendering is not DOM, browser, layout or accessibility evidence.

## Source integrity

This delivery includes `SHA256SUMS.txt`, covering every delivered file except the checksum file itself. Check it before installing or modifying files:

```sh
sha256sum --check SHA256SUMS.txt
```

On a system with Perl's checksum tool instead:

```sh
shasum -a 256 -c SHA256SUMS.txt
```

The checksum inventory detects changes relative to this delivery; it is not a signature, a vulnerability audit or evidence of onchain deployment. The artifact's runtime bytecode is an immutable template, not a deployed-contract runtime hash. See [verification boundaries](VERIFICATION.md).
