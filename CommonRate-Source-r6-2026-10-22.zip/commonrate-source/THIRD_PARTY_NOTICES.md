# Third-party notices

These notices identify third-party material retained in the source or used by the reviewed browser application. The license texts are reproduced unchanged in `licenses/`; their copyright, permission and disclaimer language remains authoritative. This file does not grant a project-wide license for CommonRate's own code.

## Vendored Solidity test library

**Forge Standard Library (`forge-std`)**, package metadata version **1.16.2**, by Contributors to Forge Standard Library. Upstream: https://github.com/foundry-rs/forge-std.

The vendored files under `lib/forge-std/` carry `MIT OR Apache-2.0` identifiers. These are alternative licenses, not cumulative terms. Both original alternatives are preserved:

- [MIT text](licenses/forge-std/LICENSE-MIT)
- [Apache 2.0 text](licenses/forge-std/LICENSE-APACHE)

Keep these texts with distributions of the vendored library, and retain the file-level notices. The vendored source was matched byte-for-byte to the downloaded package containing these texts. The metadata version is recorded as package provenance, not a separately verified upstream Git commit.

## Solidity build dependency

**OpenZeppelin Contracts 5.1.0**, copyright (c) 2016–2024 Zeppelin Group Ltd, MIT. The included CREATE2 helper imports this package; the CommonRate core contract does not import it. [Exact v5.1.0 license](licenses/openzeppelin-contracts/LICENSE). Source: https://github.com/OpenZeppelin/openzeppelin-contracts/tree/v5.1.0.

## Reviewed browser dependencies

The following package versions contributed rendered JavaScript to the checked bundle. Original MIT license texts are included for each:

- React **18.3.1**: [license](licenses/react-18.3.1/LICENSE).
- React DOM **18.3.1**: [license](licenses/react-dom-18.3.1/LICENSE).
- Scheduler **0.23.2**: [license](licenses/scheduler-0.23.2/LICENSE).
- viem **2.57.5**: [license](licenses/viem-2.57.5/LICENSE).
- ox **0.14.56**: [license](licenses/ox-0.14.56/LICENSE).
- abitype **1.2.3**: [license](licenses/abitype-1.2.3/LICENSE).
- @noble/curves **1.9.1**: [license](licenses/noble-curves-1.9.1/LICENSE).
- @noble/hashes **1.8.0**: [license](licenses/noble-hashes-1.8.0/LICENSE).
- Vite **6.4.4** runtime preload helpers: [packaged license, including its core MIT text](licenses/vite-6.4.4/LICENSE.md).

Browser distributions should include a plain-text compilation of these applicable original texts at `THIRD_PARTY_NOTICES.txt` alongside the browser assets. Vite's core MIT section covers its emitted preload helpers; the additional build-package notices in its full license file are not asserted to be browser modules.

Keep these notices and license texts accessible with distributed browser builds; retaining only a short minified license comment is not a substitute for the included permission text. `package.json` and `bun.lock` also declare installation/build dependencies whose own packages carry their applicable terms. This is a bounded source/browser inventory, not a complete audit of every installed development or optional dependency. Recheck the shipped module set if the source, dependencies or build configuration changes.
